/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HeaderNav, NavigationTab } from './components/HeaderNav';
import { DoctorProfileCard } from './components/DoctorProfileCard';
import { Odontogram } from './components/Odontogram';
import { PatientIntakeWizard } from './components/PatientIntakeWizard';
import { AppointmentBooking } from './components/AppointmentBooking';
import { PatientRecordsView } from './components/PatientRecordsView';
import { SmileShadeConsult } from './components/SmileShadeConsult';
import { PostOpCareGuide } from './components/PostOpCareGuide';
import { SdaLogo } from './components/SdaLogo';
import { CustomerLoginModal, CustomerUser } from './components/CustomerLoginModal';
import { ClinicAdminLoginModal } from './components/ClinicAdminLoginModal';
import { ClinicAdminDashboard } from './components/ClinicAdminDashboard';
import { DentalChatbot } from './components/DentalChatbot';
import { INITIAL_TEETH_DATA, DOCTOR_INFO } from './data/dentalData';
import { ToothData, PatientIntakeData, AppointmentSlot } from './types/dental';
import { 
  Building2,
  Lock,
  ShieldCheck, 
  Phone, 
  Mail, 
  Clock 
} from 'lucide-react';

const INITIAL_CLINIC_APPOINTMENTS: AppointmentSlot[] = [
  {
    id: 'APT-2026-8812',
    serviceId: 'srv-diag',
    serviceName: 'Single-Visit Rotary Root Canal & 3D Margin Scan',
    doctorName: 'Dr. Swati R Emaliya, BDS',
    date: '2026-09-30',
    time: '11:30 AM',
    durationMinutes: 60,
    status: 'confirmed',
    patientName: 'Sarah Jenkins',
    phone: '+1 (555) 392-8841',
    email: 'sarah.jenkins@example.com',
    notes: 'Tooth #30 mandibular first molar acute pulpitis. Pre-medicated.'
  },
  {
    id: 'APT-2026-8814',
    serviceId: 'srv-clean',
    serviceName: 'Ultrasonic Scaling & Airflow Polishing',
    doctorName: 'Dr. Swati R Emaliya, BDS',
    date: '2026-10-01',
    time: '04:00 PM',
    durationMinutes: 45,
    status: 'confirmed',
    patientName: 'Rajesh Patel',
    phone: '+91 98765 43210',
    email: 'rajesh.patel@example.com',
    notes: 'Routine 6-month preventive prophylaxis & topical fluoride.'
  },
  {
    id: 'APT-2026-8815',
    serviceId: 'srv-cosm',
    serviceName: 'Aesthetic Porcelain Veneer Shade Evaluation',
    doctorName: 'Dr. Swati R Emaliya, BDS',
    date: '2026-10-02',
    time: '02:15 PM',
    durationMinutes: 45,
    status: 'pending',
    patientName: 'Ananya Sharma',
    phone: '+91 98220 11984',
    email: 'ananya.sharma@example.com',
    notes: 'Upper anterior smile makeover consult with digital mock-up.'
  },
  {
    id: 'APT-2026-8809',
    serviceId: 'srv-fill',
    serviceName: 'Nano-Hybrid Composite Aesthetic Restoration',
    doctorName: 'Dr. Swati R Emaliya, BDS',
    date: '2026-09-28',
    time: '10:00 AM',
    durationMinutes: 45,
    status: 'completed',
    patientName: 'Michael Chen',
    phone: '+1 (555) 841-2093',
    email: 'm.chen@example.com',
    notes: 'Occlusal composite filling on tooth #14. Restoration sound.'
  }
];

const INITIAL_CLINIC_INTAKES: PatientIntakeData[] = [
  {
    fullName: 'Sarah Jenkins',
    dateOfBirth: '1994-06-18',
    gender: 'Female',
    phone: '+1 (555) 392-8841',
    email: 'sarah.jenkins@example.com',
    address: '428 Greenwood Ave, Apt 3B',
    hasInsurance: true,
    insuranceProvider: 'Delta Dental Premier',
    policyNumber: 'DD-9841204',
    groupNumber: 'GRP-5501',
    dentalAnxietyScore: 2,
    allergies: ['Latex (Mild skin irritation)'],
    medicalConditions: ['None of the above'],
    medications: 'Daily Vitamin D3 (Over-the-counter)',
    isPregnant: false,
    hasPreviousComplications: false,
    complicationsDetails: '',
    primaryConcern: 'Acute sensitivity to cold liquids on lower right molar',
    painLevel: 6,
    symptoms: ['Sharp toothache with cold/hot liquids', 'Localized pain when chewing'],
    symptomDuration: 'Past 10 days',
    consentSigned: true,
    signatureDataUrl: '',
    consentDate: '2026-09-29',
    privacyNoticeAcknowledged: true
  },
  {
    fullName: 'Rajesh Patel',
    dateOfBirth: '1988-11-04',
    gender: 'Male',
    phone: '+91 98765 43210',
    email: 'rajesh.patel@example.com',
    address: '14 Lotus Residency, Satellite Road',
    hasInsurance: false,
    insuranceProvider: '',
    policyNumber: '',
    groupNumber: '',
    dentalAnxietyScore: 1,
    allergies: ['No Known Drug Allergies (NKDA)'],
    medicalConditions: ['None of the above'],
    medications: 'None',
    isPregnant: false,
    hasPreviousComplications: false,
    complicationsDetails: '',
    primaryConcern: 'Routine 6-month cleaning & stain removal',
    painLevel: 0,
    symptoms: ['Routine checkup & hygiene only'],
    symptomDuration: 'Preventive check',
    consentSigned: true,
    signatureDataUrl: '',
    consentDate: '2026-09-28',
    privacyNoticeAcknowledged: true
  }
];

export default function App() {
  const [currentTab, setCurrentTab] = useState<NavigationTab>('intake');
  const [teethData, setTeethData] = useState<ToothData[]>(INITIAL_TEETH_DATA);
  const [patientRecord, setPatientRecord] = useState<PatientIntakeData | null>(null);
  const [showDoctorModal, setShowDoctorModal] = useState<boolean>(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState<boolean>(false);
  const [isChatbotOpen, setIsChatbotOpen] = useState<boolean>(false);

  // Clinic Admin Authentication & Dashboard States
  const [isClinicLoginModalOpen, setIsClinicLoginModalOpen] = useState<boolean>(false);
  const [isClinicDashboardOpen, setIsClinicDashboardOpen] = useState<boolean>(false);
  const [isClinicAdminAuthenticated, setIsClinicAdminAuthenticated] = useState<boolean>(() => {
    try {
      return (
        sessionStorage.getItem('sda_clinic_admin_authenticated') === 'true' ||
        localStorage.getItem('sda_clinic_admin_authenticated') === 'true'
      );
    } catch {
      return false;
    }
  });

  // Persistent Clinical Appointments
  const [appointments, setAppointments] = useState<AppointmentSlot[]>(() => {
    try {
      const saved = localStorage.getItem('sda_all_appointments');
      return saved ? JSON.parse(saved) : INITIAL_CLINIC_APPOINTMENTS;
    } catch {
      return INITIAL_CLINIC_APPOINTMENTS;
    }
  });

  // Persistent Clinical Patient Intake Records
  const [intakeRecords, setIntakeRecords] = useState<PatientIntakeData[]>(() => {
    try {
      const saved = localStorage.getItem('sda_all_intakes');
      return saved ? JSON.parse(saved) : INITIAL_CLINIC_INTAKES;
    } catch {
      return INITIAL_CLINIC_INTAKES;
    }
  });

  // Customer / Patient Authentication State with localStorage persistence
  const [currentUser, setCurrentUser] = useState<CustomerUser | null>(() => {
    try {
      const saved = localStorage.getItem('sda_customer_user');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const handleUpdateAppointments = (updated: AppointmentSlot[]) => {
    setAppointments(updated);
    try {
      localStorage.setItem('sda_all_appointments', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleUpdateIntakes = (updated: PatientIntakeData[]) => {
    setIntakeRecords(updated);
    try {
      localStorage.setItem('sda_all_intakes', JSON.stringify(updated));
    } catch {
      // ignore
    }
  };

  const handleLoginSuccess = (user: CustomerUser) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('sda_customer_user', JSON.stringify(user));
    } catch {
      // ignore
    }
    // Also auto-fill patient record for intake/booking if empty
    if (!patientRecord) {
      setPatientRecord({
        fullName: user.name,
        dateOfBirth: user.dob || '1994-06-18',
        gender: 'Female',
        phone: user.phone,
        email: user.email,
        address: 'Registered Clinic Patient',
        hasInsurance: false,
        insuranceProvider: '',
        policyNumber: '',
        groupNumber: '',
        dentalAnxietyScore: 2,
        allergies: ['No Known Drug Allergies (NKDA)'],
        medicalConditions: ['None of the above'],
        medications: 'None',
        isPregnant: false,
        hasPreviousComplications: false,
        complicationsDetails: '',
        primaryConcern: 'Routine checkup & diagnostic dental consultation',
        painLevel: 1,
        symptoms: ['Routine checkup & hygiene only'],
        symptomDuration: 'N/A',
        consentSigned: true,
        signatureDataUrl: '',
        consentDate: new Date().toLocaleDateString('en-US'),
        privacyNoticeAcknowledged: true
      });
    }
  };

  const handleLogout = () => {
    setCurrentUser(null);
    try {
      localStorage.removeItem('sda_customer_user');
    } catch {
      // ignore
    }
  };

  // Update tooth in odontogram
  const handleUpdateTooth = (updated: ToothData) => {
    setTeethData(prev =>
      prev.map(t => (t.universalNumber === updated.universalNumber ? updated : t))
    );
  };

  // Reset odontogram to pristine healthy state
  const handleResetChart = () => {
    const pristine = INITIAL_TEETH_DATA.map(t => ({
      ...t,
      condition: 'healthy' as const,
      affectedSurfaces: [],
      notes: undefined,
      recommendedTreatment: undefined,
      estimatedCost: 0
    }));
    setTeethData(pristine);
  };

  // Intake completion handler - saves both active patientRecord and appends to clinic database
  const handleIntakeComplete = (data: PatientIntakeData) => {
    setPatientRecord(data);
    const updatedIntakes = [data, ...intakeRecords.filter(r => r.phone !== data.phone)];
    handleUpdateIntakes(updatedIntakes);
  };

  // Appointment booked handler - prepends to appointments and persists
  const handleAppointmentBooked = (slot: AppointmentSlot) => {
    const updated = [slot, ...appointments];
    handleUpdateAppointments(updated);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0f0e0e] text-[#0F172A]">
      {/* Top Clinical Header & Navigation with Customer Login trigger */}
      <HeaderNav 
        currentTab={currentTab} 
        onSelectTab={setCurrentTab}
        currentUser={currentUser}
        onOpenLogin={() => setIsLoginModalOpen(true)}
        onOpenClinicLogin={() => {
          if (isClinicAdminAuthenticated) {
            setIsClinicDashboardOpen(true);
          } else {
            setIsClinicLoginModalOpen(true);
          }
        }}
        isClinicAdminAuthenticated={isClinicAdminAuthenticated}
        onOpenChatbot={() => setIsChatbotOpen(true)}
      />

      {/* Main Content Area */}
      <main 
        style={{ backgroundColor: '#0f0e0e', borderStyle: 'none' }}
        className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 pb-24 lg:pb-12 bg-[#0f0e0e] border-none"
      >
        {/* Doctor Spotlight Card Banner */}
        <DoctorProfileCard
          onBookClick={() => setCurrentTab('booking')}
          variant="full"
        />

        {/* Screen Switching Viewport */}
        <div>
          {currentTab === 'intake' && (
            <PatientIntakeWizard
              onComplete={handleIntakeComplete}
              onNavigateToBooking={() => setCurrentTab('booking')}
            />
          )}

          {currentTab === 'odontogram' && (
            <Odontogram
              teeth={teethData}
              onUpdateTooth={handleUpdateTooth}
              onResetChart={handleResetChart}
            />
          )}

          {currentTab === 'booking' && (
            <AppointmentBooking
              onAppointmentBooked={handleAppointmentBooked}
              defaultPatientName={currentUser?.name || patientRecord?.fullName}
              defaultPhone={currentUser?.phone || patientRecord?.phone}
              defaultEmail={currentUser?.email || patientRecord?.email}
              onNavigateToIntake={() => setCurrentTab('intake')}
            />
          )}

          {currentTab === 'records' && (
            <PatientRecordsView
              currentUser={currentUser}
              isClinicAdminAuthenticated={isClinicAdminAuthenticated}
              onOpenLogin={() => setIsLoginModalOpen(true)}
            />
          )}

          {currentTab === 'smile' && (
            <SmileShadeConsult
              onBookCosmetic={() => setCurrentTab('booking')}
            />
          )}

          {currentTab === 'postop' && (
            <PostOpCareGuide />
          )}
        </div>
      </main>

      {/* Clinical Footer */}
      <footer 
        style={{ backgroundColor: '#070606' }}
        className="border-t border-white/5 py-8 px-4 sm:px-6 lg:px-8 mt-auto"
      >
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex flex-col sm:flex-row items-center gap-4 text-center sm:text-left">
            <SdaLogo size="md" showSubtitle={false} />
            <div>
              <h4 
                style={{ color: '#bac6e1' }}
                className="text-sm font-bold"
              >
                {DOCTOR_INFO.clinicName}
              </h4>
              <p className="text-xs text-slate-400">
                Painless Minimally-Invasive Dentistry • Advanced Aesthetic Smile Studio
              </p>
              <p 
                style={{ color: '#bac6e1', fontWeight: 'bold' }}
                className="text-[11px] mt-0.5"
              >
                Dental Surgeon: <strong style={{ color: '#bac6e1' }}>{DOCTOR_INFO.name}, {DOCTOR_INFO.degrees}</strong>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-4 text-xs text-slate-400">
            <div className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-teal-400" />
              <span style={{ color: '#bac6e1', fontWeight: 'bold' }}>{DOCTOR_INFO.phone}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-teal-400" />
              <span style={{ color: '#bac6e1', fontWeight: 'bold' }}>{DOCTOR_INFO.email}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-teal-400" />
              <span style={{ color: '#bac6e1', fontWeight: 'bold' }}>{DOCTOR_INFO.hours}</span>
            </div>
          </div>
        </div>

        {/* Clinic & Admin Secure Login Section */}
        <div className="max-w-7xl mx-auto mt-6 pt-5 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 bg-white/[0.03] p-4 rounded-2xl border border-white/10">
          <div className="flex items-center gap-3 text-center sm:text-left">
            <div className="p-2.5 rounded-xl bg-teal-950/90 border border-teal-500/40 text-teal-300">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <p className="text-xs font-bold text-white flex items-center justify-center sm:justify-start gap-2">
                <span>Clinic Administration & Staff Portal</span>
                <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/40">
                  Secure Access
                </span>
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">
                Doctor & administrative command center: View all patient medical intake records, live scheduled bookings & export to Excel.
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => {
              if (isClinicAdminAuthenticated) {
                setIsClinicDashboardOpen(true);
              } else {
                setIsClinicLoginModalOpen(true);
              }
            }}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#00685F] hover:bg-[#00524b] active:scale-95 text-white text-xs font-bold shadow-lg transition border border-teal-400/40 shrink-0"
          >
            <Lock className="w-3.5 h-3.5 text-teal-200" />
            <span>
              {isClinicAdminAuthenticated ? 'Open Clinic Dashboard (SwatiDentalClinic)' : 'Clinic Login (Doctor & Staff)'}
            </span>
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-300" />
          </button>
        </div>

        <div className="max-w-7xl mx-auto mt-6 pt-4 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-500 gap-2">
          <span>
            © {new Date().getFullYear()} {DOCTOR_INFO.clinicName}. Clinical Clarity & Care Design System.
          </span>
          <span className="flex items-center gap-1 text-emerald-400">
            <ShieldCheck className="w-3.5 h-3.5" /> HIPAA Compliant Digital Medical Records & Sterilization Protocol
          </span>
        </div>
      </footer>

      {/* Customer / Patient Login Popup Modal */}
      <CustomerLoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        currentUser={currentUser}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
        onNavigateToTab={(tab) => setCurrentTab(tab)}
        onOpenClinicLogin={() => {
          setIsLoginModalOpen(false);
          if (isClinicAdminAuthenticated) {
            setIsClinicDashboardOpen(true);
          } else {
            setIsClinicLoginModalOpen(true);
          }
        }}
      />

      {/* Secure Clinic Admin Login Modal (Restricted to SwatiDentalClinic / Swati@12345) */}
      <ClinicAdminLoginModal
        isOpen={isClinicLoginModalOpen}
        onClose={() => setIsClinicLoginModalOpen(false)}
        onLoginSuccess={() => {
          setIsClinicAdminAuthenticated(true);
          setIsClinicDashboardOpen(true);
        }}
      />

      {/* Master Lavish Clinic Admin Dashboard with Excel Export */}
      <ClinicAdminDashboard
        isOpen={isClinicDashboardOpen}
        onClose={() => setIsClinicDashboardOpen(false)}
        onLogout={() => {
          setIsClinicAdminAuthenticated(false);
          setIsClinicDashboardOpen(false);
          try {
            sessionStorage.removeItem('sda_clinic_admin_authenticated');
            localStorage.removeItem('sda_clinic_admin_authenticated');
          } catch {
            // ignore
          }
        }}
        appointments={appointments}
        onUpdateAppointments={handleUpdateAppointments}
        intakeRecords={intakeRecords}
        onUpdateIntakeRecords={handleUpdateIntakes}
        customerUsers={currentUser ? [currentUser] : []}
        onDeleteCustomerUser={(id) => {
          if (currentUser?.id === id) {
            handleLogout();
          }
        }}
        onUpdateCustomerUser={(updatedUser) => {
          if (currentUser?.id === updatedUser.id) {
            setCurrentUser(updatedUser);
            try {
              localStorage.setItem('sda_customer_user', JSON.stringify(updatedUser));
            } catch {
              // ignore
            }
          }
        }}
      />

      {/* AI Dental Assistant Floating Chatbot */}
      <DentalChatbot
        onNavigateToTab={setCurrentTab}
        isOpenExternal={isChatbotOpen}
        onCloseExternal={() => setIsChatbotOpen(false)}
      />
    </div>
  );
}
