import React, { useState, useEffect } from 'react';
import { DOCTOR_INFO } from '../data/dentalData';
import { 
  HeartHandshake, 
  Clock, 
  Play, 
  Pause, 
  RotateCcw, 
  Phone, 
  MessageCircle, 
  AlertTriangle, 
  CheckCircle2, 
  XCircle,
  HelpCircle,
  ShieldAlert
} from 'lucide-react';

export const PostOpCareGuide: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<'extraction' | 'rct' | 'filling' | 'whitening'>('extraction');
  
  // Interactive Gauze Pressure Timer
  const [timerSeconds, setTimerSeconds] = useState<number>(1800); // 30 minutes = 1800s
  const [isTimerRunning, setIsTimerRunning] = useState<boolean>(false);

  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isTimerRunning && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds(prev => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setIsTimerRunning(false);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isTimerRunning, timerSeconds]);

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const resetTimer = (totalSec = 1800) => {
    setIsTimerRunning(false);
    setTimerSeconds(totalSec);
  };

  const categories = [
    { id: 'extraction', label: 'Tooth Extraction / Surgery' },
    { id: 'rct', label: 'Root Canal Therapy' },
    { id: 'filling', label: 'Composite Filling & Crown' },
    { id: 'whitening', label: 'Post-Whitening White Diet' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <HeartHandshake className="w-5 h-5 text-teal-600" />
              Post-Operative Recovery & Home Care Guide
            </h3>
            <span className="text-xs bg-emerald-50 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
              Dr. Swati R Emaliya Protocol
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Follow these clinically verified instructions to ensure rapid healing, clot protection, and pain-free recovery.
          </p>
        </div>

        <a
          href={`tel:${DOCTOR_INFO.phone}`}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-rose-50 text-rose-800 border border-rose-200 text-xs font-bold hover:bg-rose-100 transition shadow-2xs"
        >
          <Phone className="w-4 h-4 text-rose-600" />
          <span>Emergency Call: {DOCTOR_INFO.phone}</span>
        </a>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
        {categories.map(cat => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id as any)}
            className={`px-4 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap transition border ${
              selectedCategory === cat.id
                ? 'bg-[#00685F] text-white border-[#00685F] shadow-2xs'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Extraction & Surgery Instructions */}
      {selectedCategory === 'extraction' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Do's and Don'ts */}
            <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
              <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
                Critical 24-Hour Recovery Rules
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* DO's */}
                <div className="bg-emerald-50/60 rounded-xl p-4 border border-emerald-200 space-y-2.5">
                  <span className="text-xs font-bold text-emerald-800 flex items-center gap-1.5 uppercase">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" /> What You MUST Do:
                  </span>
                  <ul className="text-xs text-slate-700 space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>Bite firmly on the sterile gauze pack for a full 45 minutes to form a protective blood clot.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>Swallow your saliva normally; do NOT spit forcefully.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>Apply ice pack to the outer cheek in 15-min intervals during the first 6 hours to minimize swelling.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>Stick to cool, soft foods (ice cream, yogurt, lukewarm smoothies, mashed potatoes).</span>
                    </li>
                  </ul>
                </div>

                {/* DONT's */}
                <div className="bg-rose-50/60 rounded-xl p-4 border border-rose-200 space-y-2.5">
                  <span className="text-xs font-bold text-rose-800 flex items-center gap-1.5 uppercase">
                    <XCircle className="w-4 h-4 text-rose-600" /> What to AVOID (Prevent Dry Socket):
                  </span>
                  <ul className="text-xs text-slate-700 space-y-2">
                    <li className="flex items-start gap-2">
                      <span className="text-rose-600 font-bold">✕</span>
                      <span><strong>NO Straws:</strong> Suction will dislodge the healing clot and cause agonizing dry socket.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-rose-600 font-bold">✕</span>
                      <span><strong>NO Smoking or Vaping:</strong> Nicotine impairs micro-circulation for 72 hours.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-rose-600 font-bold">✕</span>
                      <span><strong>NO Hot or Spicy Foods:</strong> Avoid hot soups, crunchy chips, and seeds.</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-rose-600 font-bold">✕</span>
                      <span><strong>NO Heavy Strenuous Exercise:</strong> Rest with your head slightly elevated on pillows.</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive Gauze Pressure Countdown Timer */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-slate-900 to-teal-950 text-white rounded-2xl p-6 shadow-md text-center space-y-4 border border-teal-800/40">
              <div className="flex items-center justify-center gap-2">
                <Clock className="w-4 h-4 text-teal-400" />
                <span className="text-xs font-bold uppercase tracking-wider text-teal-200">
                  Gauze Pressure Timer
                </span>
              </div>

              {/* Big Timer Display */}
              <div className="text-4xl font-mono font-bold tracking-tight text-white py-2">
                {formatTimer(timerSeconds)}
              </div>

              <p className="text-[11px] text-teal-200/80 max-w-xs mx-auto">
                Bite down steadily on sterile gauze. Keep firm, continuous jaw pressure until timer finishes.
              </p>

              {/* Timer Buttons */}
              <div className="flex items-center justify-center gap-2 pt-2">
                <button
                  onClick={() => setIsTimerRunning(!isTimerRunning)}
                  className="px-4 py-2 rounded-xl bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold transition flex items-center gap-1.5 shadow-sm active:scale-95"
                >
                  {isTimerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  <span>{isTimerRunning ? 'Pause' : 'Start Timer'}</span>
                </button>
                <button
                  onClick={() => resetTimer(1800)}
                  className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-medium transition"
                  title="Reset to 30 mins"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => resetTimer(2700)}
                  className="px-2.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-teal-200 text-xs font-mono"
                  title="Set 45 mins"
                >
                  45m
                </button>
              </div>
            </div>

            {/* Quick Clinic Assistance */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 text-xs space-y-3">
              <span className="font-bold text-slate-800 block">Need Immediate Reassurance?</span>
              <p className="text-slate-600">
                Mild pink oozing is normal. If bright red active blood fills your mouth after changing gauze twice, notify Dr. Swati immediately.
              </p>
              <a
                href={`https://wa.me/${DOCTOR_INFO.whatsapp.replace(/\D/g, '')}?text=Dr.%20Swati%2C%20I%20have%20a%20question%20regarding%20post-extraction%20healing.`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 text-teal-800 hover:text-teal-900 font-semibold"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                <span>Chat with Clinic on WhatsApp</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Root Canal Care */}
      {selectedCategory === 'rct' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4 max-w-3xl">
          <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Post-Endodontic (Root Canal) Care
          </h4>
          <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
            <p>
              • <strong>Numbness:</strong> Your lip and cheek will remain numb for 2 to 3 hours. Avoid chewing or drinking hot tea until sensation fully returns to prevent biting your tongue.
            </p>
            <p>
              • <strong>Mild Tenderness:</strong> The ligament around the treated tooth root may feel bruised when tapping teeth together for 48 to 72 hours. This is normal healing inflammation.
            </p>
            <p>
              • <strong>Temporary Restoration:</strong> Avoid chewing hard nuts, ice, or sticky candy on that side until Dr. Swati places your permanent CAD/CAM ceramic crown.
            </p>
            <p>
              • <strong>Prescribed Medication:</strong> Take pain relievers as directed by Dr. Swati. Ibuprofen 400mg taken before the local numbness wears off provides optimal relief.
            </p>
          </div>
        </div>
      )}

      {/* Filling & Crown */}
      {selectedCategory === 'filling' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4 max-w-3xl">
          <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Composite Restorations & Dental Crowns
          </h4>
          <div className="space-y-3 text-xs text-slate-700 leading-relaxed">
            <p>
              • <strong>Instant Cure:</strong> Modern light-cured composite resin is 100% hardened before you leave the dental chair. You can eat once the local numbness has completely worn off.
            </p>
            <p>
              • <strong>Cold & Temperature Sensitivity:</strong> Enamel and dentin may have slight thermal sensitivity for 3 to 7 days. Use sensitive toothpaste (potassium nitrate) to soothe the tooth.
            </p>
            <p>
              • <strong>Bite Check:</strong> If the tooth feels "high" or hits first when closing your jaw, please call us for a complimentary 2-minute bite micro-adjustment with Dr. Swati.
            </p>
          </div>
        </div>
      )}

      {/* Whitening White Diet */}
      {selectedCategory === 'whitening' && (
        <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4 max-w-3xl">
          <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            The 48-Hour "White Diet" Rule
          </h4>
          <p className="text-xs text-slate-600">
            For 48 hours following laser whitening, your enamel pores are open and receptive to staining pigments. Stick to the White Diet to maximize brightness.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5 text-xs">
              <span className="font-bold text-emerald-800 block">Safe Foods:</span>
              <p className="text-slate-700">White rice, plain chicken, white fish, steamed cauliflower, egg whites, milk, bananas, water, yogurt.</p>
            </div>
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-1.5 text-xs">
              <span className="font-bold text-rose-800 block">Strictly Avoid for 48 hrs:</span>
              <p className="text-slate-700">Coffee, black tea, red wine, turmeric curry, dark soy sauce, cola, berries, smoking, dark lipstick.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
