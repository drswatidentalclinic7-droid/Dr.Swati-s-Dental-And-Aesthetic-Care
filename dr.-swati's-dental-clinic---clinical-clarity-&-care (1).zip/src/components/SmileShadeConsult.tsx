import React, { useState } from 'react';
import { VITA_SHADES, DOCTOR_INFO } from '../data/dentalData';
import { Sparkles, Check, ArrowRight, ShieldCheck, Smile, HelpCircle } from 'lucide-react';

interface SmileShadeConsultProps {
  onBookCosmetic?: () => void;
}

export const SmileShadeConsult: React.FC<SmileShadeConsultProps> = ({
  onBookCosmetic
}) => {
  const [currentShade, setCurrentShade] = useState<string>('A3');
  const [targetShade, setTargetShade] = useState<string>('B1');
  const [selectedGoals, setSelectedGoals] = useState<string[]>([
    'Brighter, Whiter Smile (Laser Whitening)',
    'Porcelain Veneers / Edge Smoothing'
  ]);

  const currentObj = VITA_SHADES.find(s => s.code === currentShade) || VITA_SHADES[5];
  const targetObj = VITA_SHADES.find(s => s.code === targetShade) || VITA_SHADES[0];

  const shadeJumpCount = Math.abs(
    VITA_SHADES.findIndex(s => s.code === currentShade) -
    VITA_SHADES.findIndex(s => s.code === targetShade)
  );

  const toggleGoal = (goal: string) => {
    setSelectedGoals(prev =>
      prev.includes(goal) ? prev.filter(g => g !== goal) : [...prev, goal]
    );
  };

  const cosmeticGoals = [
    'Brighter, Whiter Smile (Laser Whitening)',
    'Close Space / Gaps between Front Teeth',
    'Straighten Mild Crowding (Clear Aligners)',
    'Fix Chipped, Worn or Uneven Edges',
    'Porcelain Veneers / Hollywood Smile Makeover',
    'Gummy Smile Reduction / Laser Gum Contouring'
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              Digital Smile Assessment & Shade Guide
            </h3>
            <span className="text-xs bg-amber-50 text-amber-800 font-semibold px-2.5 py-0.5 rounded-full border border-amber-200">
              VITA Classical Standard
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Compare enamel shade grades, simulate whitening outcomes, and customize your aesthetic smile transformation.
          </p>
        </div>

        {onBookCosmetic && (
          <button
            onClick={onBookCosmetic}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#00685F] text-white text-xs font-bold hover:bg-[#005049] transition shadow-xs"
          >
            <span>Book Smile Design Visit</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Interactive Shade Comparison Matrix */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-6">
        <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          1. Tooth Enamel Shade Calibration
        </h4>

        {/* Live Comparison Split Preview */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-5 rounded-2xl border border-slate-200">
          {/* Current Shade Card */}
          <div className="bg-white rounded-xl p-4 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-500 uppercase">Current Baseline Shade</span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">
                {currentObj.code}
              </span>
            </div>

            <div className="flex items-center gap-4">
              {/* Tooth Silhouette Swatch */}
              <div
                className="w-16 h-20 rounded-xl border border-slate-300 shadow-inner flex items-center justify-center relative"
                style={{ backgroundColor: currentObj.hex }}
              >
                <span className="text-xs font-bold text-slate-900/60 font-mono">
                  {currentObj.code}
                </span>
              </div>
              <div className="space-y-1">
                <h5 className="text-sm font-bold text-slate-900">{currentObj.title}</h5>
                <p className="text-xs text-slate-500">{currentObj.undertone}</p>
                <span className="text-[11px] text-slate-400 block">Relative Lightness: {currentObj.lightness}%</span>
              </div>
            </div>
          </div>

          {/* Target Desired Shade Card */}
          <div className="bg-white rounded-xl p-4 border border-teal-200 space-y-3 ring-2 ring-teal-500/10">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-teal-800 uppercase flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" /> Target Smile Shade
              </span>
              <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-teal-50 text-teal-900 border border-teal-200">
                {targetObj.code}
              </span>
            </div>

            <div className="flex items-center gap-4">
              {/* Tooth Silhouette Swatch */}
              <div
                className="w-16 h-20 rounded-xl border border-teal-300 shadow-md flex items-center justify-center relative"
                style={{ backgroundColor: targetObj.hex }}
              >
                <span className="text-xs font-bold text-slate-900/70 font-mono">
                  {targetObj.code}
                </span>
              </div>
              <div className="space-y-1">
                <h5 className="text-sm font-bold text-slate-900">{targetObj.title}</h5>
                <p className="text-xs text-slate-500">{targetObj.undertone}</p>
                <span className="text-[11px] text-teal-800 font-semibold block">
                  +{shadeJumpCount * 2} Shades Noticeable Brightening!
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Vita Shade Swatch Strip */}
        <div>
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
            Select Your Current Tooth Shade:
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            {VITA_SHADES.map(s => {
              const isSelected = s.code === currentShade;
              return (
                <button
                  key={s.code}
                  type="button"
                  onClick={() => setCurrentShade(s.code)}
                  className={`p-2 rounded-xl border text-center transition ${
                    isSelected
                      ? 'ring-2 ring-[#00685F] border-[#00685F] shadow-xs'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                  style={{ backgroundColor: s.hex }}
                >
                  <span className="text-xs font-bold text-slate-900 block font-mono">
                    {s.code}
                  </span>
                  <span className="text-[9px] text-slate-700 block truncate">
                    {s.title.split(' ')[0]}
                  </span>
                  {isSelected && (
                    <span className="text-[10px] font-bold text-teal-900 block mt-0.5">
                      ✓ Current
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
            Select Your Desired Target Shade:
          </label>
          <div className="grid grid-cols-3 sm:grid-cols-9 gap-2">
            {VITA_SHADES.map(s => {
              const isSelected = s.code === targetShade;
              return (
                <button
                  key={s.code}
                  type="button"
                  onClick={() => setTargetShade(s.code)}
                  className={`p-2 rounded-xl border text-center transition ${
                    isSelected
                      ? 'ring-2 ring-amber-500 border-amber-500 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                  style={{ backgroundColor: s.hex }}
                >
                  <span className="text-xs font-bold text-slate-900 block font-mono">
                    {s.code}
                  </span>
                  <span className="text-[9px] text-slate-700 block truncate">
                    {s.title.split(' ')[0]}
                  </span>
                  {isSelected && (
                    <span className="text-[10px] font-bold text-amber-900 block mt-0.5">
                      ★ Goal
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Smile Goals Multi-Select */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
        <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
          2. Personal Aesthetic Smile Priorities
        </h4>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {cosmeticGoals.map(goal => {
            const isChecked = selectedGoals.includes(goal);
            return (
              <button
                key={goal}
                type="button"
                onClick={() => toggleGoal(goal)}
                className={`p-3.5 rounded-xl border text-left text-xs font-semibold transition flex items-center justify-between ${
                  isChecked
                    ? 'bg-teal-50/70 border-[#0D9488] text-teal-900 shadow-2xs'
                    : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                }`}
              >
                <span>{goal}</span>
                <span className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 border ${
                  isChecked ? 'bg-[#00685F] text-white border-[#00685F]' : 'border-slate-300'
                }`}>
                  {isChecked && <Check className="w-2.5 h-2.5" />}
                </span>
              </button>
            );
          })}
        </div>

        {/* Aesthetic Plan Recommendation by Dr. Swati */}
        <div className="p-4 rounded-2xl bg-gradient-to-br from-teal-50 to-emerald-50 border border-teal-200 space-y-2 mt-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-teal-700 shrink-0" />
            <h5 className="text-xs font-bold text-teal-950 uppercase tracking-wider">
              Dr. Swati R Emaliya's Aesthetic Assessment
            </h5>
          </div>
          <p className="text-xs text-teal-900 leading-relaxed">
            Targeting a transition from <strong>{currentShade}</strong> to <strong>{targetShade}</strong> is safely achievable using our in-office Cold-Light Laser Whitening protocol (single 60-minute visit), paired with customized take-home remineralizing trays to lock in brightness with zero sensitivity.
          </p>
        </div>
      </div>
    </div>
  );
};
