import React, { useState } from 'react';
import { DOCTOR_INFO } from '../data/dentalData';
import { AppointmentSlot } from '../types/dental';
import { 
  Calendar as CalendarIcon, 
  Clock, 
  CheckCircle2, 
  User, 
  Phone, 
  Mail, 
  AlertCircle,
  FileCheck,
  MessageCircle
} from 'lucide-react';

interface AppointmentBookingProps {
  onAppointmentBooked: (slot: AppointmentSlot) => void;
  defaultPatientName?: string;
  defaultPhone?: string;
  defaultEmail?: string;
  onNavigateToIntake?: () => void;
}

export const AppointmentBooking: React.FC<AppointmentBookingProps> = ({
  onAppointmentBooked,
  defaultPatientName = 'Sarah Jenkins',
  defaultPhone = '+1 (555) 392-8841',
  defaultEmail = 'sarah.jenkins@example.com',
  onNavigateToIntake
}) => {
  const [selectedDate, setSelectedDate] = useState<string>(() => {
    const today = new Date();
    return today.toISOString().split('T')[0];
  });
  const [selectedTime, setSelectedTime] = useState<string>('05:30 PM');
  const [patientName, setPatientName] = useState<string>(defaultPatientName);
  const [patientPhone, setPatientPhone] = useState<string>(defaultPhone);
  const [patientEmail, setPatientEmail] = useState<string>(defaultEmail);
  const [notes, setNotes] = useState<string>('');
  const [confirmedBooking, setConfirmedBooking] = useState<AppointmentSlot | null>(null);
  const [bookingError, setBookingError] = useState<string>('');

  // Generate next 6 selectable clinical days
  const dateOptions = Array.from({ length: 6 }).map((_, idx) => {
    const d = new Date();
    d.setDate(d.getDate() + idx);
    const dateStr = d.toISOString().split('T')[0];
    const dayName = idx === 0 ? 'Today' : idx === 1 ? 'Tomorrow' : d.toLocaleDateString('en-US', { weekday: 'short' });
    const formatted = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    return { dateStr, dayName, formatted };
  });

  const eveningSlots = ['05:00 PM', '05:30 PM', '06:00 PM', '06:30 PM', '07:00 PM', '07:30 PM', '08:00 PM', '08:15 PM'];

  const handleConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingError('');
    if (!patientName.trim() || !patientPhone.trim()) {
      setBookingError('Please provide your name and phone number to schedule your appointment.');
      return;
    }

    const slot: AppointmentSlot = {
      id: `APT-${Math.floor(10000 + Math.random() * 90000)}`,
      serviceId: 'consultation',
      serviceName: 'In-Clinic Dental & Aesthetic Consultation',
      doctorName: DOCTOR_INFO.name,
      date: selectedDate,
      time: selectedTime,
      durationMinutes: 45,
      status: 'confirmed',
      patientName,
      phone: patientPhone,
      email: patientEmail,
      notes
    };

    setConfirmedBooking(slot);
    onAppointmentBooked(slot);
  };

  if (confirmedBooking) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm text-center max-w-xl mx-auto space-y-6">
        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border-2 border-emerald-200">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div>
          <span className="text-xs font-mono font-bold tracking-wider px-3 py-1 rounded-full bg-teal-50 text-teal-800 border border-teal-200">
            APPOINTMENT CONFIRMED • PASS #{confirmedBooking.id}
          </span>
          <h3 className="text-2xl font-bold text-slate-900 mt-3">
            You're All Scheduled with Dr. Swati R Emaliya!
          </h3>
          <p className="text-sm text-slate-600 mt-1">
            A confirmation mail is sent to your registered mail id.
          </p>
        </div>

        {/* Appointment Pass Card */}
        <div className="bg-gradient-to-br from-slate-50 to-teal-50/40 rounded-2xl p-5 border border-teal-100 text-left space-y-3 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-teal-500/5 rounded-bl-full pointer-events-none" />
          
          <div className="flex items-center justify-between pb-3 border-b border-slate-200/80">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-[#00685F] text-white flex items-center justify-center font-bold text-sm shadow-xs">
                SG
              </div>
              <div>
                <h4 className="text-sm font-bold text-slate-900">{DOCTOR_INFO.name}</h4>
                <p className="text-[11px] text-teal-800 font-medium">{DOCTOR_INFO.role}</p>
              </div>
            </div>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-100/80 px-2.5 py-0.5 rounded-full">
              Confirmed
            </span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Appointment</span>
              <span className="font-semibold text-slate-800">{confirmedBooking.serviceName}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Date & Time</span>
              <span className="font-semibold text-slate-800">{confirmedBooking.date} at {confirmedBooking.time}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Patient</span>
              <span className="font-semibold text-slate-800">{confirmedBooking.patientName}</span>
            </div>
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Phone</span>
              <span className="font-semibold text-slate-800">{confirmedBooking.phone}</span>
            </div>
          </div>

          <div className="pt-2 text-[11px] text-slate-500 flex items-center gap-1.5 border-t border-slate-200/60">
            <Clock className="w-3.5 h-3.5 text-teal-600 shrink-0" />
            <span>Clinic check-in 10 minutes prior for digital intake verification.</span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          {onNavigateToIntake && (
            <button
              onClick={onNavigateToIntake}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#00685F] text-white text-xs font-bold hover:bg-[#005049] transition shadow-xs"
            >
              <FileCheck className="w-4 h-4" />
              Complete Digital Medical Intake
            </button>
          )}

          <a
            href={`https://wa.me/${DOCTOR_INFO.whatsapp.replace(/\D/g, '')}?text=Hi%20Dr.%20Swati%2C%20I%20have%20confirmed%20my%20appointment%20%23${confirmedBooking.id}%20for%20${confirmedBooking.date}%20at%20${confirmedBooking.time}.`}
            target="_blank"
            rel="noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-emerald-300 text-emerald-800 text-xs font-semibold hover:bg-emerald-50 transition"
          >
            <MessageCircle className="w-4 h-4 text-emerald-600" />
            WhatsApp Notification
          </a>

          <button
            onClick={() => setConfirmedBooking(null)}
            className="w-full sm:w-auto text-xs text-slate-500 hover:text-slate-700 font-medium py-2"
          >
            Book Another Visit
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight">
              Clinical Appointment Scheduler
            </h3>
            <span className="text-xs bg-emerald-50 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200">
              Dr. Swati R Emaliya, BDS
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Choose a treatment, select your preferred date, and secure your personalized dental consultation.
          </p>
        </div>

        {/* Emergency Quick-Contact Pill */}
        <a
          href={`tel:${DOCTOR_INFO.phone}`}
          className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-rose-50 text-rose-800 border border-rose-200 text-xs font-semibold hover:bg-rose-100 transition shadow-2xs"
        >
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>Dental Emergency? Call Clinic Directly</span>
        </a>
      </div>

      <form onSubmit={handleConfirm} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Date & Time Slot */}
        <div className="lg:col-span-2 space-y-6">
          {/* Section: Date & Slot Selection */}
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-5">
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-3">
                1. Select Date
              </label>
              
              <div className="grid grid-cols-3 sm:grid-cols-6 gap-2">
                {dateOptions.map((opt) => {
                  const isSelected = opt.dateStr === selectedDate;
                  return (
                    <button
                      key={opt.dateStr}
                      type="button"
                      onClick={() => setSelectedDate(opt.dateStr)}
                      className={`p-3 rounded-xl text-center transition border ${
                        isSelected
                          ? 'bg-[#00685F] text-white border-[#00685F] shadow-xs'
                          : 'bg-white hover:bg-slate-50 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span className="text-[10px] uppercase font-bold block opacity-75">{opt.dayName}</span>
                      <span className="text-sm font-bold block mt-0.5">{opt.formatted}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Slot Picker */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                2. Choose Time Slot
              </label>

              <div className="space-y-3">
                {/* Evening Slots (Mon-Sat 5:00 PM - 8:30 PM) */}
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[11px] font-semibold text-slate-500">
                      Evening Consultation Slots (5:00 PM – 8:30 PM)
                    </span>
                    <span className="text-[10px] text-teal-700 bg-teal-50 px-2 py-0.5 rounded font-medium border border-teal-100">
                      Mon – Sat
                    </span>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {eveningSlots.map(slot => (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => setSelectedTime(slot)}
                        className={`px-3 py-2 rounded-lg text-xs font-semibold transition border text-center ${
                          selectedTime === slot
                            ? 'bg-[#00685F] text-white border-[#00685F] shadow-xs ring-2 ring-[#00685F]/20'
                            : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sunday On-Call Banner */}
                <div className="p-2.5 rounded-xl bg-amber-50/70 border border-amber-200/80 flex items-center justify-between gap-2 text-xs">
                  <div className="text-amber-800">
                    <span className="font-semibold">Sunday Priority:</span> Available on call for urgent treatments & scheduled procedures.
                  </div>
                  <button
                    type="button"
                    onClick={() => setSelectedTime('Sunday On-Call (Priority)')}
                    className={`px-2.5 py-1 rounded-lg text-[11px] font-bold shrink-0 transition border ${
                      selectedTime === 'Sunday On-Call (Priority)'
                        ? 'bg-amber-600 text-white border-amber-600'
                        : 'bg-white text-amber-900 border-amber-200 hover:bg-amber-100'
                    }`}
                  >
                    Select On-Call
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Col: Patient Confirmation & Summary Box */}
        <div className="space-y-5">
          <div className="bg-white rounded-2xl p-5 sm:p-6 border border-slate-200 shadow-sm space-y-4">
            <h4 className="text-base font-bold text-slate-900 border-b border-slate-100 pb-3">
              Patient Contact Info
            </h4>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Your Full Name *</label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    required
                    value={patientName}
                    onChange={e => setPatientName(e.target.value)}
                    placeholder="Patient Name"
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-xs transition"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Mobile Phone Number *</label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="tel"
                    required
                    value={patientPhone}
                    onChange={e => setPatientPhone(e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-xs transition"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Email (Optional)</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="email"
                    value={patientEmail}
                    onChange={e => setPatientEmail(e.target.value)}
                    placeholder="sarah.jenkins@example.com"
                    className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-xs transition"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Notes for Dr. Swati (Optional)</label>
                <textarea
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  placeholder="Any particular tooth hurting, allergy notes, or anxiety requests..."
                  rows={2}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-[#0D9488] outline-none text-xs transition"
                />
              </div>
            </div>

            {/* Visit Summary Card */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Doctor:</span>
                <span className="font-semibold text-slate-800">{DOCTOR_INFO.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Appointment Type:</span>
                <span className="font-semibold text-slate-800">In-Clinic Consultation</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Date & Slot:</span>
                <span className="font-semibold text-teal-800">{selectedDate} @ {selectedTime}</span>
              </div>
            </div>

            {/* Error Message */}
            {bookingError && (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{bookingError}</span>
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full py-3 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-xs active:scale-95 transition flex items-center justify-center gap-2"
            >
              <CalendarIcon className="w-4 h-4" />
              Confirm Clinical Appointment
            </button>

            <p className="text-[10px] text-center text-slate-400">
              No advance payment required. Free cancellation up to 4 hours prior.
            </p>
          </div>
        </div>
      </form>
    </div>
  );
};
