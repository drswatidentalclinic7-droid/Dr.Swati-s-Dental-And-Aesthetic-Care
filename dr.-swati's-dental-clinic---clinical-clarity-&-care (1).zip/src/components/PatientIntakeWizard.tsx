import React, { useState } from 'react';
import { PatientIntakeData } from '../types/dental';
import { 
  ALLERGY_OPTIONS, 
  MEDICAL_CONDITION_OPTIONS, 
  DENTAL_SYMPTOM_OPTIONS 
} from '../data/dentalData';
import { ConsentSignaturePad } from './ConsentSignaturePad';
import { 
  User, 
  Heart, 
  AlertTriangle, 
  FileText, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  Smile, 
  ShieldCheck, 
  Sparkles,
  Printer,
  Download
} from 'lucide-react';

interface PatientIntakeWizardProps {
  onComplete: (data: PatientIntakeData) => void;
  onNavigateToBooking?: () => void;
}

export const PatientIntakeWizard: React.FC<PatientIntakeWizardProps> = ({
  onComplete,
  onNavigateToBooking
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isSubmitted, setIsSubmitted] = useState<boolean>(false);
  const [intakeId, setIntakeId] = useState<string>('');

  const [formData, setFormData] = useState<PatientIntakeData>({
    fullName: 'Sarah Jenkins',
    dateOfBirth: '1994-06-18',
    gender: 'Female',
    phone: '+1 (555) 392-8841',
    email: 'sarah.jenkins@example.com',
    address: '428 Greenwood Ave, Apt 3B',
    hasInsurance: false,
    insuranceProvider: '',
    policyNumber: '',
    groupNumber: '',
    dentalAnxietyScore: 2,
    allergies: ['Latex'],
    medicalConditions: ['None of the above'],
    medications: 'Daily Vitamin D3 (None prescription)',
    isPregnant: false,
    hasPreviousComplications: false,
    complicationsDetails: '',
    primaryConcern: 'Routine checkup & hygiene with mild sensitivity on upper right molar',
    painLevel: 2,
    symptoms: ['Sharp toothache with cold/hot liquids', 'Routine checkup & hygiene only'],
    symptomDuration: 'Past 2 weeks',
    consentSigned: false,
    signatureDataUrl: '',
    consentDate: new Date().toLocaleDateString('en-US'),
    privacyNoticeAcknowledged: true,
  });

  const steps = [
    { number: 1, title: 'Patient Profile', icon: User },
    { number: 2, title: 'Comfort & Anxiety', icon: Smile },
    { number: 3, title: 'Medical History', icon: Heart },
    { number: 4, title: 'Dental Concern', icon: AlertTriangle },
    { number: 5, title: 'Consent & Sign', icon: FileText },
  ];

  const updateField = <K extends keyof PatientIntakeData>(field: K, value: PatientIntakeData[K]) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleAllergy = (allergy: string) => {
    if (allergy === 'No Known Drug Allergies (NKDA)') {
      updateField('allergies', ['No Known Drug Allergies (NKDA)']);
      return;
    }
    const current = formData.allergies.filter(a => a !== 'No Known Drug Allergies (NKDA)');
    const exists = current.includes(allergy);
    const updated = exists ? current.filter(a => a !== allergy) : [...current, allergy];
    updateField('allergies', updated.length > 0 ? updated : ['No Known Drug Allergies (NKDA)']);
  };

  const toggleCondition = (cond: string) => {
    if (cond === 'None of the above') {
      updateField('medicalConditions', ['None of the above']);
      return;
    }
    const current = formData.medicalConditions.filter(c => c !== 'None of the above');
    const exists = current.includes(cond);
    const updated = exists ? current.filter(c => c !== cond) : [...current, cond];
    updateField('medicalConditions', updated.length > 0 ? updated : ['None of the above']);
  };

  const toggleSymptom = (sym: string) => {
    const exists = formData.symptoms.includes(sym);
    const updated = exists ? formData.symptoms.filter(s => s !== sym) : [...formData.symptoms, sym];
    updateField('symptoms', updated);
  };

  const handleSignatureCaptured = (dataUrl: string, isValid: boolean) => {
    updateField('signatureDataUrl', dataUrl);
    updateField('consentSigned', isValid);
  };

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep(prev => prev + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      // Final Submit
      const generatedId = `SDA-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;
      setIntakeId(generatedId);
      setIsSubmitted(true);
      onComplete(formData);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Anxiety description helper
  const getAnxietyDescription = (score: number) => {
    switch (score) {
      case 1:
        return { text: "Completely Relaxed", desc: "You feel comfortable with all standard dental procedures.", color: "text-emerald-700 bg-emerald-50 border-emerald-200" };
      case 2:
        return { text: "Mild Apprehension", desc: "A little uneasy about needles or scraping, but manageable.", color: "text-teal-700 bg-teal-50 border-teal-200" };
      case 3:
        return { text: "Moderate Anxiety", desc: "Noticeable nervousness. Dr. Swati will explain every step and pause anytime.", color: "text-amber-700 bg-amber-50 border-amber-200" };
      case 4:
        return { text: "High Dental Fear", desc: "Heart rate increases, past bad dental experience. Extra numbing & calming pacing provided.", color: "text-orange-700 bg-orange-50 border-orange-200" };
      case 5:
        return { text: "Severe Phobia", desc: "Panic or avoidance. We offer full anxiety-free protocol, noise-canceling headphones, and gentle touch.", color: "text-rose-700 bg-rose-50 border-rose-200" };
      default:
        return { text: "Neutral", desc: "", color: "" };
    }
  };

  if (isSubmitted) {
    return (
      <div className="bg-white rounded-2xl border border-slate-200 p-6 sm:p-8 shadow-sm text-center max-w-2xl mx-auto space-y-6">
        <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto border-2 border-emerald-200">
          <CheckCircle2 className="w-10 h-10" />
        </div>

        <div>
          <span className="text-xs font-mono font-bold tracking-wider px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
            INTAKE RECORD VERIFIED #{intakeId}
          </span>
          <h2 className="text-2xl font-bold text-slate-900 mt-3">
            Digital Medical Intake Completed!
          </h2>
          <p className="text-sm text-slate-600 mt-1 max-w-md mx-auto">
            Thank you, <strong className="text-slate-800">{formData.fullName}</strong>. Your medical history, allergy profile, and signed consent have been secured into Dr. Swati's Dental And Aesthetic Care clinical portal.
          </p>
        </div>

        {/* Verification Summary Card */}
        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 text-left text-xs space-y-2 max-w-md mx-auto">
          <div className="flex justify-between">
            <span className="text-slate-500">Patient:</span>
            <span className="font-semibold text-slate-800">{formData.fullName} (DOB: {formData.dateOfBirth})</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Primary Phone:</span>
            <span className="font-semibold text-slate-800">{formData.phone}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Allergies:</span>
            <span className="font-semibold text-rose-700">{formData.allergies.join(', ')}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Anxiety Protocol:</span>
            <span className="font-semibold text-teal-800">Level {formData.dentalAnxietyScore}/5 ({getAnxietyDescription(formData.dentalAnxietyScore).text})</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Consent Signature:</span>
            <span className="font-semibold text-emerald-700">Digital Record Attached</span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
          <button
            onClick={() => window.print()}
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 text-xs font-semibold transition"
          >
            <Printer className="w-4 h-4" />
            Print / Save PDF Copy
          </button>
          {onNavigateToBooking && (
            <button
              onClick={onNavigateToBooking}
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#00685F] text-white hover:bg-[#005049] text-xs font-semibold shadow-xs transition"
            >
              <span>Schedule Doctor Visit</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => {
              setIsSubmitted(false);
              setCurrentStep(1);
            }}
            className="w-full sm:w-auto text-xs text-slate-500 hover:text-slate-700 font-medium py-2"
          >
            Edit Intake Form
          </button>
        </div>
      </div>
    );
  }

  const anxietyMeta = getAnxietyDescription(formData.dentalAnxietyScore);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
      {/* Wizard Header & Progress Bar */}
      <div style={{ backgroundColor: '#d1d1ec' }} className="p-4 sm:p-5 border-b border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-teal-700 uppercase tracking-wider">
                Step {currentStep} of 5
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-slate-300" />
              <h3 className="text-base font-bold text-slate-900">
                {steps[currentStep - 1].title}
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Secure patient intake & clinical questionnaire for Dr. Swati's Dental And Aesthetic Care.
            </p>
          </div>

          {/* Step Pills for Desktop */}
          <div className="hidden sm:flex items-center gap-1.5">
            {steps.map(s => {
              const Icon = s.icon;
              const isActive = s.number === currentStep;
              const isPast = s.number < currentStep;
              return (
                <div
                  key={s.number}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium transition ${
                    isActive
                      ? 'bg-[#00685F] text-white shadow-xs'
                      : isPast
                      ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                      : 'bg-white text-slate-400 border border-slate-200'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{s.title.split(' ')[0]}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Visual Progress Bar */}
        <div className="w-full bg-slate-200 h-1.5 rounded-full mt-4 overflow-hidden">
          <div
            className="bg-gradient-to-r from-[#00685F] to-[#06B6D4] h-full transition-all duration-300 ease-out"
            style={{ width: `${(currentStep / 5) * 100}%` }}
          />
        </div>
      </div>

      {/* Wizard Step Body */}
      <div style={{ backgroundColor: '#e9f1ef' }} className="p-5 sm:p-7 space-y-6">
        {/* STEP 1: Personal & Demographic Info */}
        {currentStep === 1 && (
          <div className="space-y-4 max-w-xl mx-auto">
            <div className="space-y-1">
              <h4 className="text-base font-bold text-slate-900">Patient Personal Details</h4>
              <p className="text-xs text-slate-500">Please provide your contact information for clinical records and appointment reminders.</p>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Full Legal Name *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={e => updateField('fullName', e.target.value)}
                  placeholder="e.g. Sarah Jenkins"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Date of Birth *</label>
                  <input
                    type="date"
                    value={formData.dateOfBirth}
                    onChange={e => updateField('dateOfBirth', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Biological Gender</label>
                  <select
                    value={formData.gender}
                    onChange={e => updateField('gender', e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other / Non-binary</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Phone Number (SMS reminders) *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={e => updateField('phone', e.target.value)}
                    placeholder="+1 (555) 000-0000"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 block mb-1">Email Address</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={e => updateField('email', e.target.value)}
                    placeholder="name@example.com"
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 block mb-1">Residential Address</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={e => updateField('address', e.target.value)}
                  placeholder="Street address, City, Postal Code"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
                />
              </div>
            </div>
          </div>
        )}

        {/* STEP 2: Dental Anxiety & Comfort Assessment */}
        {currentStep === 2 && (
          <div className="space-y-5 max-w-xl mx-auto">
            <div className="space-y-1">
              <h4 className="text-base font-bold text-slate-900">Your Comfort & Anxiety Level</h4>
              <p className="text-xs text-slate-500">
                Dental anxiety is extremely common. Sharing how you feel allows Dr. Swati R Emaliya to tailor pacing, local anesthesia, and gentle comfort protocols.
              </p>
            </div>

            {/* Anxiety Slider with visual scale */}
            <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  How comfortable do you feel in a dental chair?
                </span>
                <span className="text-sm font-bold text-teal-800">
                  {formData.dentalAnxietyScore} / 5
                </span>
              </div>

              <input
                type="range"
                min="1"
                max="5"
                step="1"
                value={formData.dentalAnxietyScore}
                onChange={e => updateField('dentalAnxietyScore', parseInt(e.target.value, 10))}
                className="w-full accent-[#00685F] h-2 bg-slate-200 rounded-lg cursor-pointer"
              />

              <div className="flex justify-between text-[11px] text-slate-400 font-medium px-1">
                <span>1 - Completely Relaxed</span>
                <span>3 - Moderate</span>
                <span>5 - Severe Phobia</span>
              </div>

              {/* Dynamic feedback card */}
              <div className={`p-3.5 rounded-xl border ${anxietyMeta.color} transition-all`}>
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 shrink-0" />
                  <strong className="text-xs font-bold">{anxietyMeta.text}</strong>
                </div>
                <p className="text-xs mt-1 leading-relaxed opacity-90">
                  {anxietyMeta.desc}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* STEP 3: Allergies & Medical History */}
        {currentStep === 3 && (
          <div className="space-y-5 max-w-xl mx-auto">
            <div className="space-y-1">
              <h4 className="text-base font-bold text-slate-900">Allergies & Medical History</h4>
              <p className="text-xs text-slate-500">
                Your medical safety is paramount. Certain medications or conditions influence local anesthesia and dental prescriptions.
              </p>
            </div>

            {/* Allergies multi-select chips */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Allergies to Medications or Materials *
              </label>
              <div className="flex flex-wrap gap-2">
                {ALLERGY_OPTIONS.map((allergy) => {
                  const isSelected = formData.allergies.includes(allergy);
                  return (
                    <button
                      key={allergy}
                      type="button"
                      onClick={() => toggleAllergy(allergy)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold transition border ${
                        isSelected
                          ? allergy.includes('No Known')
                            ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                            : 'bg-rose-100 text-rose-900 border-rose-300 shadow-2xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {isSelected && '✓ '}
                      {allergy}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Medical conditions */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Current or Past Medical Conditions *
              </label>
              <div className="flex flex-wrap gap-2">
                {MEDICAL_CONDITION_OPTIONS.map((cond) => {
                  const isSelected = formData.medicalConditions.includes(cond);
                  return (
                    <button
                      key={cond}
                      type="button"
                      onClick={() => toggleCondition(cond)}
                      className={`px-3 py-1.5 rounded-full text-xs font-semibold transition border ${
                        isSelected
                          ? 'bg-[#00685F] text-white border-[#00685F] shadow-2xs'
                          : 'bg-white text-slate-600 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      {isSelected && '✓ '}
                      {cond}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Current Medications */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                Current Medications, Vitamins, or Supplements
              </label>
              <textarea
                value={formData.medications}
                onChange={e => updateField('medications', e.target.value)}
                placeholder="List any daily prescriptions, blood thinners, blood pressure tablets, or vitamins..."
                rows={2}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-xs transition"
              />
            </div>
          </div>
        )}

        {/* STEP 4: Chief Complaint & Dental Symptoms */}
        {currentStep === 4 && (
          <div className="space-y-5 max-w-xl mx-auto">
            <div className="space-y-1">
              <h4 className="text-base font-bold text-slate-900">Chief Complaint & Dental Symptoms</h4>
              <p className="text-xs text-slate-500">
                Help Dr. Swati R Emaliya understand what brought you in today so we can prioritize your care.
              </p>
            </div>

            {/* Primary Concern Textarea */}
            <div>
              <label className="text-xs font-semibold text-slate-700 block mb-1">
                What is the primary reason for your visit today? *
              </label>
              <textarea
                value={formData.primaryConcern}
                onChange={e => updateField('primaryConcern', e.target.value)}
                placeholder="e.g. Broken tooth on lower left, sharp pain with cold water, desire teeth whitening..."
                rows={3}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-[#0D9488] focus:ring-2 focus:ring-[#06B6D4]/20 outline-none text-sm transition"
              />
            </div>

            {/* Pain Scale (0 to 10) */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Current Pain Level (0 = None, 10 = Severe)
                </span>
                <span className={`text-sm font-bold px-2.5 py-0.5 rounded-full ${
                  formData.painLevel === 0 ? 'bg-emerald-100 text-emerald-800' :
                  formData.painLevel <= 3 ? 'bg-teal-100 text-teal-800' :
                  formData.painLevel <= 6 ? 'bg-amber-100 text-amber-800' :
                  'bg-rose-100 text-rose-800'
                }`}>
                  Level {formData.painLevel} / 10
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="10"
                value={formData.painLevel}
                onChange={e => updateField('painLevel', parseInt(e.target.value, 10))}
                className="w-full accent-[#00685F] h-2 bg-slate-200 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                <span>0 - No pain</span>
                <span>5 - Moderate discomfort</span>
                <span>10 - Unbearable emergency</span>
              </div>
            </div>

            {/* Common Symptoms multi-select */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Check Any Symptoms You Are Experiencing
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {DENTAL_SYMPTOM_OPTIONS.map((sym) => {
                  const isChecked = formData.symptoms.includes(sym);
                  return (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => toggleSymptom(sym)}
                      className={`text-left p-2.5 rounded-xl border text-xs font-medium transition flex items-start gap-2 ${
                        isChecked
                          ? 'bg-teal-50 border-teal-400 text-teal-900 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                      }`}
                    >
                      <span className={`w-3.5 h-3.5 rounded mt-0.5 flex items-center justify-center shrink-0 border ${
                        isChecked ? 'bg-[#00685F] border-[#00685F] text-white' : 'border-slate-300'
                      }`}>
                        {isChecked && '✓'}
                      </span>
                      <span>{sym}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* STEP 5: Digital Consent & Signature */}
        {currentStep === 5 && (
          <div className="space-y-5 max-w-xl mx-auto">
            <div className="space-y-1">
              <h4 className="text-base font-bold text-slate-900">Informed Consent & Medical Verification</h4>
              <p className="text-xs text-slate-500">
                Please review the clinical terms and sign below on your device to authorize diagnostic examination and treatment.
              </p>
            </div>

            {/* Terms Box */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 text-xs text-slate-600 space-y-2 max-h-48 overflow-y-auto scrollbar-thin">
              <p className="font-semibold text-slate-800">
                1. Authorization for Examination & Treatment:
              </p>
              <p>
                I hereby authorize Dr. Swati R Emaliya (BDS Dental Surgeon) and associated dental staff to conduct comprehensive oral examination, take necessary digital radiographs, photograph intraoral conditions, and administer local anesthesia or medications necessary for dental diagnosis and treatment.
              </p>
              <p className="font-semibold text-slate-800">
                2. Medical Accuracy Guarantee:
              </p>
              <p>
                I certify that I have read and answered the medical, allergy, and medication questionnaire truthfully to the best of my knowledge. I understand that withholding medical info could lead to adverse drug reactions.
              </p>
              <p className="font-semibold text-slate-800">
                3. Privacy & HIPAA Compliance:
              </p>
              <p>
                Dental health records and diagnostic charts are maintained confidentially under healthcare privacy guidelines.
              </p>
            </div>

            {/* Checkbox Acknowledgment */}
            <label className="flex items-start gap-2.5 p-3 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.privacyNoticeAcknowledged}
                onChange={e => updateField('privacyNoticeAcknowledged', e.target.checked)}
                className="accent-[#00685F] mt-0.5 rounded"
              />
              <span className="text-xs text-slate-700 leading-relaxed">
                I have read, understood, and accept the informed consent terms, clinic privacy policy, and medical verification disclosure.
              </span>
            </label>

            {/* Interactive Signature Canvas Pad */}
            <ConsentSignaturePad
              signerName={formData.fullName}
              onSignatureChange={handleSignatureCaptured}
            />
          </div>
        )}
      </div>

      {/* Mobile-Ergonomic Bottom Action Bar */}
      <div style={{ backgroundColor: '#d1d1ec' }} className="p-4 sm:p-5 border-t border-slate-200 flex items-center justify-between gap-3">
        {currentStep > 1 ? (
          <button
            type="button"
            onClick={handleBack}
            className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-white text-xs font-semibold transition"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>
        ) : (
          <div />
        )}

        <button
          type="button"
          onClick={handleNext}
          disabled={currentStep === 5 && (!formData.consentSigned || !formData.privacyNoticeAcknowledged)}
          className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs font-bold transition shadow-xs ${
            currentStep === 5 && (!formData.consentSigned || !formData.privacyNoticeAcknowledged)
              ? 'bg-slate-200 text-slate-400 cursor-not-allowed'
              : 'bg-[#00685F] hover:bg-[#005049] text-white active:scale-95'
          }`}
        >
          <span>{currentStep === 5 ? 'Sign & Submit Medical Record' : 'Continue'}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
