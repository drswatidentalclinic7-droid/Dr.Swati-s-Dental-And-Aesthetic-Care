import React, { useRef, useState, useEffect } from 'react';
import { Eraser, Check, ShieldCheck, AlertCircle } from 'lucide-react';

interface ConsentSignaturePadProps {
  onSignatureChange: (signatureDataUrl: string, isValid: boolean) => void;
  signerName?: string;
  className?: string;
}

export const ConsentSignaturePad: React.FC<ConsentSignaturePadProps> = ({
  onSignatureChange,
  signerName = '',
  className = ''
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [timestamp, setTimestamp] = useState<string>('');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI displays
    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    const rect = canvas.getBoundingClientRect();
    
    // Set actual display size
    canvas.width = rect.width * ratio;
    canvas.height = rect.height * ratio;
    
    ctx.scale(ratio, ratio);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = '#0F172A'; // Deep Slate ink
    ctx.lineWidth = 2.2;
  }, []);

  const getCoordinates = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    return {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
  };

  const startDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.setPointerCapture(e.pointerId);
    const { x, y } = getCoordinates(e);

    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setHasDrawn(true);

    if (!timestamp) {
      setTimestamp(new Date().toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      }));
    }
  };

  const draw = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (canvas) {
      try {
        canvas.releasePointerCapture(e.pointerId);
      } catch {
        // ignore
      }
    }
    setIsDrawing(false);

    if (canvas) {
      const dataUrl = canvas.toDataURL('image/png');
      onSignatureChange(dataUrl, true);
    }
  };

  const clearSignature = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
    setTimestamp('');
    onSignatureChange('', false);
  };

  return (
    <div className={`space-y-3 ${className}`}>
      <div className="flex items-center justify-between">
        <label className="text-xs font-bold text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-teal-600" />
          Patient / Guardian Digital Signature
        </label>
        {hasDrawn && (
          <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full font-medium flex items-center gap-1 border border-emerald-200">
            <Check className="w-3 h-3" /> Captured
          </span>
        )}
      </div>

      {/* Sterile signature container */}
      <div className="relative bg-white rounded-xl border border-dashed border-slate-300 overflow-hidden shadow-2xs hover:border-[#0D9488] transition group">
        {/* Fixed Baseline Guide in Cyan #06B6D4 */}
        <div className="absolute left-6 right-6 bottom-9 border-b border-[#06B6D4]/50 pointer-events-none flex justify-between items-end pb-1">
          <span className="text-[10px] uppercase font-mono tracking-widest text-[#06B6D4] font-medium select-none">
            Sign on this line ✕
          </span>
          {signerName && (
            <span className="text-[10px] text-slate-400 font-mono select-none">
              Signer: {signerName}
            </span>
          )}
        </div>

        {/* Drawing Canvas */}
        <canvas
          ref={canvasRef}
          onPointerDown={startDrawing}
          onPointerMove={draw}
          onPointerUp={stopDrawing}
          onPointerCancel={stopDrawing}
          className="w-full h-36 signature-canvas cursor-crosshair block select-none bg-transparent"
        />

        {/* Clear Action Button */}
        {hasDrawn && (
          <button
            type="button"
            onClick={clearSignature}
            className="absolute top-2 right-2 bg-slate-100/90 hover:bg-slate-200 text-slate-600 hover:text-slate-900 p-1.5 rounded-lg text-xs font-medium flex items-center gap-1 backdrop-blur-xs transition shadow-2xs"
            title="Clear signature"
          >
            <Eraser className="w-3.5 h-3.5" />
            <span className="text-[11px]">Clear</span>
          </button>
        )}

        {/* Helper overlay when empty */}
        {!hasDrawn && (
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center text-slate-300 text-xs font-medium">
            Touch or drag with stylus / mouse to sign
          </div>
        )}
      </div>

      {/* Timestamp & Verification Note */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between text-[11px] text-slate-500 gap-1 px-1">
        <span className="flex items-center gap-1">
          <AlertCircle className="w-3 h-3 text-slate-400" />
          Legally binding digital signature under HIPAA & Medical Records Act.
        </span>
        {timestamp && (
          <span className="font-mono text-slate-600 bg-slate-100 px-2 py-0.5 rounded">
            Recorded: {timestamp}
          </span>
        )}
      </div>
    </div>
  );
};
