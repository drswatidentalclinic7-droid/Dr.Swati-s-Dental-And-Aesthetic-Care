import React, { useState, useRef, useEffect } from 'react';
import { 
  MessageSquare, 
  Send, 
  X, 
  Sparkles, 
  Bot, 
  User, 
  Calendar, 
  Phone, 
  ShieldCheck, 
  RefreshCw, 
  ChevronDown, 
  HeartHandshake,
  Stethoscope
} from 'lucide-react';
import { DOCTOR_INFO } from '../data/dentalData';

interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  hasBookingAction?: boolean;
}

interface DentalChatbotProps {
  onNavigateToTab?: (tab: 'intake' | 'booking' | 'records' | 'smile' | 'postop') => void;
  isOpenExternal?: boolean;
  onCloseExternal?: () => void;
}

const INITIAL_GREETING: ChatMessage = {
  id: 'msg-init',
  sender: 'ai',
  text: `Hello! I'm **SDA Dental AI**, your clinical assistant for Dr. Swati's Dental And Aesthetic Care.

I can help explain dental procedures, suggest remedies for toothache, explain aftercare guidelines, or assist you in booking a visit with **Dr. Swati R Emaliya**.

How can I help you with your smile today?`,
  timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
  hasBookingAction: false
};

const SUGGESTED_QUESTIONS = [
  "🦷 Is Root Canal (RCT) painful?",
  "✨ Teeth whitening & veneer options",
  "📅 Clinic hours & booking with Dr. Swati",
  "🩺 Immediate relief for toothache",
  "🩻 How to view my digital X-rays?"
];

export const DentalChatbot: React.FC<DentalChatbotProps> = ({ 
  onNavigateToTab,
  isOpenExternal,
  onCloseExternal 
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([INITIAL_GREETING]);
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [hasUnreadNotification, setHasUnreadNotification] = useState(true);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Sync external open state if provided
  useEffect(() => {
    if (isOpenExternal !== undefined) {
      setIsOpen(isOpenExternal);
    }
  }, [isOpenExternal]);

  useEffect(() => {
    if (isOpen) {
      setHasUnreadNotification(false);
      setTimeout(() => {
        inputRef.current?.focus();
        scrollToBottom();
      }, 100);
    }
  }, [isOpen]);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleToggle = () => {
    const nextState = !isOpen;
    setIsOpen(nextState);
    if (!nextState && onCloseExternal) {
      onCloseExternal();
    }
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputValue).trim();
    if (!query || isTyping) return;

    const userMessage: ChatMessage = {
      id: 'msg_' + Date.now(),
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      // Format recent conversation history for Gemini API
      const historyPayload = messages.slice(-6).map(m => ({
        role: m.sender === 'user' ? 'user' : 'model',
        parts: [{ text: m.text }]
      }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: historyPayload
        })
      });

      if (!res.ok) {
        throw new Error('API server returned error');
      }

      const data = await res.json();
      const replyText = data.reply || "I'm here to help with your dental health questions. Please feel free to ask about any procedure, tooth symptom, or appointment details.";
      const isBookingRelated = /book|appointment|schedule|consult|visit/i.test(query) || /book visit|appointment slot/i.test(replyText);

      const aiMessage: ChatMessage = {
        id: 'msg_ai_' + Date.now(),
        sender: 'ai',
        text: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        hasBookingAction: isBookingRelated
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (err) {
      console.error('Failed to communicate with AI chat backend:', err);
      // Friendly fallback
      const aiMessage: ChatMessage = {
        id: 'msg_ai_err_' + Date.now(),
        sender: 'ai',
        text: `Dr. Swati's Dental And Aesthetic Care welcomes you!

- **Location:** 5/904, GDA Market, Sector 5, Vaishali, Ghaziabad
- **Timings:** Mon - Sat: 5:00 PM – 8:30 PM (Sun: On Prior Appointment)
- **Direct Helpline / WhatsApp:** ${DOCTOR_INFO.phone}

Please feel free to click the **Book Visit** tab to schedule a painless consultation directly with Dr. Swati!`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        hasBookingAction: true
      };
      setMessages(prev => [...prev, aiMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleResetChat = () => {
    setMessages([INITIAL_GREETING]);
  };

  // Simple markdown-to-JSX renderer for clean procedure bullet points and bolding
  const renderFormattedText = (rawText: string) => {
    const lines = rawText.split('\n');
    return lines.map((line, idx) => {
      let content = line;

      // Header handling
      if (content.startsWith('### ')) {
        return (
          <h5 key={idx} className="font-bold text-slate-900 text-xs sm:text-sm mt-1.5 mb-1 text-teal-900">
            {content.replace('### ', '')}
          </h5>
        );
      }

      // Bullet points
      const isBullet = content.trim().startsWith('- ') || content.trim().startsWith('* ');
      if (isBullet) {
        content = content.trim().replace(/^[-*]\s+/, '');
      }

      // Bold formatting
      const parts = content.split(/(\*\*.*?\*\*)/g);
      const formattedParts = parts.map((part, pIdx) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={pIdx} className="font-bold text-slate-900">{part.slice(2, -2)}</strong>;
        }
        return part;
      });

      if (isBullet) {
        return (
          <div key={idx} className="flex items-start gap-1.5 my-0.5 text-xs text-slate-700">
            <span className="text-teal-600 font-bold shrink-0 mt-0.5">•</span>
            <span>{formattedParts}</span>
          </div>
        );
      }

      return (
        <p key={idx} className={`${line.trim() === '' ? 'h-1.5' : 'text-xs text-slate-700 leading-relaxed my-0.5'}`}>
          {formattedParts}
        </p>
      );
    });
  };

  return (
    <>
      {/* Floating Launcher Button */}
      {!isOpen && (
        <div className="fixed bottom-20 lg:bottom-6 right-4 sm:right-6 z-40">
          <button
            type="button"
            onClick={handleToggle}
            className="group relative flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-[#00685F] to-[#0D9488] text-white shadow-[0_8px_25px_rgba(0,104,95,0.4)] hover:shadow-[0_10px_30px_rgba(0,104,95,0.6)] hover:scale-105 active:scale-95 transition-all duration-200 cursor-pointer border border-teal-300/40"
            aria-label="Open Dr. Swati Dental AI Chatbot"
          >
            <div className="relative">
              <Bot className="w-5 h-5 text-teal-100" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 ring-2 ring-[#00685F] animate-pulse" />
            </div>

            <div className="text-left hidden sm:block">
              <span className="text-xs font-bold block leading-none">Ask Dental AI</span>
              <span className="text-[10px] text-teal-100 block leading-none mt-0.5">Dr. Swati's Clinic</span>
            </div>

            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow opacity-80" />

            {/* Notification Badge on first visit */}
            {hasUnreadNotification && (
              <span className="absolute -top-1.5 -left-1.5 bg-amber-400 text-slate-900 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full shadow-xs">
                New
              </span>
            )}
          </button>
        </div>
      )}

      {/* Main Chatbot Window */}
      {isOpen && (
        <div className="fixed bottom-20 lg:bottom-6 right-3 sm:right-6 z-50 w-[92vw] sm:w-[420px] max-h-[85vh] h-[600px] flex flex-col bg-white rounded-3xl border border-slate-200 shadow-2xl overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-[#072422] to-[#00685F] text-white flex items-center justify-between border-b border-teal-600/30">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-2xl bg-teal-800/80 border border-teal-400/40 flex items-center justify-center text-white shadow-xs">
                  <Bot className="w-5 h-5 text-teal-200" />
                </div>
                <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-400 ring-2 ring-[#072422]" />
              </div>

              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-sm font-bold text-white tracking-tight">
                    SDA Dental AI
                  </h3>
                  <span className="text-[10px] font-bold px-2 py-0.2 rounded-full bg-teal-900/90 text-teal-200 border border-teal-400/30">
                    Online
                  </span>
                </div>
                <p className="text-[11px] text-teal-100/90 flex items-center gap-1">
                  <span>Dr. Swati's Clinical Assistant</span>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={handleResetChat}
                className="p-1.5 rounded-xl text-teal-200 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="Restart conversation"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                onClick={handleToggle}
                className="p-1.5 rounded-xl text-teal-200 hover:text-white hover:bg-white/10 transition cursor-pointer"
                title="Close chat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Consultation Helpline Banner */}
          <div className="bg-[#f0fbf9] border-b border-teal-100 px-4 py-2 flex items-center justify-between text-[11px] text-teal-900">
            <span className="flex items-center gap-1.5 font-medium truncate">
              <Stethoscope className="w-3.5 h-3.5 text-teal-700 shrink-0" />
              <span>Painless Modern Dentistry Guidance</span>
            </span>
            <a
              href={`tel:${DOCTOR_INFO.phone}`}
              className="text-teal-800 font-bold hover:underline shrink-0 text-[10px] bg-teal-100/60 px-2 py-0.5 rounded-md"
            >
              Call Clinic
            </a>
          </div>

          {/* Messages Stream */}
          <div className="flex-1 p-4 overflow-y-auto space-y-3.5 bg-slate-50/50">
            {messages.map((msg) => {
              const isAi = msg.sender === 'ai';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-2.5 ${isAi ? 'justify-start' : 'justify-end'}`}
                >
                  {isAi && (
                    <div className="w-7 h-7 rounded-xl bg-[#00685F] text-white flex items-center justify-center shrink-0 mt-0.5 shadow-xs">
                      <Bot className="w-4 h-4 text-teal-200" />
                    </div>
                  )}

                  <div className={`max-w-[85%] rounded-2xl p-3 sm:p-3.5 shadow-2xs space-y-1.5 ${
                    isAi
                      ? 'bg-white border border-slate-200 text-slate-800'
                      : 'bg-[#00685F] text-white'
                  }`}>
                    {/* Message Body */}
                    <div className="text-xs space-y-0.5">
                      {isAi ? renderFormattedText(msg.text) : <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>}
                    </div>

                    {/* Quick Interactive Actions */}
                    {isAi && msg.hasBookingAction && onNavigateToTab && (
                      <div className="pt-2 mt-1 border-t border-slate-100 flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setIsOpen(false);
                            onNavigateToTab('booking');
                          }}
                          className="px-3 py-1.5 rounded-xl bg-[#00685F] hover:bg-[#00554e] text-white text-[11px] font-bold inline-flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Book Visit with Dr. Swati</span>
                        </button>
                      </div>
                    )}

                    {/* Timestamp */}
                    <div className={`text-[9px] font-mono text-right ${isAi ? 'text-slate-400' : 'text-teal-200'}`}>
                      {msg.timestamp}
                    </div>
                  </div>

                  {!isAi && (
                    <div className="w-7 h-7 rounded-xl bg-slate-300 text-slate-700 flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-2.5 justify-start">
                <div className="w-7 h-7 rounded-xl bg-[#00685F] text-white flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4 text-teal-200" />
                </div>
                <div className="bg-white border border-slate-200 rounded-2xl p-3 shadow-2xs flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-teal-500 animate-bounce" />
                  <span className="w-2 h-2 rounded-full bg-teal-500 animate-bounce [animation-delay:0.2s]" />
                  <span className="w-2 h-2 rounded-full bg-teal-500 animate-bounce [animation-delay:0.4s]" />
                  <span className="text-[11px] text-slate-400 ml-1">Dr. Swati AI is typing...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Quick Question Chips (when few messages) */}
          {messages.length <= 3 && (
            <div className="px-3 py-2 bg-white border-t border-slate-100 flex items-center gap-1.5 overflow-x-auto scrollbar-none">
              {SUGGESTED_QUESTIONS.map((q, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => handleSendMessage(q)}
                  className="px-2.5 py-1 rounded-xl bg-slate-100 hover:bg-teal-50 hover:text-teal-800 border border-slate-200 text-[11px] text-slate-600 font-medium whitespace-nowrap transition cursor-pointer"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input Bar */}
          <div className="p-3 bg-white border-t border-slate-200 space-y-1.5">
            <div className="flex items-center gap-2">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Ask about root canal, toothache, timings, booking..."
                disabled={isTyping}
                className="flex-1 bg-slate-100 border border-slate-200 rounded-2xl px-3.5 py-2.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-teal-500 focus:bg-white transition"
              />
              <button
                type="button"
                onClick={() => handleSendMessage()}
                disabled={!inputValue.trim() || isTyping}
                className="p-2.5 rounded-2xl bg-[#00685F] hover:bg-[#00554e] disabled:opacity-40 disabled:hover:bg-[#00685F] text-white shadow-xs transition cursor-pointer shrink-0"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            <div className="flex items-center justify-between text-[10px] text-slate-400 px-1">
              <span>Guidance powered by Dr. Swati's clinical desk</span>
              <span>Emergency? Call <strong className="text-teal-700">{DOCTOR_INFO.phone}</strong></span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
