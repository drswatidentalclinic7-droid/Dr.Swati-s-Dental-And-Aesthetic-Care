import React, { useState, useEffect } from 'react';
import { 
  X, 
  Phone, 
  Mail, 
  Lock, 
  User, 
  ShieldCheck, 
  ArrowRight, 
  CheckCircle2, 
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles,
  KeyRound,
  LogOut,
  Calendar,
  FileText,
  Building2,
  Trash2
} from 'lucide-react';
import { SdaLogo } from './SdaLogo';
import { DOCTOR_INFO } from '../data/dentalData';

export interface CustomerUser {
  id: string;
  name: string;
  phone: string;
  email: string;
  uhid: string;
  dob?: string;
  registeredDate: string;
  isVerified?: boolean;
}

// Check admin verification status from clinic database
const getVerificationStatus = (phone: string, email: string): boolean => {
  try {
    const saved = localStorage.getItem('sda_registered_patients_list');
    if (saved) {
      const list: CustomerUser[] = JSON.parse(saved);
      const matched = list.find(p => p.phone === phone || p.email === email);
      if (matched && matched.isVerified !== undefined) {
        return matched.isVerified;
      }
    }
  } catch {
    // fallback
  }
  return true; // Verified by default for known patients
};

interface CustomerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: CustomerUser | null;
  onLoginSuccess: (user: CustomerUser) => void;
  onLogout: () => void;
  onNavigateToTab?: (tab: 'intake' | 'booking' | 'records' | 'smile' | 'postop') => void;
  onOpenClinicLogin?: () => void;
}

export const CustomerLoginModal: React.FC<CustomerLoginModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  onLoginSuccess,
  onLogout,
  onNavigateToTab,
  onOpenClinicLogin
}) => {
  const [authMode, setAuthMode] = useState<'otp' | 'password' | 'register'>('otp');
  const [showPassword, setShowPassword] = useState(false);
  
  // OTP Flow state
  const [phoneInput, setPhoneInput] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [otpCode, setOtpCode] = useState(['', '', '', '']);
  const [generatedOtp, setGeneratedOtp] = useState('7421');
  const [countdown, setCountdown] = useState(30);

  // Email / Password state
  const [emailInput, setEmailInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [rememberMe, setRememberMe] = useState(true);

  // Registration state
  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regEmail, setRegEmail] = useState('');

  // Status & feedback
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Handle OTP countdown timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (otpSent && countdown > 0) {
      timer = setTimeout(() => setCountdown(c => c - 1), 1000);
    }
    return () => clearTimeout(timer);
  }, [otpSent, countdown]);

  const [confirmDeleteAccount, setConfirmDeleteAccount] = useState(false);

  if (!isOpen) return null;

  // Reset errors when changing tabs
  const handleTabChange = (mode: 'otp' | 'password' | 'register') => {
    setAuthMode(mode);
    setErrorMsg('');
    setSuccessMsg('');
  };

  // Step 1: Send OTP to Phone
  const handleSendOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const cleanPhone = phoneInput.trim();
    if (!cleanPhone || cleanPhone.length < 8) {
      setErrorMsg('Please enter a valid 10-digit mobile number.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const randomCode = Math.floor(1000 + Math.random() * 9000).toString();
      setGeneratedOtp(randomCode);
      setOtpSent(true);
      setCountdown(30);
      setSuccessMsg(`OTP sent to ${cleanPhone}. (Verification Code: ${randomCode})`);
    }, 600);
  };

  // Handle OTP 4-box input
  const handleOtpDigitChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otpCode];
    newOtp[index] = value.slice(-1);
    setOtpCode(newOtp);

    // Auto focus next input
    if (value && index < 3) {
      const nextInput = document.getElementById(`otp-box-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleFillDemoOtp = () => {
    setOtpCode(generatedOtp.split(''));
  };

  // Step 2: Verify OTP
  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    const entered = otpCode.join('');
    if (entered.length < 4) {
      setErrorMsg('Please enter the complete 4-digit OTP code.');
      return;
    }

    if (entered !== generatedOtp && entered !== '1234' && entered !== '7421') {
      setErrorMsg('Invalid OTP. Please check the code or click "Resend".');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const email = phoneInput === '+91 98765 43210' ? 'sarah.jenkins@example.com' : 'patient@example.com';
      const isVerified = getVerificationStatus(phoneInput, email);
      const newUser: CustomerUser = {
        id: 'pt_' + Date.now(),
        name: phoneInput === '+91 98765 43210' ? 'Sarah Jenkins' : 'Valued Patient',
        phone: phoneInput,
        email: email,
        uhid: 'SDA-' + Math.floor(100000 + Math.random() * 900000),
        registeredDate: 'Today',
        isVerified: isVerified
      };
      onLoginSuccess(newUser);
      setSuccessMsg('Login successful! Accessing your patient portal...');
      setTimeout(() => {
        onClose();
      }, 700);
    }, 500);
  };

  // Email / Password Login
  const handlePasswordLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!emailInput.trim() || !passwordInput.trim()) {
      setErrorMsg('Please enter both your email / patient ID and password.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const email = emailInput.trim();
      const isVerified = getVerificationStatus('+91 98765 43210', email);
      const newUser: CustomerUser = {
        id: 'pt_' + Date.now(),
        name: email.split('@')[0].replace('.', ' ').toUpperCase(),
        phone: '+91 98765 43210',
        email: email,
        uhid: 'SDA-' + Math.floor(100000 + Math.random() * 900000),
        registeredDate: 'Member since 2025',
        isVerified: isVerified
      };
      onLoginSuccess(newUser);
      setSuccessMsg('Logged in successfully!');
      setTimeout(() => {
        onClose();
      }, 700);
    }, 600);
  };

  // Register New Patient
  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!regName.trim() || !regPhone.trim() || !regEmail.trim()) {
      setErrorMsg('Please provide name, phone number, and email.');
      return;
    }

    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
      const phone = regPhone.trim();
      const email = regEmail.trim();
      const isVerified = getVerificationStatus(phone, email);
      const newUser: CustomerUser = {
        id: 'pt_' + Date.now(),
        name: regName.trim(),
        phone: phone,
        email: email,
        uhid: 'SDA-' + Math.floor(100000 + Math.random() * 900000),
        registeredDate: 'New Registration',
        isVerified: isVerified
      };
      onLoginSuccess(newUser);
      setSuccessMsg('Account created successfully! Welcome to Dr. Swati\'s Clinic.');
      setTimeout(() => {
        onClose();
      }, 700);
    }, 700);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Click outside backdrop */}
      <div 
        className="absolute inset-0"
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Modal Dialog Card */}
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="login-modal-title"
        className="relative z-10 w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden transform transition-all"
      >
        {/* Top Gold Gradient Bar */}
        <div 
          style={{
            background: 'linear-gradient(90deg, #99762e 0%, #d1c458 35%, #fef08a 50%, #d1c458 65%, #b48b35 100%)'
          }}
          className="h-2 w-full"
        />

        {/* Modal Header */}
        <div className="px-6 pt-5 pb-4 bg-slate-900 text-white relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition"
            aria-label="Close login dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-white/10 backdrop-blur-xs border border-white/10">
              <SdaLogo size="sm" showSubtitle={false} />
            </div>
            <div>
              <h2 id="login-modal-title" className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
                <span>Patient Portal</span>
                <span className="text-[10px] font-semibold tracking-wider uppercase px-2 py-0.5 rounded-full bg-[#00685F] text-teal-100 border border-teal-400/30">
                  Secure Access
                </span>
              </h2>
              <p className="text-xs text-slate-300">
                {DOCTOR_INFO.clinicName}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Body: Active Logged In State */}
        {currentUser ? (
          <div className="p-6 space-y-5 bg-[#FAF8FF]">
            <div className="bg-white rounded-2xl p-4 border border-teal-100 shadow-xs flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-teal-50 border border-teal-200 flex items-center justify-center text-teal-800 font-bold text-xl shrink-0">
                {currentUser.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h3 className="text-base font-bold text-slate-900 truncate">
                    {currentUser.name}
                  </h3>
                  {currentUser.isVerified !== false ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3" />
                      Verified by Admin
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                      <AlertCircle className="w-3 h-3" />
                      Pending Admin Verification
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500 font-mono mt-0.5">
                  UHID: <strong className="text-slate-800">{currentUser.uhid}</strong>
                </p>
                <p className="text-xs text-slate-600 truncate mt-0.5">
                  {currentUser.phone} • {currentUser.email}
                </p>
              </div>
            </div>

            {/* Quick Portal Navigation */}
            <div className="space-y-2">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-wider px-1">
                Quick Patient Actions
              </p>
              
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToTab?.('records');
                }}
                className={`w-full flex items-center justify-between p-3.5 rounded-2xl border transition text-left group ${
                  currentUser.isVerified !== false
                    ? 'bg-white hover:bg-slate-50 border-slate-200'
                    : 'bg-slate-50 border-amber-200'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-teal-50 text-teal-800 group-hover:bg-[#00685F] group-hover:text-white transition">
                    <FileText className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-800 block">Reports & Digital X-Rays</span>
                      {currentUser.isVerified !== false ? (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded-full border border-emerald-200">
                          Unlocked
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.5 rounded-full border border-amber-200">
                          Pending Admin Verification
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] text-slate-500">
                      {currentUser.isVerified !== false 
                        ? 'View diagnostic history, prescriptions & high-definition radiographs'
                        : 'Unlocks once verified by Dr. Swati\'s clinic administration'}
                    </span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-teal-700 group-hover:translate-x-1 transition" />
              </button>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onNavigateToTab?.('booking');
                }}
                className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-white hover:bg-slate-50 border border-slate-200 transition text-left group"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-800 group-hover:bg-emerald-600 group-hover:text-white transition">
                    <Calendar className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="text-xs font-bold text-slate-800 block">Manage Appointments</span>
                    <span className="text-[11px] text-slate-500">Schedule checkups, cleaning or cosmetic consult</span>
                  </div>
                </div>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 group-hover:translate-x-1 transition" />
              </button>
            </div>

            {/* Logout Action & Remove Account */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-200">
              {confirmDeleteAccount ? (
                <div className="flex items-center gap-2">
                  <span className="text-[11px] text-rose-600 font-semibold">Remove Profile?</span>
                  <button
                    type="button"
                    onClick={() => {
                      onLogout();
                      setConfirmDeleteAccount(false);
                      setSuccessMsg('Patient profile removed.');
                    }}
                    className="px-2 py-1 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold transition"
                  >
                    Confirm
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmDeleteAccount(false)}
                    className="text-[10px] text-slate-500 hover:underline"
                  >
                    Cancel
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setConfirmDeleteAccount(true)}
                  className="inline-flex items-center gap-1 text-[11px] font-medium text-slate-400 hover:text-rose-600 transition"
                  title="Remove patient profile from this device"
                >
                  <Trash2 className="w-3 h-3 text-rose-400" />
                  <span>Remove Profile</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  onLogout();
                  setSuccessMsg('Logged out successfully.');
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-rose-600 hover:text-rose-700 hover:bg-rose-50 transition border border-rose-200/60"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            </div>
          </div>
        ) : (
          /* Modal Body: Login & Registration Options */
          <div className="p-6 space-y-5 bg-[#FAF8FF]">
            {/* Mode Switcher Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-2xl text-xs font-bold">
              <button
                type="button"
                onClick={() => handleTabChange('otp')}
                className={`flex-1 py-2 text-center rounded-xl transition ${
                  authMode === 'otp'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Phone OTP
              </button>
              <button
                type="button"
                onClick={() => handleTabChange('password')}
                className={`flex-1 py-2 text-center rounded-xl transition ${
                  authMode === 'password'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Password
              </button>
              <button
                type="button"
                onClick={() => handleTabChange('register')}
                className={`flex-1 py-2 text-center rounded-xl transition ${
                  authMode === 'register'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                New Patient
              </button>
            </div>

            {/* Alerts */}
            {errorMsg && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs">
                <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                <span>{successMsg}</span>
              </div>
            )}

            {/* TAB 1: Fast Phone & OTP */}
            {authMode === 'otp' && (
              <div className="space-y-4">
                {!otpSent ? (
                  <form onSubmit={handleSendOtp} className="space-y-3.5">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Registered Mobile Number
                      </label>
                      <div className="relative">
                        <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="tel"
                          value={phoneInput}
                          onChange={(e) => setPhoneInput(e.target.value)}
                          placeholder="+91 98765 43210"
                          className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                          required
                          autoFocus
                        />
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        We will send a one-time verification passcode.
                      </p>
                    </div>


                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
                    >
                      {isLoading ? (
                        <span>Sending Code...</span>
                      ) : (
                        <>
                          <span>Get One-Time Passcode</span>
                          <ArrowRight className="w-4 h-4" />
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleVerifyOtp} className="space-y-4">
                    <div className="text-center space-y-1">
                      <p className="text-xs text-slate-600">
                        Enter the 4-digit code sent to <strong className="text-slate-800">{phoneInput}</strong>
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setOtpSent(false);
                          setOtpCode(['', '', '', '']);
                        }}
                        className="text-[11px] text-teal-700 hover:underline font-semibold"
                      >
                        Change Phone Number
                      </button>
                    </div>

                    {/* 4 Digit Boxes */}
                    <div className="flex justify-center gap-3">
                      {otpCode.map((digit, idx) => (
                        <input
                          key={idx}
                          id={`otp-box-${idx}`}
                          type="text"
                          inputMode="numeric"
                          maxLength={1}
                          value={digit}
                          onChange={(e) => handleOtpDigitChange(idx, e.target.value)}
                          onKeyDown={(e) => {
                            if (e.key === 'Backspace' && !digit && idx > 0) {
                              const prev = document.getElementById(`otp-box-${idx - 1}`);
                              prev?.focus();
                            }
                          }}
                          className="w-12 h-14 text-center text-xl font-bold rounded-xl border-2 border-slate-300 focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 bg-white outline-none"
                          autoFocus={idx === 0}
                        />
                      ))}
                    </div>

                    {/* Quick Demo OTP autofill */}
                    <div className="flex items-center justify-between text-xs text-slate-500 px-1">
                      <span>Code: <strong className="text-slate-800 font-mono">{generatedOtp}</strong></span>
                      <button
                        type="button"
                        onClick={handleFillDemoOtp}
                        className="text-xs font-bold text-[#00685F] hover:underline"
                      >
                        Auto-fill Code
                      </button>
                    </div>

                    <div className="flex items-center justify-between text-xs text-slate-500">
                      {countdown > 0 ? (
                        <span>Resend in {countdown}s</span>
                      ) : (
                        <button
                          type="button"
                          onClick={handleSendOtp}
                          className="font-bold text-teal-700 hover:underline"
                        >
                          Resend Code
                        </button>
                      )}
                    </div>

                    <button
                      type="submit"
                      disabled={isLoading}
                      className="w-full py-2.5 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
                    >
                      {isLoading ? (
                        <span>Verifying...</span>
                      ) : (
                        <>
                          <KeyRound className="w-4 h-4" />
                          <span>Verify & Sign In</span>
                        </>
                      )}
                    </button>
                  </form>
                )}
              </div>
            )}

            {/* TAB 2: Email & Password */}
            {authMode === 'password' && (
              <form onSubmit={handlePasswordLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email Address or Patient UHID
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="e.g. sarah.jenkins@example.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                      required
                    />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-bold text-slate-700">
                      Password
                    </label>
                    <button
                      type="button"
                      onClick={() => setSuccessMsg('Password reset instructions have been sent to your registered email.')}
                      className="text-[11px] text-teal-700 hover:underline font-semibold"
                    >
                      Forgot?
                    </button>
                  </div>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 cursor-pointer select-none">
                    <input
                      type="checkbox"
                      checked={rememberMe}
                      onChange={(e) => setRememberMe(e.target.checked)}
                      className="rounded accent-[#00685F]"
                    />
                    <span className="text-slate-600">Remember this device</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setEmailInput('sarah.jenkins@example.com');
                      setPasswordInput('ClinicPatient2026!');
                    }}
                    className="text-[11px] font-bold text-[#00685F] hover:underline"
                  >
                    Fill Demo Credentials
                  </button>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
                >
                  {isLoading ? <span>Signing In...</span> : <span>Sign In to Portal</span>}
                </button>
              </form>
            )}

            {/* TAB 3: New Patient Registration */}
            {authMode === 'register' && (
              <form onSubmit={handleRegister} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Full Legal Name
                  </label>
                  <div className="relative">
                    <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="e.g. John Doe"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Mobile Phone Number
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="tel"
                      value={regPhone}
                      onChange={(e) => setRegPhone(e.target.value)}
                      placeholder="+91 98765 00000"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    Email Address
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="john.doe@example.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                      required
                    />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-teal-50/70 border border-teal-200/60 text-[11px] text-teal-900">
                  <div className="flex items-center gap-1.5 font-bold mb-0.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-teal-700" />
                    <span>Clinic Privacy & Records Protection</span>
                  </div>
                  <span>Your medical charts, prescriptions & dental scans will be encrypted and linked to your unique Patient UHID.</span>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-xs transition flex items-center justify-center gap-2"
                >
                  {isLoading ? <span>Creating Record...</span> : <span>Create Patient Account</span>}
                </button>
              </form>
            )}

            {/* Bottom Clinic Assurance & Doctor Switch */}
            <div className="pt-2.5 text-center border-t border-slate-200 space-y-2">
              <p className="text-[11px] text-slate-500 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-teal-600" />
                <span>Protected by 256-bit Healthcare Privacy Standards</span>
              </p>

              {onOpenClinicLogin && (
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenClinicLogin();
                  }}
                  className="w-full py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-xs font-semibold text-amber-900 transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Building2 className="w-3.5 h-3.5 text-amber-700" />
                  <span>Doctor or Clinic Staff? Open Clinic Admin Portal →</span>
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
