import React, { useState, useMemo, useEffect } from 'react';
import { 
  Building2, 
  Calendar, 
  Users, 
  FileText, 
  Activity, 
  Download, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Phone, 
  Mail, 
  MessageCircle, 
  ShieldCheck, 
  LogOut, 
  X, 
  Plus, 
  FileSpreadsheet, 
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  Stethoscope,
  ChevronDown,
  Printer,
  Trash2,
  MoreVertical,
  MessageSquarePlus,
  Upload,
  Pill,
  Image as ImageIcon,
  Eye,
  FileCheck
} from 'lucide-react';
import { DOCTOR_INFO } from '../data/dentalData';
import { AppointmentSlot, PatientIntakeData } from '../types/dental';
import { SdaLogo } from './SdaLogo';
import { CustomerUser } from './CustomerLoginModal';
import { 
  PatientRemark, 
  PatientXray, 
  PatientPrescription, 
  PatientClinicalVault,
  getPatientClinicalVault, 
  savePatientClinicalVault 
} from '../services/clinicalRecordsService';

interface ClinicAdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  appointments: AppointmentSlot[];
  onUpdateAppointments: (updated: AppointmentSlot[]) => void;
  intakeRecords: PatientIntakeData[];
  onUpdateIntakeRecords?: (updated: PatientIntakeData[]) => void;
  customerUsers?: CustomerUser[];
  onDeleteCustomerUser?: (userId: string) => void;
  onUpdateCustomerUser?: (user: CustomerUser) => void;
}

export const ClinicAdminDashboard: React.FC<ClinicAdminDashboardProps> = ({
  isOpen,
  onClose,
  onLogout,
  appointments,
  onUpdateAppointments,
  intakeRecords,
  onUpdateIntakeRecords,
  customerUsers = [],
  onDeleteCustomerUser,
  onUpdateCustomerUser
}) => {
  const [activeTab, setActiveTab] = useState<'appointments' | 'intakes' | 'patients' | 'treatments'>('appointments');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'confirmed' | 'completed' | 'pending' | 'cancelled'>('all');
  const [selectedIntake, setSelectedIntake] = useState<PatientIntakeData | null>(null);
  const [showAddWalkIn, setShowAddWalkIn] = useState(false);
  const [exportNotice, setExportNotice] = useState<string | null>(null);

  // Walk-in form state
  const [walkInName, setWalkInName] = useState('');
  const [walkInPhone, setWalkInPhone] = useState('');
  const [walkInEmail, setWalkInEmail] = useState('');
  const [walkInService, setWalkInService] = useState('Diagnostic Consultation & Scaling');
  const [walkInDate, setWalkInDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [walkInTime, setWalkInTime] = useState('11:00 AM');
  const [walkInNotes, setWalkInNotes] = useState('Walk-in patient checked in at reception');

  // Filtered Appointments
  const filteredAppointments = useMemo(() => {
    return appointments.filter(apt => {
      const matchesSearch = 
        apt.patientName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        apt.phone.includes(searchTerm) ||
        apt.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        apt.serviceName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        apt.date.includes(searchTerm);
      
      const matchesStatus = statusFilter === 'all' || apt.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [appointments, searchTerm, statusFilter]);

  // Filtered Intakes
  const filteredIntakes = useMemo(() => {
    return intakeRecords.filter(rec => {
      return (
        rec.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.phone.includes(searchTerm) ||
        rec.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rec.primaryConcern.toLowerCase().includes(searchTerm.toLowerCase())
      );
    });
  }, [intakeRecords, searchTerm]);

  // Patient removal confirmation state
  const [patientToRemove, setPatientToRemove] = useState<{
    type: 'patient' | 'appointment' | 'intake';
    id: string;
    name: string;
    index?: number;
  } | null>(null);

  // 3-dot dropdown menu and clinical modals
  const [openMenuPatientId, setOpenMenuPatientId] = useState<string | null>(null);
  const [activeClinicalModal, setActiveClinicalModal] = useState<'remarks' | 'xrays' | 'prescription' | null>(null);
  const [selectedPatientForClinical, setSelectedPatientForClinical] = useState<CustomerUser | null>(null);
  const [currentPatientVault, setCurrentPatientVault] = useState<PatientClinicalVault | null>(null);

  // Remarks Form State
  const [newRemarkCategory, setNewRemarkCategory] = useState<PatientRemark['category']>('Treatment Plan');
  const [newRemarkContent, setNewRemarkContent] = useState('');

  // X-Rays Form State
  const [newXrayTitle, setNewXrayTitle] = useState('');
  const [newXrayType, setNewXrayType] = useState('Intraoral Periapical (IOPA)');
  const [newXrayArea, setNewXrayArea] = useState('Tooth #30 Mandibular Molar');
  const [newXrayDosage, setNewXrayDosage] = useState('0.003 mSv (Ultra-Low Dose)');
  const [newXrayFindings, setNewXrayFindings] = useState('');
  const [newXrayDataUrl, setNewXrayDataUrl] = useState<string>('');
  const [newXrayFileName, setNewXrayFileName] = useState<string>('');

  // Prescription Form State
  const [newRxDrug, setNewRxDrug] = useState('');
  const [newRxDosage, setNewRxDosage] = useState('1 Tablet');
  const [newRxFrequency, setNewRxFrequency] = useState('Twice Daily (BID) - After Meals');
  const [newRxDuration, setNewRxDuration] = useState('5 Days');
  const [newRxInstructions, setNewRxInstructions] = useState('Take after food with full glass of water. Complete full course.');
  const [newRxStatus, setNewRxStatus] = useState<'Active' | 'Completed'>('Active');

  // Load vault when selected patient changes
  useEffect(() => {
    if (selectedPatientForClinical?.phone) {
      const vault = getPatientClinicalVault(selectedPatientForClinical.phone);
      setCurrentPatientVault(vault);
    } else {
      setCurrentPatientVault(null);
    }
  }, [selectedPatientForClinical]);

  // Managed Patient Directory State
  const [managedPatients, setManagedPatients] = useState<CustomerUser[]>(() => {
    try {
      const saved = localStorage.getItem('sda_registered_patients_list');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return customerUsers.length > 0 ? customerUsers : [
      {
        id: 'pt_1',
        name: 'Sarah Jenkins',
        phone: '+1 (555) 392-8841',
        email: 'sarah.jenkins@example.com',
        uhid: 'SDA-2026-7842',
        registeredDate: 'Active Member'
      },
      {
        id: 'pt_2',
        name: 'Rajesh Patel',
        phone: '+91 98765 43210',
        email: 'rajesh.patel@example.com',
        uhid: 'SDA-2026-8819',
        registeredDate: 'Active Member'
      }
    ];
  });

  // Sync new patient users if registered
  useEffect(() => {
    if (customerUsers && customerUsers.length > 0) {
      setManagedPatients(prev => {
        const existingIds = new Set(prev.map(p => p.id));
        const newOnes = customerUsers.filter(u => !existingIds.has(u.id));
        if (newOnes.length > 0) {
          const merged = [...newOnes, ...prev];
          try {
            localStorage.setItem('sda_registered_patients_list', JSON.stringify(merged));
          } catch {
            // ignore
          }
          return merged;
        }
        return prev;
      });
    }
  }, [customerUsers]);

  // Filtered Patients
  const filteredPatients = useMemo(() => {
    return managedPatients.filter(pt => {
      const term = searchTerm.toLowerCase();
      return (
        pt.name.toLowerCase().includes(term) ||
        pt.phone.includes(searchTerm) ||
        pt.email.toLowerCase().includes(term) ||
        pt.uhid.toLowerCase().includes(term)
      );
    });
  }, [managedPatients, searchTerm]);

  if (!isOpen) return null;

  // Confirm and execute removal
  const confirmRemove = () => {
    if (!patientToRemove) return;
    const { type, id, name, index } = patientToRemove;

    if (type === 'patient') {
      const updated = managedPatients.filter(p => p.id !== id);
      setManagedPatients(updated);
      try {
        localStorage.setItem('sda_registered_patients_list', JSON.stringify(updated));
      } catch {
        // ignore
      }
      onDeleteCustomerUser?.(id);
      setExportNotice(`Patient "${name}" has been removed from the clinic directory.`);
    } else if (type === 'appointment') {
      const updated = appointments.filter(a => a.id !== id);
      onUpdateAppointments(updated);
      setExportNotice(`Appointment for patient "${name}" has been removed.`);
    } else if (type === 'intake') {
      const updated = intakeRecords.filter((_, i) => i !== index);
      onUpdateIntakeRecords?.(updated);
      if (selectedIntake?.fullName === name) {
        setSelectedIntake(null);
      }
      setExportNotice(`Intake medical record for "${name}" has been removed.`);
    }

    setPatientToRemove(null);
    setTimeout(() => setExportNotice(null), 4000);
  };

  // Toggle patient profile verification (unlocks/locks digital X-rays and reports)
  const handleToggleVerification = (patientId: string, patientName: string) => {
    const updated = managedPatients.map(pt => {
      if (pt.id === patientId) {
        const nextStatus = pt.isVerified === false ? true : false;
        return { ...pt, isVerified: nextStatus };
      }
      return pt;
    });
    setManagedPatients(updated);
    try {
      localStorage.setItem('sda_registered_patients_list', JSON.stringify(updated));
    } catch {
      // ignore
    }

    const target = updated.find(p => p.id === patientId);
    if (target && onUpdateCustomerUser) {
      onUpdateCustomerUser(target);
    }

    const isNowVerified = target?.isVerified !== false;
    setExportNotice(
      isNowVerified
        ? `Patient "${patientName}" verified! Digital reports and X-rays are now unlocked in their patient login.`
        : `Patient "${patientName}" verification revoked. Digital reports and X-rays locked.`
    );
    setTimeout(() => setExportNotice(null), 4000);
  };

  // Remark Handlers
  const handleSaveRemark = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientForClinical || !newRemarkContent.trim()) return;

    const vault = getPatientClinicalVault(selectedPatientForClinical.phone);
    const newRemark: PatientRemark = {
      id: 'rem_' + Date.now(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      category: newRemarkCategory,
      content: newRemarkContent.trim(),
      doctor: 'Dr. Swati R Emaliya, BDS'
    };

    const updatedVault: PatientClinicalVault = {
      ...vault,
      remarks: [newRemark, ...vault.remarks]
    };

    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
    setNewRemarkContent('');
    setExportNotice(`Remark saved for ${selectedPatientForClinical.name}! Visible in patient portal (${selectedPatientForClinical.phone}).`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  const handleDeleteRemark = (remarkId: string) => {
    if (!selectedPatientForClinical || !currentPatientVault) return;
    const updatedVault: PatientClinicalVault = {
      ...currentPatientVault,
      remarks: currentPatientVault.remarks.filter(r => r.id !== remarkId)
    };
    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
  };

  // X-Ray Upload Handlers
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setNewXrayFileName(file.name);
    if (!newXrayTitle) {
      setNewXrayTitle(file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' '));
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (typeof event.target?.result === 'string') {
        setNewXrayDataUrl(event.target.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSaveXray = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientForClinical) return;
    if (!newXrayTitle.trim()) {
      alert('Please specify a title or description for the radiograph.');
      return;
    }

    const vault = getPatientClinicalVault(selectedPatientForClinical.phone);
    const newXray: PatientXray = {
      id: 'xray_' + Date.now(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      title: newXrayTitle.trim(),
      type: newXrayType,
      anatomicalArea: newXrayArea.trim() || 'Mandibular / Maxillary Dentition',
      dosageMsv: newXrayDosage,
      imageDataUrl: newXrayDataUrl || undefined,
      findings: newXrayFindings.trim() || 'Radiographic margins and apical periodontal structures within normal physiological limits.',
      doctor: 'Dr. Swati R Emaliya, BDS'
    };

    const updatedVault: PatientClinicalVault = {
      ...vault,
      xrays: [newXray, ...vault.xrays]
    };

    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
    setNewXrayTitle('');
    setNewXrayFindings('');
    setNewXrayDataUrl('');
    setNewXrayFileName('');
    setExportNotice(`Radiograph uploaded for ${selectedPatientForClinical.name}! Visible in patient portal (${selectedPatientForClinical.phone}).`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  const handleDeleteXray = (xrayId: string) => {
    if (!selectedPatientForClinical || !currentPatientVault) return;
    const updatedVault: PatientClinicalVault = {
      ...currentPatientVault,
      xrays: currentPatientVault.xrays.filter(x => x.id !== xrayId)
    };
    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
  };

  // Prescription Handlers
  const handleSavePrescription = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatientForClinical || !newRxDrug.trim()) return;

    const vault = getPatientClinicalVault(selectedPatientForClinical.phone);
    const newRx: PatientPrescription = {
      id: 'rx_' + Date.now(),
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }),
      drug: newRxDrug.trim(),
      dosage: newRxDosage.trim(),
      frequency: newRxFrequency.trim(),
      duration: newRxDuration.trim(),
      instructions: newRxInstructions.trim(),
      status: newRxStatus,
      doctor: 'Dr. Swati R Emaliya, BDS'
    };

    const updatedVault: PatientClinicalVault = {
      ...vault,
      prescriptions: [newRx, ...vault.prescriptions]
    };

    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
    setNewRxDrug('');
    setExportNotice(`Prescription added for ${selectedPatientForClinical.name}! Visible in patient portal (${selectedPatientForClinical.phone}).`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  const handleDeletePrescription = (rxId: string) => {
    if (!selectedPatientForClinical || !currentPatientVault) return;
    const updatedVault: PatientClinicalVault = {
      ...currentPatientVault,
      prescriptions: currentPatientVault.prescriptions.filter(p => p.id !== rxId)
    };
    savePatientClinicalVault(selectedPatientForClinical.phone, updatedVault);
    setCurrentPatientVault(updatedVault);
  };

  // Key KPI Metrics
  const totalAppointments = appointments.length;
  const confirmedCount = appointments.filter(a => a.status === 'confirmed').length;
  const completedCount = appointments.filter(a => a.status === 'completed').length;
  const pendingCount = appointments.filter(a => a.status === 'pending').length;
  const totalIntakes = intakeRecords.length;

  // Update appointment status handler
  const handleStatusChange = (id: string, newStatus: 'confirmed' | 'completed' | 'pending') => {
    const updated = appointments.map(apt => 
      apt.id === id ? { ...apt, status: newStatus } : apt
    );
    onUpdateAppointments(updated);
  };

  // Add Walk-In Appointment
  const handleAddWalkIn = (e: React.FormEvent) => {
    e.preventDefault();
    if (!walkInName.trim() || !walkInPhone.trim()) return;

    const newSlot: AppointmentSlot = {
      id: 'apt_walkin_' + Date.now(),
      serviceId: 'srv_walkin',
      serviceName: walkInService,
      doctorName: DOCTOR_INFO.name,
      date: walkInDate,
      time: walkInTime,
      durationMinutes: 45,
      status: 'confirmed',
      patientName: walkInName.trim(),
      phone: walkInPhone.trim(),
      email: walkInEmail.trim() || 'walkin@clinic.local',
      notes: walkInNotes
    };

    onUpdateAppointments([newSlot, ...appointments]);
    setShowAddWalkIn(false);
    setWalkInName('');
    setWalkInPhone('');
    setWalkInEmail('');
  };

  // Safe CSV cell escaping
  const escapeCsv = (str: string | number | undefined | null): string => {
    if (str === undefined || str === null) return '""';
    const clean = String(str).replace(/"/g, '""');
    return `"${clean}"`;
  };

  // Export to Excel / CSV with UTF-8 BOM
  const handleExportToExcel = (type: 'all' | 'appointments' | 'intakes') => {
    let csvContent = '\uFEFF'; // UTF-8 Byte Order Mark for Excel
    const timestamp = new Date().toISOString().split('T')[0];
    let fileName = `Dr_Swati_Dental_Clinic_Master_Data_${timestamp}.csv`;

    if (type === 'appointments' || type === 'all') {
      csvContent += '--- APPOINTMENTS & BOOKINGS ---\n';
      csvContent += [
        'Appointment ID',
        'Patient Full Name',
        'Phone Number',
        'Email Address',
        'Service Requested',
        'Doctor Assigned',
        'Scheduled Date',
        'Scheduled Time',
        'Duration (Minutes)',
        'Status',
        'Clinical Notes'
      ].map(escapeCsv).join(',') + '\n';

      appointments.forEach(apt => {
        csvContent += [
          apt.id,
          apt.patientName,
          apt.phone,
          apt.email,
          apt.serviceName,
          apt.doctorName,
          apt.date,
          apt.time,
          apt.durationMinutes,
          apt.status.toUpperCase(),
          apt.notes || 'None'
        ].map(escapeCsv).join(',') + '\n';
      });

      csvContent += '\n';
    }

    if (type === 'intakes' || type === 'all') {
      csvContent += '--- PATIENT INTAKE & MEDICAL CONSENT RECORDS ---\n';
      csvContent += [
        'Patient Name',
        'Date of Birth',
        'Gender',
        'Phone',
        'Email',
        'Address',
        'Anxiety Score (1-5)',
        'Allergies',
        'Medical Conditions',
        'Current Medications',
        'Primary Concern',
        'Pain Score (0-10)',
        'Symptoms Reported',
        'Consent Signed',
        'Consent Date'
      ].map(escapeCsv).join(',') + '\n';

      intakeRecords.forEach(rec => {
        csvContent += [
          rec.fullName,
          rec.dateOfBirth,
          rec.gender,
          rec.phone,
          rec.email,
          rec.address,
          rec.dentalAnxietyScore,
          rec.allergies.join('; '),
          rec.medicalConditions.join('; '),
          rec.medications,
          rec.primaryConcern,
          rec.painLevel,
          rec.symptoms.join('; '),
          rec.consentSigned ? 'YES' : 'NO',
          rec.consentDate
        ].map(escapeCsv).join(',') + '\n';
      });

      csvContent += '\n';
    }

    if (type === 'all' && customerUsers.length > 0) {
      csvContent += '--- REGISTERED CLINIC ACCOUNTS ---\n';
      csvContent += [
        'Patient UHID',
        'Name',
        'Phone',
        'Email',
        'Registered Date'
      ].map(escapeCsv).join(',') + '\n';

      customerUsers.forEach(u => {
        csvContent += [
          u.uhid,
          u.name,
          u.phone,
          u.email,
          u.registeredDate
        ].map(escapeCsv).join(',') + '\n';
      });
    }

    // Trigger Download
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', fileName);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setExportNotice(`Excel sheet successfully exported: ${fileName}`);
    setTimeout(() => setExportNotice(null), 4000);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/85 backdrop-blur-md flex flex-col justify-start">
      {/* Top Gold Gradient Bar */}
      <div 
        style={{
          background: 'linear-gradient(90deg, #99762e 0%, #d1c458 35%, #fef08a 50%, #d1c458 65%, #b48b35 100%)'
        }}
        className="h-2 w-full sticky top-0 z-60"
      />

      {/* Main Container */}
      <div className="min-h-screen flex flex-col bg-[#0b0e14] text-slate-100">
        {/* Dashboard Navigation Header */}
        <header className="sticky top-2 z-50 bg-[#0f141c]/95 border-b border-white/10 px-4 sm:px-6 lg:px-8 py-3.5 backdrop-blur-md shadow-xl">
          <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Left: Branding & Staff Badge */}
            <div className="flex items-center gap-3.5 w-full md:w-auto justify-between md:justify-start">
              <div className="flex items-center gap-3">
                <SdaLogo size="sm" showSubtitle={false} />
                <div>
                  <div className="flex items-center gap-2">
                    <h1 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2">
                      <span>Clinic Admin Command Center</span>
                    </h1>
                    <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-300 border border-emerald-500/40">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                      Live Database
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 flex items-center gap-1.5">
                    <span>Logged in as:</span>
                    <strong className="text-teal-400 font-mono">SwatiDentalClinic</strong>
                    <span>• {DOCTOR_INFO.clinicName}</span>
                  </p>
                </div>
              </div>

              {/* Mobile Close Button */}
              <button
                onClick={onClose}
                className="md:hidden p-2 rounded-xl bg-white/10 text-slate-300 hover:text-white"
                aria-label="Close dashboard"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Right: Actions (Excel Export, Add Walk-in, Close, Logout) */}
            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
              {/* Export to Excel Primary Button */}
              <div className="relative group">
                <button
                  type="button"
                  onClick={() => handleExportToExcel('all')}
                  className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-md transition active:scale-95"
                  title="Export all collected patient and appointment data to Excel compatible format"
                >
                  <FileSpreadsheet className="w-4 h-4 text-emerald-100" />
                  <span>Export to Excel (.xlsx/.csv)</span>
                  <Download className="w-3.5 h-3.5 opacity-80" />
                </button>
              </div>

              {/* Add Walk-in Patient */}
              <button
                type="button"
                onClick={() => setShowAddWalkIn(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-teal-800/80 hover:bg-teal-700 text-teal-100 text-xs font-bold border border-teal-500/30 transition"
              >
                <Plus className="w-4 h-4 text-teal-300" />
                <span className="hidden sm:inline">Add Walk-In</span>
              </button>

              {/* Return to Portal */}
              <button
                type="button"
                onClick={onClose}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-200 text-xs font-semibold border border-white/10 transition"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline">Close</span>
              </button>

              {/* Logout */}
              <button
                type="button"
                onClick={() => {
                  try {
                    sessionStorage.removeItem('sda_clinic_admin_authenticated');
                  } catch {
                    // ignore
                  }
                  onLogout();
                  onClose();
                }}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/80 text-rose-200 text-xs font-semibold border border-rose-500/30 transition"
                title="Sign out of clinic administrative session"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Logout</span>
              </button>
            </div>
          </div>
        </header>

        {/* Export Notification Toast */}
        {exportNotice && (
          <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 mt-3">
            <div className="p-3 rounded-2xl bg-emerald-950 border border-emerald-500/50 text-emerald-200 text-xs flex items-center justify-between shadow-lg">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{exportNotice}</span>
              </div>
              <button 
                onClick={() => setExportNotice(null)}
                className="text-emerald-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Dashboard Content */}
        <main className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 space-y-6 flex-1">
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            <div className="bg-[#141b24] p-4 rounded-2xl border border-white/5 shadow-md">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Total Bookings</span>
                <Calendar className="w-4 h-4 text-teal-400" />
              </div>
              <p className="text-2xl font-bold text-white mt-1.5">{totalAppointments}</p>
              <div className="flex items-center gap-2 mt-2 text-[11px] text-slate-400">
                <span className="text-emerald-400 font-semibold">{confirmedCount} Confirmed</span>
                <span>•</span>
                <span className="text-teal-400">{completedCount} Done</span>
              </div>
            </div>

            <div className="bg-[#141b24] p-4 rounded-2xl border border-white/5 shadow-md">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Intakes & Consents</span>
                <FileText className="w-4 h-4 text-emerald-400" />
              </div>
              <p className="text-2xl font-bold text-white mt-1.5">{totalIntakes}</p>
              <p className="text-[11px] text-emerald-400 font-semibold mt-2 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> 100% Signed Digital HIPAA
              </p>
            </div>

            <div className="bg-[#141b24] p-4 rounded-2xl border border-white/5 shadow-md">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Registered Patients</span>
                <Users className="w-4 h-4 text-amber-400" />
              </div>
              <p className="text-2xl font-bold text-white mt-1.5">{customerUsers.length || totalIntakes || 4}</p>
              <p className="text-[11px] text-slate-400 mt-2">
                Unique Patient UHID Records
              </p>
            </div>

            <div className="bg-[#141b24] p-4 rounded-2xl border border-white/5 shadow-md">
              <div className="flex items-center justify-between text-slate-400 text-xs">
                <span>Doctor On Duty</span>
                <Stethoscope className="w-4 h-4 text-[#d1c458]" />
              </div>
              <p className="text-base font-bold text-white mt-1.5 truncate">{DOCTOR_INFO.name}</p>
              <p className="text-[11px] text-[#d1c458] mt-2 font-medium">
                {DOCTOR_INFO.degrees} • In Clinic
              </p>
            </div>
          </div>

          {/* Controls Bar: Tabs, Search & Status Filters */}
          <div className="bg-[#141b24] p-3 rounded-2xl border border-white/5 flex flex-col md:flex-row items-center justify-between gap-3 shadow-md">
            {/* Tabs */}
            <div className="flex p-1 bg-black/40 rounded-xl w-full md:w-auto text-xs font-bold overflow-x-auto">
              <button
                type="button"
                onClick={() => setActiveTab('appointments')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition shrink-0 ${
                  activeTab === 'appointments'
                    ? 'bg-[#00685F] text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Calendar className="w-4 h-4" />
                <span>Appointments ({appointments.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('intakes')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition shrink-0 ${
                  activeTab === 'intakes'
                    ? 'bg-[#00685F] text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Intake Records ({intakeRecords.length})</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('patients')}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg transition shrink-0 ${
                  activeTab === 'patients'
                    ? 'bg-[#00685F] text-white shadow-xs'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>Patient Accounts ({customerUsers.length})</span>
              </button>
            </div>

            {/* Search & Filter */}
            <div className="flex items-center gap-2.5 w-full md:w-auto">
              <div className="relative flex-1 md:w-64">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search patient, phone, date..."
                  className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-teal-500"
                />
              </div>

              {activeTab === 'appointments' && (
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="px-2.5 py-1.5 rounded-xl bg-black/40 border border-white/10 text-xs text-slate-200 focus:outline-none focus:border-teal-500"
                >
                  <option value="all">All Status</option>
                  <option value="confirmed">Confirmed</option>
                  <option value="completed">Completed</option>
                  <option value="pending">Pending</option>
                </select>
              )}
            </div>
          </div>

          {/* TAB 1: APPOINTMENTS TABLE */}
          {activeTab === 'appointments' && (
            <div className="bg-[#141b24] rounded-2xl border border-white/5 overflow-hidden shadow-lg">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Patient Scheduled Appointments
                  </h3>
                  <p className="text-xs text-slate-400">
                    Showing {filteredAppointments.length} of {appointments.length} total bookings
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleExportToExcel('appointments')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-200 transition"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Export Appointments</span>
                </button>
              </div>

              {filteredAppointments.length === 0 ? (
                <div className="p-12 text-center text-slate-500 space-y-2">
                  <Calendar className="w-10 h-10 mx-auto text-slate-600 opacity-60" />
                  <p className="text-sm font-medium">No appointments match your filter.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-black/30 text-slate-400 uppercase tracking-wider text-[10px] border-b border-white/5">
                      <tr>
                        <th className="px-4 py-3">Patient</th>
                        <th className="px-4 py-3">Date & Time</th>
                        <th className="px-4 py-3">Treatment / Service</th>
                        <th className="px-4 py-3">Direct Contact</th>
                        <th className="px-4 py-3">Status</th>
                        <th className="px-4 py-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {filteredAppointments.map((apt) => (
                        <tr key={apt.id} className="hover:bg-white/5 transition">
                          {/* Patient */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2.5">
                              <div className="w-8 h-8 rounded-full bg-teal-900/60 border border-teal-500/30 flex items-center justify-center text-teal-300 font-bold shrink-0">
                                {apt.patientName.charAt(0)}
                              </div>
                              <div>
                                <span className="font-bold text-white block">{apt.patientName}</span>
                                <span className="text-[11px] text-slate-400 font-mono">{apt.id}</span>
                              </div>
                            </div>
                          </td>

                          {/* Date & Time */}
                          <td className="px-4 py-3">
                            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
                              <Calendar className="w-3.5 h-3.5 text-teal-400" />
                              <span>{apt.date}</span>
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                              <Clock className="w-3 h-3 text-slate-400" />
                              <span>{apt.time} ({apt.durationMinutes} min)</span>
                            </div>
                          </td>

                          {/* Service */}
                          <td className="px-4 py-3">
                            <span className="font-medium text-slate-200 block">{apt.serviceName}</span>
                            {apt.notes && (
                              <span className="text-[11px] text-slate-400 italic block mt-0.5 line-clamp-1">
                                "{apt.notes}"
                              </span>
                            )}
                          </td>

                          {/* Contact & WhatsApp */}
                          <td className="px-4 py-3">
                            <div className="flex items-center gap-2">
                              <a
                                href={`tel:${apt.phone}`}
                                className="text-teal-400 hover:underline flex items-center gap-1"
                                title="Call patient"
                              >
                                <Phone className="w-3 h-3" />
                                <span>{apt.phone}</span>
                              </a>
                              <a
                                href={`https://wa.me/${apt.phone.replace(/\D/g, '')}?text=Hello%20${encodeURIComponent(apt.patientName)}%2C%20this%20is%20Dr.%20Swati%27s%20Dental%20Clinic%20regarding%20your%20appointment%20on%20${encodeURIComponent(apt.date)}.`}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 rounded bg-[#20e688]/20 hover:bg-[#20e688]/30 text-[#20e688]"
                                title="Open WhatsApp Chat"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </a>
                            </div>
                            <span className="text-[11px] text-slate-400 block truncate max-w-[140px] mt-0.5">
                              {apt.email}
                            </span>
                          </td>

                          {/* Status */}
                          <td className="px-4 py-3">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                              apt.status === 'confirmed'
                                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-500/40'
                                : apt.status === 'completed'
                                ? 'bg-teal-950/80 text-teal-300 border-teal-500/40'
                                : 'bg-amber-950/80 text-amber-300 border-amber-500/40'
                            }`}>
                              {apt.status === 'confirmed' && <CheckCircle2 className="w-3 h-3 text-emerald-400" />}
                              {apt.status}
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              {apt.status !== 'confirmed' && (
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(apt.id, 'confirmed')}
                                  className="px-2 py-1 rounded bg-emerald-900/60 hover:bg-emerald-800 text-[10px] font-semibold text-emerald-200 border border-emerald-500/30"
                                >
                                  Confirm
                                </button>
                              )}
                              {apt.status !== 'completed' && (
                                <button
                                  type="button"
                                  onClick={() => handleStatusChange(apt.id, 'completed')}
                                  className="px-2 py-1 rounded bg-teal-900/60 hover:bg-teal-800 text-[10px] font-semibold text-teal-200 border border-teal-500/30"
                                >
                                  Complete
                                </button>
                              )}
                              <button
                                type="button"
                                onClick={() => setPatientToRemove({ type: 'appointment', id: apt.id, name: apt.patientName })}
                                className="px-2 py-1 rounded bg-rose-950/70 hover:bg-rose-900 text-[10px] font-semibold text-rose-300 border border-rose-500/30 inline-flex items-center gap-1 transition"
                                title={`Remove appointment for ${apt.patientName}`}
                              >
                                <Trash2 className="w-3 h-3 text-rose-400" />
                                <span>Remove</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: INTAKE & MEDICAL RECORDS */}
          {activeTab === 'intakes' && (
            <div className="bg-[#141b24] rounded-2xl border border-white/5 overflow-hidden shadow-lg">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Digital Patient Intake & Medical History Records
                  </h3>
                  <p className="text-xs text-slate-400">
                    Compliant clinical charts with signed digital legal consent
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => handleExportToExcel('intakes')}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-200 transition"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Export Intakes</span>
                </button>
              </div>

              {filteredIntakes.length === 0 ? (
                <div className="p-12 text-center text-slate-500">
                  <FileText className="w-10 h-10 mx-auto text-slate-600 opacity-60 mb-2" />
                  <p className="text-sm font-medium">No intake records found.</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {filteredIntakes.map((intake, idx) => (
                    <div key={idx} className="p-4 hover:bg-white/5 transition flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-3">
                          <h4 className="text-sm font-bold text-white">
                            {intake.fullName}
                          </h4>
                          <span className="text-[11px] text-slate-400 font-mono">
                            DOB: {intake.dateOfBirth} ({intake.gender})
                          </span>
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-950/70 text-emerald-300 border border-emerald-500/40">
                            <CheckCircle2 className="w-3 h-3" /> Consent Verified
                          </span>
                        </div>

                        <div className="text-xs text-slate-300 flex flex-wrap items-center gap-3">
                          <span className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-teal-400" />
                            {intake.phone}
                          </span>
                          <span className="flex items-center gap-1">
                            <Mail className="w-3 h-3 text-teal-400" />
                            {intake.email}
                          </span>
                          <span className="text-slate-400">
                            Signed on: <strong>{intake.consentDate}</strong>
                          </span>
                        </div>

                        <p className="text-xs text-slate-400 mt-1">
                          <strong>Chief Complaint:</strong> {intake.primaryConcern} (Pain Level: {intake.painLevel}/10)
                        </p>

                        <div className="flex flex-wrap items-center gap-2 mt-2">
                          <span className="text-[11px] font-semibold text-slate-400">Allergies:</span>
                          {intake.allergies.map((all, i) => (
                            <span key={i} className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                              all.includes('None') || all.includes('NKDA')
                                ? 'bg-slate-800 text-slate-300'
                                : 'bg-rose-950/70 text-rose-300 border border-rose-500/40'
                            }`}>
                              {all}
                            </span>
                          ))}

                          <span className="text-[11px] font-semibold text-slate-400 ml-2">Dental Anxiety:</span>
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-950/70 text-amber-300 border border-amber-500/40">
                            Level {intake.dentalAnxietyScore}/5
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => setSelectedIntake(intake)}
                          className="px-3 py-1.5 rounded-xl bg-teal-900/60 hover:bg-teal-800 text-teal-200 text-xs font-semibold border border-teal-500/30 transition shrink-0"
                        >
                          View Full Medical Chart
                        </button>
                        <button
                          type="button"
                          onClick={() => setPatientToRemove({ type: 'intake', id: String(idx), name: intake.fullName, index: idx })}
                          className="px-2.5 py-1.5 rounded-xl bg-rose-950/70 hover:bg-rose-900 text-rose-300 text-xs font-semibold border border-rose-500/30 transition shrink-0 inline-flex items-center gap-1.5"
                          title={`Remove intake chart for ${intake.fullName}`}
                        >
                          <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                          <span>Remove</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* TAB 3: REGISTERED PATIENT ACCOUNTS */}
          {activeTab === 'patients' && (
            <div className="bg-[#141b24] rounded-2xl border border-white/5 overflow-hidden shadow-lg">
              <div className="p-4 border-b border-white/5 flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">
                    Registered Patient Portal Accounts
                  </h3>
                  <p className="text-xs text-slate-400">
                    Patient accounts with verified Unique Healthcare Identification (UHID)
                  </p>
                </div>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-black/30 text-slate-400 uppercase tracking-wider text-[10px] border-b border-white/5">
                    <tr>
                      <th className="px-4 py-3">Patient UHID</th>
                      <th className="px-4 py-3">Name</th>
                      <th className="px-4 py-3">Phone</th>
                      <th className="px-4 py-3">Email</th>
                      <th className="px-4 py-3">Registration Date</th>
                      <th className="px-4 py-3 text-center">Admin Verification & X-Ray Access</th>
                      <th className="px-4 py-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-white/5">
                    {filteredPatients.length === 0 ? (
                      <tr>
                        <td colSpan={7} className="px-4 py-8 text-center text-slate-500">
                          <Users className="w-8 h-8 mx-auto text-slate-600 opacity-60 mb-1" />
                          <span>No patient accounts found matching search.</span>
                        </td>
                      </tr>
                    ) : (
                      filteredPatients.map((user, idx) => (
                        <tr key={user.id || idx} className="hover:bg-white/5 transition">
                          <td className="px-4 py-3 font-mono font-bold text-teal-400">
                            {user.uhid}
                          </td>
                          <td className="px-4 py-3 font-bold text-white">
                            {user.name}
                          </td>
                          <td className="px-4 py-3 text-slate-300">
                            {user.phone}
                          </td>
                          <td className="px-4 py-3 text-slate-300">
                            {user.email}
                          </td>
                          <td className="px-4 py-3 text-slate-400">
                            {user.registeredDate}
                          </td>
                          <td className="px-4 py-3 text-center">
                            {user.isVerified !== false ? (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                                <CheckCircle2 className="w-3 h-3 text-emerald-400" /> Verified (X-Rays & Reports Open)
                              </span>
                            ) : (
                              <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-400 bg-amber-950/60 px-2.5 py-0.5 rounded-full border border-amber-500/30">
                                <AlertCircle className="w-3 h-3 text-amber-400" /> Pending Admin Verification
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="flex items-center justify-end gap-1.5 relative">
                              <button
                                type="button"
                                onClick={() => handleToggleVerification(user.id, user.name)}
                                className={`px-2 py-1 rounded-lg text-[10px] font-bold transition border inline-flex items-center gap-1 ${
                                  user.isVerified !== false
                                    ? 'bg-amber-950/70 hover:bg-amber-900 text-amber-300 border-amber-500/30'
                                    : 'bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 border-emerald-500/30'
                                }`}
                                title="Verify or revoke patient access to reports and digital X-rays"
                              >
                                <ShieldCheck className="w-3 h-3" />
                                <span>{user.isVerified !== false ? 'Lock X-Rays' : 'Verify for X-Rays'}</span>
                              </button>

                              {/* 3 Dot Clinical Options Button */}
                              <div className="relative">
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setOpenMenuPatientId(openMenuPatientId === user.id ? null : user.id);
                                  }}
                                  className={`p-1 rounded-lg border transition inline-flex items-center justify-center ${
                                    openMenuPatientId === user.id
                                      ? 'bg-teal-600 text-white border-teal-400'
                                      : 'bg-white/10 hover:bg-white/20 text-slate-200 border-white/15'
                                  }`}
                                  title="Clinical actions (Remarks, Upload X-Rays, Prescription)"
                                >
                                  <MoreVertical className="w-3.5 h-3.5" />
                                </button>

                                {/* Dropdown Menu */}
                                {openMenuPatientId === user.id && (
                                  <div 
                                    className="absolute right-0 top-full mt-1.5 w-64 bg-[#161c24] border border-white/20 rounded-xl shadow-2xl z-50 py-1.5 text-left divide-y divide-white/10"
                                    onClick={(e) => e.stopPropagation()}
                                  >
                                    <div className="px-3 py-1.5 text-[10px] font-bold text-teal-400 uppercase tracking-wider flex items-center justify-between">
                                      <span>Clinical Actions</span>
                                      <span className="font-mono text-slate-400 text-[9px]">{user.phone}</span>
                                    </div>
                                    <div className="py-1">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setOpenMenuPatientId(null);
                                          setSelectedPatientForClinical(user);
                                          setActiveClinicalModal('remarks');
                                        }}
                                        className="w-full px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-teal-500/20 hover:text-teal-300 flex items-center gap-2.5 transition text-left"
                                      >
                                        <MessageSquarePlus className="w-4 h-4 text-teal-400 shrink-0" />
                                        <div>
                                          <div className="font-bold">Remark Section</div>
                                          <div className="text-[10px] text-slate-400 font-normal">Add clinical notes & observations</div>
                                        </div>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          setOpenMenuPatientId(null);
                                          setSelectedPatientForClinical(user);
                                          setActiveClinicalModal('xrays');
                                        }}
                                        className="w-full px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-cyan-500/20 hover:text-cyan-300 flex items-center gap-2.5 transition text-left"
                                      >
                                        <Upload className="w-4 h-4 text-cyan-400 shrink-0" />
                                        <div>
                                          <div className="font-bold">Upload Digital X-Rays</div>
                                          <div className="text-[10px] text-slate-400 font-normal">Attach OPG, IOPA or scans</div>
                                        </div>
                                      </button>

                                      <button
                                        type="button"
                                        onClick={() => {
                                          setOpenMenuPatientId(null);
                                          setSelectedPatientForClinical(user);
                                          setActiveClinicalModal('prescription');
                                        }}
                                        className="w-full px-3 py-2 text-xs font-semibold text-slate-200 hover:bg-emerald-500/20 hover:text-emerald-300 flex items-center gap-2.5 transition text-left"
                                      >
                                        <Pill className="w-4 h-4 text-emerald-400 shrink-0" />
                                        <div>
                                          <div className="font-bold">Clinical Dental Prescription</div>
                                          <div className="text-[10px] text-slate-400 font-normal">Issue Rx medications & regimen</div>
                                        </div>
                                      </button>
                                    </div>

                                    <div className="py-1">
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setOpenMenuPatientId(null);
                                          setPatientToRemove({ type: 'patient', id: user.id, name: user.name });
                                        }}
                                        className="w-full px-3 py-1.5 text-[11px] font-semibold text-rose-300 hover:bg-rose-950/60 flex items-center gap-2 transition text-left"
                                      >
                                        <Trash2 className="w-3 h-3 text-rose-400" />
                                        <span>Remove Patient Account</span>
                                      </button>
                                    </div>
                                  </div>
                                )}
                              </div>
                            </div>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: ADD WALK-IN APPOINTMENT */}
      {showAddWalkIn && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-white/10 rounded-2xl w-full max-w-md p-6 text-white space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <h3 className="text-base font-bold flex items-center gap-2">
                <Plus className="w-4 h-4 text-teal-400" />
                <span>Add Walk-In Patient Appointment</span>
              </h3>
              <button onClick={() => setShowAddWalkIn(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddWalkIn} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-300 font-bold mb-1">Patient Name</label>
                <input
                  type="text"
                  value={walkInName}
                  onChange={(e) => setWalkInName(e.target.value)}
                  placeholder="e.g. Rahul Sharma"
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={walkInPhone}
                    onChange={(e) => setWalkInPhone(e.target.value)}
                    placeholder="+91 98765..."
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Email</label>
                  <input
                    type="email"
                    value={walkInEmail}
                    onChange={(e) => setWalkInEmail(e.target.value)}
                    placeholder="patient@mail.com"
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-300 font-bold mb-1">Clinical Service</label>
                <select
                  value={walkInService}
                  onChange={(e) => setWalkInService(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                >
                  <option value="Diagnostic Consultation & Scaling">Diagnostic Consultation & Scaling</option>
                  <option value="Emergency Toothache Relief">Emergency Toothache Relief</option>
                  <option value="Root Canal Treatment">Root Canal Treatment</option>
                  <option value="Aesthetic Smile & Whitening">Aesthetic Smile & Whitening</option>
                  <option value="Composite Filling">Composite Filling</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Date</label>
                  <input
                    type="date"
                    value={walkInDate}
                    onChange={(e) => setWalkInDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-bold mb-1">Time</label>
                  <input
                    type="text"
                    value={walkInTime}
                    onChange={(e) => setWalkInTime(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-black/40 border border-white/10 text-white focus:outline-none focus:border-teal-500"
                  />
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddWalkIn(false)}
                  className="px-4 py-2 rounded-xl bg-white/10 text-slate-300 text-xs font-semibold hover:bg-white/20"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-[#00685F] text-white text-xs font-bold hover:bg-[#005049]"
                >
                  Add Appointment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: VIEW FULL INTAKE DETAILS */}
      {selectedIntake && (
        <div className="fixed inset-0 z-70 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-white/10 rounded-2xl w-full max-w-2xl p-6 text-white space-y-4 shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileText className="w-5 h-5 text-teal-400" />
                  <span>Clinical Patient Intake Chart: {selectedIntake.fullName}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  Phone: {selectedIntake.phone} • Email: {selectedIntake.email}
                </p>
              </div>
              <button onClick={() => setSelectedIntake(null)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-black/30 p-3 rounded-xl">
                <div>
                  <span className="text-slate-400 block text-[11px]">Date of Birth</span>
                  <span className="font-semibold text-white">{selectedIntake.dateOfBirth}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Gender</span>
                  <span className="font-semibold text-white">{selectedIntake.gender}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[11px]">Dental Anxiety</span>
                  <span className="font-semibold text-amber-300">Level {selectedIntake.dentalAnxietyScore}/5</span>
                </div>
              </div>

              <div className="bg-black/30 p-3 rounded-xl space-y-2">
                <h4 className="font-bold text-teal-400 text-xs uppercase tracking-wider">Chief Complaint & Symptoms</h4>
                <p className="text-slate-200"><strong>Primary Concern:</strong> {selectedIntake.primaryConcern}</p>
                <p className="text-slate-200"><strong>Pain Scale:</strong> {selectedIntake.painLevel}/10</p>
                <p className="text-slate-200"><strong>Duration:</strong> {selectedIntake.symptomDuration}</p>
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {selectedIntake.symptoms.map((s, idx) => (
                    <span key={idx} className="px-2 py-0.5 rounded bg-teal-950/80 text-teal-300 text-[10px] border border-teal-500/30">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-black/30 p-3 rounded-xl space-y-2">
                <h4 className="font-bold text-teal-400 text-xs uppercase tracking-wider">Medical History & Allergies</h4>
                <p className="text-slate-200"><strong>Allergies:</strong> {selectedIntake.allergies.join(', ')}</p>
                <p className="text-slate-200"><strong>Medical Conditions:</strong> {selectedIntake.medicalConditions.join(', ')}</p>
                <p className="text-slate-200"><strong>Medications:</strong> {selectedIntake.medications || 'None'}</p>
                <p className="text-slate-200"><strong>Pregnancy Status:</strong> {selectedIntake.isPregnant ? 'Yes' : 'No'}</p>
              </div>

              <div className="bg-emerald-950/40 border border-emerald-500/30 p-3 rounded-xl flex items-center justify-between">
                <div>
                  <span className="text-emerald-300 font-bold block">HIPAA Legal Informed Consent</span>
                  <span className="text-[11px] text-slate-300">Signed digitally on {selectedIntake.consentDate}</span>
                </div>
                <span className="px-2.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 font-bold text-[10px] border border-emerald-500/40">
                  ✓ Valid Signature
                </span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-between border-t border-white/10">
              <button
                type="button"
                onClick={() => {
                  const idx = intakeRecords.findIndex(r => r.fullName === selectedIntake.fullName);
                  setPatientToRemove({ type: 'intake', id: String(idx), name: selectedIntake.fullName, index: idx });
                }}
                className="px-3 py-1.5 rounded-xl bg-rose-950/70 hover:bg-rose-900 text-rose-300 text-xs font-semibold border border-rose-500/30 inline-flex items-center gap-1.5 transition"
              >
                <Trash2 className="w-3.5 h-3.5 text-rose-400" />
                <span>Remove Patient Record</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedIntake(null)}
                className="px-4 py-2 rounded-xl bg-white/10 text-white text-xs font-semibold hover:bg-white/20"
              >
                Close Record
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: REMARK SECTION */}
      {activeClinicalModal === 'remarks' && selectedPatientForClinical && (
        <div className="fixed inset-0 z-80 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-teal-500/30 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col text-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/30">
                  <MessageSquarePlus className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Doctor Remarks & Clinical Notes</span>
                    <span className="text-[10px] bg-teal-900/80 text-teal-300 px-2 py-0.5 rounded-full border border-teal-500/30">
                      Mobile: {selectedPatientForClinical.phone}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Patient: <strong className="text-white">{selectedPatientForClinical.name}</strong> • UHID: <span className="font-mono text-teal-300">{selectedPatientForClinical.uhid}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              <div className="bg-teal-950/40 border border-teal-500/20 p-3 rounded-xl text-xs text-teal-200/90 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>
                  Remarks saved here are securely linked to this patient's registered mobile number <strong>{selectedPatientForClinical.phone}</strong> and will be visible when they sign into the patient portal.
                </span>
              </div>

              {/* Form to add new remark */}
              <form onSubmit={handleSaveRemark} className="space-y-3 bg-black/30 p-4 rounded-xl border border-white/10">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <span>Add New Clinical Remark</span>
                  </label>
                  <select
                    value={newRemarkCategory}
                    onChange={(e) => setNewRemarkCategory(e.target.value as any)}
                    className="bg-[#1f2836] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-teal-300 font-semibold focus:outline-none focus:border-teal-500"
                  >
                    <option value="Treatment Plan">Treatment Plan</option>
                    <option value="Examination">Examination Finding</option>
                    <option value="Post-Op Observation">Post-Op Observation</option>
                    <option value="Hygiene Advice">Hygiene Advice</option>
                    <option value="General">General Remark</option>
                  </select>
                </div>

                <textarea
                  value={newRemarkContent}
                  onChange={(e) => setNewRemarkContent(e.target.value)}
                  placeholder="Enter clinical observations, prognosis, diagnosis notes, or home-care advice for this patient..."
                  rows={3}
                  className="w-full bg-[#111722] border border-white/10 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-teal-500"
                  required
                />

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-[#00685F] hover:bg-[#00524b] text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Save Remark to Patient Vault</span>
                  </button>
                </div>
              </form>

              {/* Previous Remarks List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Existing Remarks ({currentPatientVault?.remarks.length || 0})
                </h4>

                {!currentPatientVault || currentPatientVault.remarks.length === 0 ? (
                  <div className="text-center py-6 text-slate-500 text-xs bg-black/20 rounded-xl border border-white/5">
                    No remarks recorded yet for this patient. Add the first remark above.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {currentPatientVault.remarks.map((rem) => (
                      <div key={rem.id} className="p-3.5 rounded-xl bg-slate-900/80 border border-white/10 space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-teal-300 px-2 py-0.5 rounded-md bg-teal-950/70 border border-teal-500/30 text-[10px]">
                            {rem.category}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className="text-[11px] text-slate-400">{rem.date}</span>
                            <button
                              type="button"
                              onClick={() => handleDeleteRemark(rem.id)}
                              className="p-1 rounded text-slate-500 hover:text-rose-400 transition"
                              title="Delete remark"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        <p className="text-xs text-slate-200 leading-relaxed">
                          {rem.content}
                        </p>
                        <div className="text-[10px] text-slate-400 pt-1 border-t border-white/5">
                          Doctor: <strong className="text-slate-300">{rem.doctor}</strong>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-900 border-t border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: UPLOAD DIGITAL X-RAYS */}
      {activeClinicalModal === 'xrays' && selectedPatientForClinical && (
        <div className="fixed inset-0 z-80 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-cyan-500/30 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col text-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                  <Upload className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Upload Digital X-Rays & Radiographs</span>
                    <span className="text-[10px] bg-cyan-900/80 text-cyan-300 px-2 py-0.5 rounded-full border border-cyan-500/30">
                      Mobile: {selectedPatientForClinical.phone}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Patient: <strong className="text-white">{selectedPatientForClinical.name}</strong> • UHID: <span className="font-mono text-cyan-300">{selectedPatientForClinical.uhid}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              <div className="bg-cyan-950/40 border border-cyan-500/20 p-3 rounded-xl text-xs text-cyan-200/90 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <span>
                  Radiographs uploaded here will be visible to <strong>{selectedPatientForClinical.name}</strong> when logging in with registered mobile <strong>{selectedPatientForClinical.phone}</strong> in their digital reports vault.
                </span>
              </div>

              {/* Upload Form */}
              <form onSubmit={handleSaveXray} className="space-y-3 bg-black/30 p-4 rounded-xl border border-white/10">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Radiograph Type
                    </label>
                    <select
                      value={newXrayType}
                      onChange={(e) => setNewXrayType(e.target.value)}
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    >
                      <option value="Intraoral Periapical (IOPA)">Intraoral Periapical (IOPA)</option>
                      <option value="Full Panoramic OPG">Full Panoramic OPG</option>
                      <option value="Bitewing Radiograph">Bitewing Radiograph</option>
                      <option value="Cone Beam CT 3D Slice">Cone Beam CT 3D Slice</option>
                      <option value="Lateral Cephalogram">Lateral Cephalogram</option>
                      <option value="Intraoral Camera High-Res Photo">Intraoral Camera Photo</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Target Tooth / Anatomical Area
                    </label>
                    <input
                      type="text"
                      value={newXrayArea}
                      onChange={(e) => setNewXrayArea(e.target.value)}
                      placeholder="e.g. Tooth #30 Mandibular Molar"
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Radiograph Title / Scan Description
                  </label>
                  <input
                    type="text"
                    value={newXrayTitle}
                    onChange={(e) => setNewXrayTitle(e.target.value)}
                    placeholder="e.g. Post-Endodontic Obturation Verification Scan"
                    className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-cyan-500"
                    required
                  />
                </div>

                {/* File Upload Selector */}
                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Select X-Ray Image File (PNG, JPG, WebP)
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="cursor-pointer px-3.5 py-2 rounded-xl bg-cyan-950/80 hover:bg-cyan-900 border border-cyan-500/40 text-xs font-semibold text-cyan-200 inline-flex items-center gap-2 transition">
                      <Upload className="w-4 h-4 text-cyan-400" />
                      <span>{newXrayFileName ? 'Change Image File' : 'Choose Radiograph Image'}</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                    </label>
                    {newXrayFileName && (
                      <span className="text-xs text-slate-300 truncate max-w-[200px]">
                        {newXrayFileName}
                      </span>
                    )}
                  </div>

                  {/* Image Preview if chosen */}
                  {newXrayDataUrl && (
                    <div className="mt-2.5 p-2 bg-black rounded-xl border border-white/10 max-h-40 overflow-hidden flex items-center justify-center">
                      <img
                        src={newXrayDataUrl}
                        alt="X-Ray preview"
                        className="max-h-36 object-contain rounded"
                      />
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Dr. Swati's Clinical Radiographic Interpretation
                  </label>
                  <textarea
                    value={newXrayFindings}
                    onChange={(e) => setNewXrayFindings(e.target.value)}
                    placeholder="Describe bone density, lamina dura continuity, apex length, obturation seal, or absence of periapical radiolucency..."
                    rows={2}
                    className="w-full bg-[#111722] border border-white/10 rounded-xl p-3 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-4 h-4" />
                    <span>Upload & Attach Radiograph</span>
                  </button>
                </div>
              </form>

              {/* Uploaded Radiographs List */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Patient Radiographs ({currentPatientVault?.xrays.length || 0})
                </h4>

                {!currentPatientVault || currentPatientVault.xrays.length === 0 ? (
                  <div className="text-center py-6 text-slate-500 text-xs bg-black/20 rounded-xl border border-white/5">
                    No radiographs uploaded yet for this patient.
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {currentPatientVault.xrays.map((xray) => (
                      <div key={xray.id} className="p-3 rounded-xl bg-slate-900 border border-white/10 space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-cyan-300 text-[11px] truncate max-w-[150px]">
                            {xray.title}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeleteXray(xray.id)}
                            className="p-1 rounded text-slate-500 hover:text-rose-400 transition"
                            title="Delete radiograph"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>

                        {xray.imageDataUrl ? (
                          <div className="h-28 bg-black rounded-lg overflow-hidden flex items-center justify-center border border-white/10">
                            <img src={xray.imageDataUrl} alt={xray.title} className="h-full w-full object-cover" />
                          </div>
                        ) : (
                          <div className="h-24 bg-slate-950 rounded-lg flex flex-col items-center justify-center text-slate-400 border border-white/5">
                            <ImageIcon className="w-6 h-6 text-teal-400 opacity-60 mb-1" />
                            <span className="text-[10px]">{xray.type}</span>
                          </div>
                        )}

                        <div className="text-[10px] text-slate-400 space-y-0.5">
                          <div>Area: <strong className="text-slate-200">{xray.anatomicalArea}</strong></div>
                          <div>Date: {xray.date}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-900 border-t border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: CLINICAL DENTAL PRESCRIPTION */}
      {activeClinicalModal === 'prescription' && selectedPatientForClinical && (
        <div className="fixed inset-0 z-80 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-emerald-500/30 rounded-2xl w-full max-w-xl max-h-[90vh] flex flex-col text-white shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-150">
            {/* Header */}
            <div className="p-4 bg-slate-900 border-b border-white/10 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>Clinical Dental Prescription (Rx)</span>
                    <span className="text-[10px] bg-emerald-900/80 text-emerald-300 px-2 py-0.5 rounded-full border border-emerald-500/30">
                      Mobile: {selectedPatientForClinical.phone}
                    </span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    Patient: <strong className="text-white">{selectedPatientForClinical.name}</strong> • UHID: <span className="font-mono text-emerald-300">{selectedPatientForClinical.uhid}</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Body */}
            <div className="p-5 overflow-y-auto space-y-4 flex-1">
              <div className="bg-emerald-950/40 border border-emerald-500/20 p-3 rounded-xl text-xs text-emerald-200/90 flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>
                  Prescriptions issued here will be immediately accessible to <strong>{selectedPatientForClinical.name}</strong> upon logging into their registered mobile <strong>{selectedPatientForClinical.phone}</strong> with direct print/download capability.
                </span>
              </div>

              {/* Form to issue Rx */}
              <form onSubmit={handleSavePrescription} className="space-y-3 bg-black/30 p-4 rounded-xl border border-white/10">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-300">
                    Prescribe Medication
                  </label>
                  {/* Quick Preset Buttons */}
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] text-slate-400 mr-1">Presets:</span>
                    <button
                      type="button"
                      onClick={() => {
                        setNewRxDrug('Amoxicillin + Potassium Clavulanate 625mg');
                        setNewRxDosage('1 Tablet');
                        setNewRxFrequency('Twice Daily (BID) - After Meals');
                        setNewRxDuration('5 Days');
                        setNewRxInstructions('Take strictly after food with full glass of water. Complete entire antimicrobial course.');
                      }}
                      className="px-2 py-0.5 text-[10px] bg-white/10 hover:bg-white/20 rounded text-slate-300 cursor-pointer"
                    >
                      Amox-Clav 625
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setNewRxDrug('Ketorolac Tromethamine 10mg DT');
                        setNewRxDosage('1 Dispersible Tablet');
                        setNewRxFrequency('SOS (As Needed for Severe Ache)');
                        setNewRxDuration('3 Days');
                        setNewRxInstructions('Dissolve in 1 tbsp water. Max 2 tablets in 24 hours. Take after food.');
                      }}
                      className="px-2 py-0.5 text-[10px] bg-white/10 hover:bg-white/20 rounded text-slate-300 cursor-pointer"
                    >
                      Ketorolac
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setNewRxDrug('Chlorhexidine Gluconate 0.2% w/v Oral Rinse');
                        setNewRxDosage('10 ml rinse');
                        setNewRxFrequency('Twice Daily (Morning & Night)');
                        setNewRxDuration('14 Days');
                        setNewRxInstructions('Swish vigorously for 60 seconds after brushing. Do not eat or drink for 30 minutes.');
                      }}
                      className="px-2 py-0.5 text-[10px] bg-white/10 hover:bg-white/20 rounded text-slate-300 cursor-pointer"
                    >
                      Chlorhexidine
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Drug Name & Strength
                    </label>
                    <input
                      type="text"
                      value={newRxDrug}
                      onChange={(e) => setNewRxDrug(e.target.value)}
                      placeholder="e.g. Amoxicillin + Pot. Clavulanate 625mg"
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Dosage (Form & Quantity)
                    </label>
                    <input
                      type="text"
                      value={newRxDosage}
                      onChange={(e) => setNewRxDosage(e.target.value)}
                      placeholder="e.g. 1 Tablet / 1 Capsule / 10ml"
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Frequency & Timing
                    </label>
                    <input
                      type="text"
                      value={newRxFrequency}
                      onChange={(e) => setNewRxFrequency(e.target.value)}
                      placeholder="e.g. Twice Daily (BID) - After Meals"
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Duration
                    </label>
                    <input
                      type="text"
                      value={newRxDuration}
                      onChange={(e) => setNewRxDuration(e.target.value)}
                      placeholder="e.g. 5 Days"
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                      required
                    />
                  </div>

                  <div>
                    <label className="text-[11px] font-bold text-slate-300 block mb-1">
                      Prescription Status
                    </label>
                    <select
                      value={newRxStatus}
                      onChange={(e) => setNewRxStatus(e.target.value as any)}
                      className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                    >
                      <option value="Active">Active Regimen</option>
                      <option value="Completed">Completed History</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-slate-300 block mb-1">
                    Special Doctor Instructions & Precautions
                  </label>
                  <input
                    type="text"
                    value={newRxInstructions}
                    onChange={(e) => setNewRxInstructions(e.target.value)}
                    placeholder="e.g. Take strictly after food with full glass of water. Avoid dairy within 2 hours."
                    className="w-full bg-[#111722] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-200 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition shadow-xs flex items-center gap-1.5 cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Issue Prescription to Patient</span>
                  </button>
                </div>
              </form>

              {/* Active & Historical Prescriptions */}
              <div className="space-y-2">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Current Prescriptions ({currentPatientVault?.prescriptions.length || 0})
                </h4>

                {!currentPatientVault || currentPatientVault.prescriptions.length === 0 ? (
                  <div className="text-center py-6 text-slate-500 text-xs bg-black/20 rounded-xl border border-white/5">
                    No prescriptions issued yet for this patient.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {currentPatientVault.prescriptions.map((rx) => (
                      <div key={rx.id} className="p-3.5 rounded-xl bg-slate-900 border border-white/10 space-y-1.5 text-xs">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white flex items-center gap-1.5">
                            <Pill className="w-3.5 h-3.5 text-emerald-400" />
                            {rx.drug}
                          </span>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              rx.status === 'Active'
                                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                                : 'bg-slate-800 text-slate-400'
                            }`}>
                              {rx.status}
                            </span>
                            <button
                              type="button"
                              onClick={() => handleDeletePrescription(rx.id)}
                              className="p-1 rounded text-slate-500 hover:text-rose-400 transition"
                              title="Delete prescription"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300 bg-black/20 p-2 rounded-lg">
                          <div>Dosage: <strong className="text-emerald-300">{rx.dosage}</strong></div>
                          <div>Timing: <strong>{rx.frequency}</strong></div>
                          <div>Duration: <strong>{rx.duration}</strong></div>
                          <div>Date: <strong>{rx.date}</strong></div>
                        </div>

                        {rx.instructions && (
                          <p className="text-[11px] text-slate-400 italic">
                            "{rx.instructions}"
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Footer */}
            <div className="p-3 bg-slate-900 border-t border-white/10 flex justify-end">
              <button
                type="button"
                onClick={() => {
                  setActiveClinicalModal(null);
                  setSelectedPatientForClinical(null);
                }}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: CONFIRM REMOVE PATIENT / RECORD */}
      {patientToRemove && (
        <div className="fixed inset-0 z-80 flex items-center justify-center p-4 bg-black/80 backdrop-blur-xs">
          <div className="bg-[#141b24] border border-rose-500/30 rounded-2xl w-full max-w-sm p-5 text-white space-y-4 shadow-2xl">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20">
                <Trash2 className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-white">Remove Patient Record?</h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  Are you sure you want to remove <span className="text-rose-300 font-semibold">{patientToRemove.name}</span>?
                </p>
              </div>
            </div>

            <p className="text-[11px] text-slate-400 bg-black/30 p-2.5 rounded-xl border border-white/5">
              {patientToRemove.type === 'patient' && 'This will remove the patient account from active clinical registrations.'}
              {patientToRemove.type === 'appointment' && 'This will cancel and remove this patient appointment from the schedule.'}
              {patientToRemove.type === 'intake' && 'This will permanently remove this patient intake & consent submission.'}
            </p>

            <div className="flex items-center justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setPatientToRemove(null)}
                className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-slate-300 transition"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={confirmRemove}
                className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-xs font-bold text-white shadow-md transition flex items-center gap-1.5"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Confirm Remove</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
