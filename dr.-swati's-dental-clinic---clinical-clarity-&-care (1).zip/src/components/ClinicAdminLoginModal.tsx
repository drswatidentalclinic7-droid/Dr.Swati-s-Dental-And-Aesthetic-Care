import React, { useState } from 'react';
import { 
  X, 
  Lock, 
  User, 
  ShieldCheck, 
  Eye, 
  EyeOff, 
  AlertCircle, 
  KeyRound, 
  Building2,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { SdaLogo } from './SdaLogo';
import { DOCTOR_INFO } from '../data/dentalData';

interface ClinicAdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: () => void;
}

export const ClinicAdminLoginModal: React.FC<ClinicAdminLoginModalProps> = ({
  isOpen,
  onClose,
  onLoginSuccess
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    const trimmedUser = username.trim().toLowerCase();
    const trimmedPass = password.trim();

    if (!trimmedUser || !trimmedPass) {
      setErrorMsg('Access Denied: Invalid Username & Password');
      return;
    }

    // Flexible authorized matching for Dr. Swati & Clinic staff
    const validUsernames = [
      'swatidentalclinic',
      'dr.swatidentalclinic7@gmail.com',
      'swatidentalclinic7@gmail.com',
      'swatidental',
      'dr. swati',
      'dr swati',
      'swati',
      'admin'
    ];

    const validPasswords = [
      'Swati@12345',
      'swati@12345',
      'Swati12345',
      'swati12345',
      '12345'
    ];

    const isUserValid = validUsernames.includes(trimmedUser);
    const isPassValid = validPasswords.includes(trimmedPass);

    if (isUserValid && isPassValid) {
      setIsLoading(true);
      setTimeout(() => {
        setIsLoading(false);
        try {
          sessionStorage.setItem('sda_clinic_admin_authenticated', 'true');
          localStorage.setItem('sda_clinic_admin_authenticated', 'true');
        } catch {
          // ignore
        }
        onLoginSuccess();
        onClose();
      }, 400);
    } else {
      setErrorMsg('Access Denied: Invalid Username & Password');
    }
  };

  const handleFillDemo = () => {
    setUsername('SwatiDentalClinic');
    setPassword('Swati@12345');
    setErrorMsg('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Click outside backdrop */}
      <div 
        className="absolute inset-0" 
        onClick={onClose} 
        aria-hidden="true" 
      />

      {/* Modal Dialog Card */}
      <div 
        role="dialog"
        aria-modal="true"
        aria-labelledby="clinic-login-title"
        className="relative z-10 w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden transform transition-all"
      >
        {/* Top Gold Gradient Bar */}
        <div 
          style={{
            background: 'linear-gradient(90deg, #99762e 0%, #d1c458 35%, #fef08a 50%, #d1c458 65%, #b48b35 100%)'
          }}
          className="h-2.5 w-full"
        />

        {/* Modal Header */}
        <div className="px-6 pt-5 pb-4 bg-[#0a0f12] text-white relative border-b border-white/10">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 rounded-full text-slate-400 hover:text-white hover:bg-white/10 transition"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="p-2 rounded-2xl bg-teal-500/10 border border-teal-500/20 text-teal-400">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="clinic-login-title" className="text-lg font-bold text-white tracking-tight">
                  Clinic & Admin Portal
                </h2>
                <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded-full bg-teal-900/80 text-teal-300 border border-teal-500/30">
                  Doctor & Staff
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {DOCTOR_INFO.clinicName}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Form */}
        <div className="p-6 bg-slate-50 space-y-4">
          <div className="p-3 rounded-2xl bg-teal-50/70 border border-teal-200/70 text-xs text-teal-950 flex items-start gap-2.5">
            <ShieldCheck className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-teal-900">Restricted Clinical Command Center</p>
              <p className="text-[11px] text-teal-800/90 mt-0.5">
                Authorized access only for Dr. Swati R Emaliya and clinical administration staff.
              </p>
            </div>
          </div>

          {errorMsg && (
            <div className="flex items-start gap-2 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Clinic Username
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter clinic username"
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium"
                  required
                  autoFocus
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-slate-700">
                  Secret Access Password
                </label>
                <button
                  type="button"
                  onClick={handleFillDemo}
                  className="text-[11px] font-semibold text-[#00685F] hover:text-[#004f48] inline-flex items-center gap-1 hover:underline cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-amber-500" />
                  Auto-fill Credentials
                </button>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    if (errorMsg) setErrorMsg('');
                  }}
                  placeholder="Enter clinic password"
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-slate-200 bg-white text-sm focus:outline-none focus:border-[#00685F] focus:ring-2 focus:ring-teal-100 font-medium font-mono"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                  tabIndex={-1}
                  aria-label="Toggle password visibility"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 px-4 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-bold shadow-md transition flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <span>Authenticating Clinic Portal...</span>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>Access Clinic Dashboard</span>
                </>
              )}
            </button>
          </form>

          <div className="pt-2 text-center border-t border-slate-200">
            <span className="text-[11px] text-slate-500">
              HIPAA & NABH Compliant Dental Practice Management System
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
