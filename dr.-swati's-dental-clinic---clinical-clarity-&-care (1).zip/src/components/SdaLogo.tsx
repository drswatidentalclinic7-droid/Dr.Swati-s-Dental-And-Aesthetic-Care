import React from 'react';

interface SdaLogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showSubtitle?: boolean;
  className?: string;
  variant?: 'gold' | 'clinical';
}

export const SdaLogo: React.FC<SdaLogoProps> = ({
  size = 'md',
  showSubtitle = true,
  className = '',
  variant = 'gold'
}) => {
  const dimensionMap = {
    sm: { box: 'w-8 h-8', svgW: 32, svgH: 32, text: 'text-sm' },
    md: { box: 'w-11 h-11', svgW: 44, svgH: 44, text: 'text-base' },
    lg: { box: 'w-16 h-16', svgW: 64, svgH: 64, text: 'text-xl' },
    xl: { box: 'w-24 h-24', svgW: 96, svgH: 96, text: 'text-2xl' },
  };

  const dim = dimensionMap[size];

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Logo Emblem Icon */}
      <div className={`relative ${dim.box} shrink-0 rounded-xl overflow-hidden shadow-sm flex items-center justify-center select-none ${
        variant === 'gold' 
          ? 'bg-gradient-to-br from-[#c9a656] via-[#dfbe73] to-[#99762e] border border-[#f3d994]/60' 
          : 'bg-[#00685F] border border-[#0D9488]'
      }`}>
        {/* SVG Vector Representation of the SDA Golden Tooth & Face Silhouette */}
        <svg
          viewBox="0 0 100 110"
          className="w-[90%] h-[90%]"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <linearGradient id="goldSheen" x1="0" y1="0" x2="100" y2="100" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#fff8db" />
              <stop offset="45%" stopColor="#efce80" />
              <stop offset="75%" stopColor="#b48b35" />
              <stop offset="100%" stopColor="#7a5513" />
            </linearGradient>
            <filter id="emboss" x="-10%" y="-10%" width="120%" height="120%">
              <feDropShadow dx="0.8" dy="1.2" stdDeviation="0.8" floodColor="#3d2806" floodOpacity="0.45" />
            </filter>
          </defs>

          {/* SDA letters */}
          <text
            x="50"
            y="22"
            textAnchor="middle"
            fill={variant === 'gold' ? 'url(#goldSheen)' : '#FFFFFF'}
            fontWeight="900"
            fontSize="19"
            letterSpacing="2"
            fontFamily="serif"
            filter="url(#emboss)"
          >
            SDA
          </text>

          {/* Stylized Tooth Outer Path with Anatomical Cusps */}
          <path
            d="M26 36 C34 32, 42 36, 50 34 C58 36, 66 32, 74 36 C80 40, 81 50, 78 68 C76 80, 70 94, 62 97 C57 99, 53 91, 51 86 C48 91, 44 99, 39 97 C31 93, 25 80, 23 68 C20 50, 21 40, 26 36 Z"
            stroke={variant === 'gold' ? 'url(#goldSheen)' : '#FFFFFF'}
            strokeWidth="4"
            strokeLinecap="round"
            strokeLinejoin="round"
            filter="url(#emboss)"
          />

          {/* Internal Face Silhouette looking to the right inside the tooth */}
          <path
            d="M54 44 C53 47, 54 49, 56 52 C58 55, 60 56, 57 58 C55 59, 56 61, 58 63 C57 65, 55 66, 56 70 C57 74, 52 79, 44 79"
            stroke={variant === 'gold' ? 'url(#goldSheen)' : '#FFFFFF'}
            strokeWidth="3"
            strokeLinecap="round"
            fill="none"
            filter="url(#emboss)"
          />

          {/* Orbit Dynamic Swoop */}
          <path
            d="M14 85 C28 98, 70 88, 86 62"
            stroke={variant === 'gold' ? 'url(#goldSheen)' : '#FFFFFF'}
            strokeWidth="4.5"
            strokeLinecap="round"
            filter="url(#emboss)"
          />
        </svg>
      </div>

      {/* Brand Text */}
      {showSubtitle && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span 
              style={{ color: '#d1c458', textDecoration: 'none' }}
              className={`font-bold tracking-tight ${dim.text}`}
            >
              Dr. Swati's Dental And Aesthetic Care
            </span>
            <span 
              style={{ backgroundColor: '#070808', color: '#d1c458' }}
              className="text-[10px] font-bold tracking-wider px-1.5 py-0.5 rounded border border-[#d1c458]/40"
            >
              SDA
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
