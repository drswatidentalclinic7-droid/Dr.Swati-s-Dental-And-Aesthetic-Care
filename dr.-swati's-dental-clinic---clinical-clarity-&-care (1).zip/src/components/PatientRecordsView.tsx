import React, { useState, useEffect, useMemo } from 'react';
import { DOCTOR_INFO } from '../data/dentalData';
import { 
  FileText, 
  Activity, 
  Calendar, 
  Clock, 
  Pill, 
  ShieldCheck, 
  Sparkles, 
  Eye, 
  CheckCircle2, 
  AlertCircle,
  FileCheck,
  Lock,
  UserCheck,
  MessageSquarePlus,
  Maximize2,
  Printer,
  ChevronRight,
  Download,
  Image as ImageIcon,
  X
} from 'lucide-react';
import { CustomerUser } from './CustomerLoginModal';
import { 
  getPatientClinicalVault, 
  PatientClinicalVault,
  PatientRemark,
  PatientXray,
  PatientPrescription 
} from '../services/clinicalRecordsService';

interface PatientRecordsViewProps {
  currentUser?: CustomerUser | null;
  onOpenLogin?: () => void;
  isClinicAdminAuthenticated?: boolean;
}

export const PatientRecordsView: React.FC<PatientRecordsViewProps> = ({
  currentUser,
  onOpenLogin,
  isClinicAdminAuthenticated = false
}) => {
  const [activeTab, setActiveTab] = useState<'remarks' | 'radiographs' | 'prescriptions' | 'timeline'>('remarks');
  const [xrayInverted, setXrayInverted] = useState<boolean>(false);
  const [zoomedXray, setZoomedXray] = useState<PatientXray | null>(null);
  const [vaultVersion, setVaultVersion] = useState(0);

  // Listen for clinical updates from doctor admin portal in real time
  useEffect(() => {
    const handleUpdate = () => {
      setVaultVersion(v => v + 1);
    };
    window.addEventListener('sda_patient_clinical_updated', handleUpdate);
    return () => window.removeEventListener('sda_patient_clinical_updated', handleUpdate);
  }, []);

  // Retrieve clinical vault tied to the logged-in patient's registered mobile number
  const clinicalVault = useMemo(() => {
    return getPatientClinicalVault(currentUser?.phone || '+91 98765 43210');
  }, [currentUser?.phone, vaultVersion]);

  // If visitor is not logged in as a patient and not clinic admin
  if (!currentUser && !isClinicAdminAuthenticated) {
    return (
      <div className="bg-white rounded-3xl border border-slate-200 p-8 sm:p-12 text-center max-w-xl mx-auto shadow-sm space-y-5 my-8">
        <div className="w-16 h-16 rounded-2xl bg-teal-50 border border-teal-200/80 text-[#00685F] flex items-center justify-center mx-auto shadow-xs">
          <Lock className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 text-[#00685F] text-xs font-bold border border-teal-200/60">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Admin-Verified Patient Portal Only</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Reports & Digital X-Rays Vault
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            Diagnostic reports, full-mouth radiographs, and clinical prescriptions are strictly protected medical data. Please sign into your verified patient account using your registered mobile number to access your records.
          </p>
        </div>

        <div className="pt-2">
          <button
            type="button"
            onClick={onOpenLogin}
            className="px-6 py-3 rounded-2xl bg-[#00685F] hover:bg-[#00524b] text-white text-xs sm:text-sm font-bold shadow-md transition inline-flex items-center gap-2 cursor-pointer"
          >
            <UserCheck className="w-4 h-4" />
            <span>Sign In to Patient Portal</span>
          </button>
        </div>
      </div>
    );
  }

  // If patient account is logged in but pending admin approval
  if (currentUser && currentUser.isVerified === false && !isClinicAdminAuthenticated) {
    return (
      <div className="bg-white rounded-3xl border border-amber-200/80 p-8 sm:p-12 text-center max-w-xl mx-auto shadow-sm space-y-5 my-8">
        <div className="w-16 h-16 rounded-2xl bg-amber-50 border border-amber-200 text-amber-600 flex items-center justify-center mx-auto shadow-xs">
          <AlertCircle className="w-8 h-8" />
        </div>
        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200">
            <Clock className="w-3.5 h-3.5" />
            <span>Account Verification Pending</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
            Verification In Progress
          </h3>
          <p className="text-xs sm:text-sm text-slate-600 leading-relaxed max-w-md mx-auto">
            Welcome, <strong>{currentUser.name}</strong> (Registered Mobile: <span className="font-mono font-bold text-slate-800">{currentUser.phone}</span> • UHID: <span className="font-mono font-bold text-slate-800">{currentUser.uhid}</span>). Your customer profile is currently awaiting verification by Dr. Swati's clinic administration.
          </p>
          <p className="text-xs text-slate-500">
            Once clinic admin approves your profile in the command center, your digital X-rays, clinical remarks, and official prescriptions will unlock automatically.
          </p>
        </div>
      </div>
    );
  }

  const patientDisplayName = currentUser ? currentUser.name : 'Sarah Jenkins';
  const patientInitials = patientDisplayName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase() || 'PT';
  const patientUhid = currentUser ? currentUser.uhid : 'SDA-2026-8842';
  const patientPhone = currentUser ? currentUser.phone : '+91 98765 43210';

  const visitTimeline = [
    {
      date: 'Sept 15, 2026',
      type: 'Diagnostic & Restorative',
      doctor: 'Dr. Swati R Emaliya, BDS',
      toothInvolved: 'Tooth #30 (Mandibular 1st Molar)',
      summary: 'Completed single-visit rotary endodontic root canal obturation. Prepped for CAD/CAM ceramic crown margin impression.',
      findings: 'Pulp necrosis successfully cleared with sterile irrigation. Patient tolerated procedure painlessly under local infiltration.',
      status: 'Completed'
    },
    {
      date: 'Jan 22, 2026',
      type: 'Preventive Hygiene & Fluoride',
      doctor: 'Dr. Swati R Emaliya, BDS',
      toothInvolved: 'Full Mouth Arch',
      summary: 'Ultrasonic supragingival & subgingival scaling, airflow bicarbonate polishing, topical sodium fluoride varnish (5%).',
      findings: 'Gingival index improved significantly. Minor localized bleeding at lower lingual anterior.',
      status: 'Completed'
    },
    {
      date: 'Aug 14, 2025',
      type: 'Aesthetic Restoration',
      doctor: 'Dr. Swati R Emaliya, BDS',
      toothInvolved: 'Tooth #14 (Maxillary 1st Molar)',
      summary: 'Nano-hybrid composite resin filling placed on occluso-mesial fissure using rubber dam isolation.',
      findings: 'Restoration sound, occlusion verified with 40µm articulating foil.',
      status: 'Completed'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Patient Health Overview Hero */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-5 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#00685F] to-[#0D9488] text-white flex items-center justify-center font-bold text-xl shadow-xs">
              {patientInitials}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-bold text-slate-900">{patientDisplayName}</h3>
                <span className="text-xs bg-emerald-50 text-emerald-800 font-semibold px-2.5 py-0.5 rounded-full border border-emerald-200 inline-flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" /> Verified by Admin Portal
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Record ID: <strong className="font-mono text-slate-700">#{patientUhid}</strong> • Registered Mobile: <strong className="font-mono text-teal-800">{patientPhone}</strong>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto">
            <div className="bg-slate-50 rounded-xl px-3.5 py-2 border border-slate-200 text-center flex-1 md:flex-initial">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Oral Health Score</span>
              <span className="text-lg font-bold text-emerald-600">94 / 100</span>
            </div>
            <div className="bg-slate-50 rounded-xl px-3.5 py-2 border border-slate-200 text-center flex-1 md:flex-initial">
              <span className="text-[10px] uppercase font-bold text-slate-400 block">Gum Health</span>
              <span className="text-lg font-bold text-teal-800">Grade 1 (Healthy)</span>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 pt-4 overflow-x-auto scrollbar-none">
          {[
            { id: 'remarks', label: 'Doctor Remarks & Notes', icon: MessageSquarePlus, badge: clinicalVault.remarks.length },
            { id: 'radiographs', label: 'Digital X-Rays', icon: Eye, badge: clinicalVault.xrays.length },
            { id: 'prescriptions', label: 'Dental Prescriptions (Rx)', icon: Pill, badge: clinicalVault.prescriptions.length },
            { id: 'timeline', label: 'Clinical Visit Notes', icon: Calendar, badge: visitTimeline.length },
          ].map(tab => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  active
                    ? 'bg-[#00685F] text-white shadow-2xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
                {tab.badge !== undefined && tab.badge > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    active ? 'bg-white/20 text-white' : 'bg-slate-200 text-slate-700'
                  }`}>
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: DOCTOR REMARKS & CLINICAL NOTES */}
      {activeTab === 'remarks' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-4">
            <div>
              <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <MessageSquarePlus className="w-4 h-4 text-teal-600" />
                <span>Doctor Remarks & Clinical Observations</span>
              </h4>
              <p className="text-xs text-slate-500 mt-0.5">
                Direct recommendations entered by Dr. Swati for registered mobile: <strong className="text-teal-900">{patientPhone}</strong>
              </p>
            </div>
            <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-teal-50 text-teal-800 border border-teal-200/80 self-start sm:self-auto">
              Dr. Swati R Emaliya, BDS
            </span>
          </div>

          {clinicalVault.remarks.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/60 rounded-2xl border border-dashed border-slate-200 p-6 space-y-2">
              <MessageSquarePlus className="w-8 h-8 text-teal-600/60 mx-auto" />
              <h5 className="text-sm font-bold text-slate-800">No Remarks Added Yet</h5>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Dr. Swati R Emaliya will post your customized treatment plan advice, hygiene guidelines, and post-op remarks here following your clinic appointment.
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {clinicalVault.remarks.map((rem) => (
                <div 
                  key={rem.id} 
                  className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-teal-50/40 via-white to-slate-50/40 border border-teal-200/70 shadow-2xs space-y-2.5 transition hover:border-teal-300"
                >
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-teal-100/80 text-teal-900 border border-teal-300">
                      {rem.category}
                    </span>
                    <span className="text-xs text-slate-400 font-medium">
                      Date: <strong className="text-slate-600">{rem.date}</strong>
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                    {rem.content}
                  </p>

                  <div className="pt-2 border-t border-teal-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span className="flex items-center gap-1 font-semibold text-teal-900">
                      <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                      <span>{rem.doctor}</span>
                    </span>
                    <span className="text-slate-400">Authenticated Clinical Note</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: DIGITAL RADIOGRAPHS (X-RAYS) */}
      {activeTab === 'radiographs' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 pb-4">
            <div>
              <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
                <Eye className="w-4 h-4 text-cyan-600" />
                <span>Direct Digital Radiographs & Sensor Imaging</span>
              </h4>
              <p className="text-xs text-slate-500 mt-0.5">
                Low-radiation digital sensor captures for registered mobile: <strong className="text-cyan-900">{patientPhone}</strong>
              </p>
            </div>
            <button
              onClick={() => setXrayInverted(!xrayInverted)}
              className="text-xs font-semibold px-3 py-1.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 transition cursor-pointer self-start sm:self-auto"
            >
              {xrayInverted ? 'Standard Radiograph' : 'Invert Contrast'}
            </button>
          </div>

          {clinicalVault.xrays.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/60 rounded-2xl border border-dashed border-slate-200 p-6 space-y-2">
              <Eye className="w-8 h-8 text-cyan-600/60 mx-auto" />
              <h5 className="text-sm font-bold text-slate-800">No Digital Radiographs on File</h5>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                Any intraoral periapical (IOPA) scans, panoramic OPGs, or bitewings uploaded by Dr. Swati in the clinic portal will appear here with high-resolution inspection tools.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {clinicalVault.xrays.map((xray) => (
                <div 
                  key={xray.id} 
                  className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-900 text-slate-300 p-4 space-y-3 shadow-xs hover:border-cyan-500/50 transition"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-mono text-cyan-400 font-bold truncate max-w-[200px]">
                      {xray.title}
                    </span>
                    <span className="text-slate-400 text-[11px]">
                      {xray.date} {xray.dosageMsv ? `• ${xray.dosageMsv}` : ''}
                    </span>
                  </div>

                  {/* Radiograph Image or Canvas */}
                  <div 
                    className="h-52 rounded-xl bg-slate-950 flex items-center justify-center relative overflow-hidden group cursor-pointer border border-white/10"
                    onClick={() => setZoomedXray(xray)}
                  >
                    {xray.imageDataUrl ? (
                      <img
                        src={xray.imageDataUrl}
                        alt={xray.title}
                        style={{ filter: xrayInverted ? 'invert(1) contrast(1.2)' : 'none' }}
                        className="w-full h-full object-contain transition-all"
                      />
                    ) : (
                      <svg viewBox="0 0 200 120" className="w-full h-full opacity-80" style={{ filter: xrayInverted ? 'invert(1)' : 'none' }}>
                        <rect width="200" height="120" fill="#020617" />
                        <path d="M 30 20 C 35 15, 60 15, 65 20 C 70 35, 68 80, 60 105 C 50 110, 45 110, 35 105 C 27 80, 25 35, 30 20 Z" fill="#cbd5e1" stroke="#ffffff" strokeWidth="1.5" />
                        <path d="M 45 35 C 47 45, 47 80, 48 100" stroke="#020617" strokeWidth="3" strokeLinecap="round" />
                        <path d="M 80 20 C 85 15, 115 15, 120 20 C 125 35, 122 80, 115 105 C 105 110, 95 110, 85 105 C 77 80, 75 35, 80 20 Z" fill="#cbd5e1" stroke="#ffffff" strokeWidth="1.5" />
                        <path d="M 98 32 C 98 45, 96 85, 94 102" stroke="#ffffff" strokeWidth="4" strokeLinecap="round" />
                        <path d="M 135 25 C 140 20, 165 20, 170 25 C 175 40, 170 75, 160 100 C 150 105, 145 105, 138 100 C 130 75, 130 40, 135 25 Z" fill="#cbd5e1" stroke="#ffffff" strokeWidth="1.5" />
                      </svg>
                    )}

                    <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-2 text-xs font-semibold text-white">
                      <Maximize2 className="w-4 h-4" />
                      <span>Click to Zoom Scan</span>
                    </div>

                    <div className="absolute bottom-2 left-2 text-[10px] font-mono text-cyan-300 bg-black/70 px-2 py-0.5 rounded">
                      {xray.anatomicalArea}
                    </div>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    <strong className="text-white">Doctor Interpretation:</strong> {xray.findings}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 3: CLINICAL DENTAL PRESCRIPTIONS */}
      {activeTab === 'prescriptions' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-5">
          {/* Rx Letterhead */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-serif text-2xl font-bold text-teal-800">℞</span>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 tracking-tight">
                    {DOCTOR_INFO.clinicName}
                  </h4>
                  <p className="text-xs text-slate-600">
                    Prescribing Doctor: <strong>Dr. Swati R Emaliya, BDS</strong> (Reg. No: DCI-84920/DL)
                  </p>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 mt-1 font-mono">
                Patient: <strong className="text-slate-800">{patientDisplayName}</strong> • Phone: <strong className="text-slate-800">{patientPhone}</strong> • UHID: <strong>{patientUhid}</strong>
              </p>
            </div>

            <button
              type="button"
              onClick={() => window.print()}
              className="px-3.5 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-700 inline-flex items-center gap-1.5 transition shadow-2xs self-start sm:self-auto cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5 text-teal-600" />
              <span>Print Official Rx</span>
            </button>
          </div>

          {clinicalVault.prescriptions.length === 0 ? (
            <div className="text-center py-10 bg-slate-50/60 rounded-2xl border border-dashed border-slate-200 p-6 space-y-2">
              <Pill className="w-8 h-8 text-emerald-600/60 mx-auto" />
              <h5 className="text-sm font-bold text-slate-800">No Prescriptions On File</h5>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                No active or historical dental prescriptions have been issued yet for this registered mobile number.
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {clinicalVault.prescriptions.map((rx) => (
                <div 
                  key={rx.id} 
                  className="p-4 rounded-xl border border-slate-200 bg-slate-50/70 hover:bg-slate-50 transition space-y-2.5"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h5 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-1.5">
                        <Pill className="w-3.5 h-3.5 text-emerald-600" />
                        {rx.drug}
                      </h5>
                      <p className="text-xs text-teal-800 font-semibold mt-0.5">
                        {rx.dosage} • {rx.frequency}
                      </p>
                    </div>
                    <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full ${
                      rx.status === 'Active'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-200 text-slate-600'
                    }`}>
                      {rx.status}
                    </span>
                  </div>

                  {rx.instructions && (
                    <p className="text-xs text-slate-600 italic bg-white p-2 rounded-lg border border-slate-100">
                      "{rx.instructions}"
                    </p>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-200/80">
                    <span>Duration: <strong className="text-slate-700">{rx.duration}</strong></span>
                    <span>Date Prescribed: <strong className="text-slate-700">{rx.date}</strong></span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: CLINICAL VISIT NOTES */}
      {activeTab === 'timeline' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-5 sm:p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
              Longitudinal Clinical Visit History
            </h4>
            <span className="text-xs text-slate-500">
              Documented by Dr. Swati R Emaliya
            </span>
          </div>

          <div className="space-y-4 relative before:absolute before:left-4 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
            {visitTimeline.map((item, idx) => (
              <div key={idx} className="relative pl-10">
                <div className="absolute left-2.5 top-1.5 w-3.5 h-3.5 rounded-full bg-[#00685F] ring-4 ring-white" />
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                    <span className="text-xs font-bold text-slate-900">{item.type}</span>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Clock className="w-3.5 h-3.5 text-slate-400" />
                      <span>{item.date}</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200">
                        {item.status}
                      </span>
                    </div>
                  </div>

                  <p className="text-xs text-slate-700 leading-relaxed">
                    {item.summary}
                  </p>

                  <div className="pt-2 border-t border-slate-200/80 flex flex-col sm:flex-row sm:items-center justify-between text-[11px] text-slate-500 gap-1">
                    <span>Target: <strong className="text-teal-900 font-semibold">{item.toothInvolved}</strong></span>
                    <span>Provider: <strong className="text-slate-700">{item.doctor}</strong></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* MODAL: ZOOMED HIGH-RES X-RAY VIEWER */}
      {zoomedXray && (
        <div 
          className="fixed inset-0 z-80 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          onClick={() => setZoomedXray(null)}
        >
          <div 
            className="bg-slate-950 border border-white/20 rounded-2xl max-w-3xl w-full p-4 space-y-4 shadow-2xl text-white"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div>
                <h4 className="text-sm font-bold text-cyan-400">{zoomedXray.title}</h4>
                <p className="text-xs text-slate-400">
                  Target: {zoomedXray.anatomicalArea} • {zoomedXray.date} {zoomedXray.dosageMsv ? `(${zoomedXray.dosageMsv})` : ''}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setXrayInverted(!xrayInverted)}
                  className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-white/10 hover:bg-white/20 text-slate-200 cursor-pointer"
                >
                  {xrayInverted ? 'Standard' : 'Invert'}
                </button>
                <button
                  type="button"
                  onClick={() => setZoomedXray(null)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="max-h-[65vh] flex items-center justify-center overflow-auto bg-black rounded-xl p-2">
              {zoomedXray.imageDataUrl ? (
                <img
                  src={zoomedXray.imageDataUrl}
                  alt={zoomedXray.title}
                  style={{ filter: xrayInverted ? 'invert(1) contrast(1.2)' : 'none' }}
                  className="max-h-[60vh] max-w-full object-contain"
                />
              ) : (
                <div className="p-12 text-center text-slate-400">
                  <ImageIcon className="w-12 h-12 text-teal-400 mx-auto opacity-70 mb-2" />
                  <span>Standard Digital Sensor Radiograph</span>
                </div>
              )}
            </div>

            <div className="text-xs text-slate-300 bg-white/5 p-3 rounded-xl border border-white/5">
              <strong className="text-cyan-300">Doctor Findings:</strong> {zoomedXray.findings}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
