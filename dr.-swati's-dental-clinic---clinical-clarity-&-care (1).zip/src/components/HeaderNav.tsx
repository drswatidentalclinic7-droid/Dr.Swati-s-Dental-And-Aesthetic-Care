import React from 'react';
import { SdaLogo } from './SdaLogo';
import { DOCTOR_INFO } from '../data/dentalData';
import { 
  FileCheck, 
  Calendar, 
  Activity, 
  Sparkles, 
  HeartPulse, 
  Phone, 
  MessageCircle,
  Menu,
  X,
  User,
  ShieldCheck,
  Bot
} from 'lucide-react';
import { CustomerUser } from './CustomerLoginModal';

export type NavigationTab = 
  | 'intake'
  | 'odontogram'
  | 'booking'
  | 'records'
  | 'smile'
  | 'postop';

interface HeaderNavProps {
  currentTab: NavigationTab;
  onSelectTab: (tab: NavigationTab) => void;
  currentUser?: CustomerUser | null;
  onOpenLogin?: () => void;
  onOpenClinicLogin?: () => void;
  isClinicAdminAuthenticated?: boolean;
  onOpenChatbot?: () => void;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentTab,
  onSelectTab,
  currentUser,
  onOpenLogin,
  onOpenClinicLogin,
  isClinicAdminAuthenticated = false,
  onOpenChatbot
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  // Check if patient profile is verified by admin portal to see reports and digital X-rays
  const isCustomerVerified = Boolean(currentUser && currentUser.isVerified !== false);
  const canAccessReportsAndXrays = isClinicAdminAuthenticated || isCustomerVerified;

  const allTabs: { id: NavigationTab; label: string; shortLabel: string; icon: React.FC<{ className?: string }> }[] = [
    { id: 'intake', label: 'Patient Intake', shortLabel: 'Intake', icon: FileCheck },
    { id: 'booking', label: 'Book Visit', shortLabel: 'Book', icon: Calendar },
    { id: 'records', label: 'Reports & Digital X-rays', shortLabel: 'X-Rays & Reports', icon: ShieldCheck },
    { id: 'smile', label: 'Smile Studio', shortLabel: 'Smile', icon: Sparkles },
    { id: 'postop', label: 'Recovery & Post-Op', shortLabel: 'Post-Op', icon: HeartPulse },
  ];

  // Reports & Digital X-Rays button is visible in patient login when customer profile is verified by admin portal
  const tabs = allTabs.filter(tab => {
    if (tab.id === 'records') {
      return canAccessReportsAndXrays;
    }
    return true;
  });

  return (
    <>
      {/* Top Clinical Header */}
      <header className="sticky top-0 z-40 bg-[#080808] backdrop-blur-md border-none">
        <div 
          style={{ backgroundColor: '#080808', borderStyle: 'none' }}
          className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
        >
          <div className="flex items-center justify-between h-16 sm:h-20">
            {/* Left: SDA Logo & Doctor Brand */}
            <div 
              onClick={() => onSelectTab('intake')}
              className="cursor-pointer select-none"
            >
              <SdaLogo size="md" showSubtitle={true} />
            </div>

            {/* Middle: Desktop Navigation Links */}
            <nav className="hidden lg:flex items-center gap-1">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                const isActive = currentTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => onSelectTab(tab.id)}
                    className={`inline-flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition ${
                      isActive
                        ? 'bg-[#00685F] text-white shadow-2xs'
                        : 'text-slate-300 hover:text-white hover:bg-white/10'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>

            {/* Right: Quick Doctor Helpline & Mobile Menu Toggle */}
            <div className="flex items-center gap-2.5">
              <a
                href={`tel:${DOCTOR_INFO.phone}`}
                style={{ backgroundColor: '#090909' }}
                className="hidden sm:inline-flex items-center gap-2 px-3 py-1.5 rounded-xl border border-white/10 text-xs font-semibold transition hover:opacity-90"
              >
                <Phone className="w-3.5 h-3.5 text-teal-400" />
                <span style={{ color: '#e9edf3' }}>{DOCTOR_INFO.phone}</span>
              </a>

              <a
                href={`https://wa.me/${DOCTOR_INFO.whatsapp.replace(/\D/g, '')}?text=Hello%20Dr.%20Swati%2C%20I%20have%20an%20inquiry.`}
                target="_blank"
                rel="noreferrer"
                style={{ backgroundColor: '#20e688' }}
                className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-[#20e688] text-xs font-semibold transition hover:opacity-95"
              >
                <MessageCircle className="w-3.5 h-3.5 text-[#070808]" />
                <span style={{ color: '#070808' }}>WhatsApp</span>
              </a>

              {/* AI Dental Assistant Button */}
              {onOpenChatbot && (
                <button
                  type="button"
                  onClick={onOpenChatbot}
                  className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border border-teal-500/40 bg-teal-950/60 hover:bg-teal-900/80 text-teal-200 text-xs font-semibold transition cursor-pointer shadow-2xs"
                  title="Ask Dr. Swati's AI Dental Assistant"
                >
                  <Bot className="w-3.5 h-3.5 text-teal-400" />
                  <span className="hidden md:inline">AI Dental Assistant</span>
                  <span className="md:hidden">AI</span>
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                </button>
              )}

              {/* Patient / Customer Login Button */}
              {onOpenLogin && (
                <button
                  type="button"
                  onClick={onOpenLogin}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition border ${
                    currentUser
                      ? 'bg-teal-900/60 text-teal-200 border-teal-500/40 hover:bg-teal-800/80'
                      : 'bg-white/10 text-white border-white/20 hover:bg-white/20'
                  }`}
                  title={currentUser ? `Logged in as ${currentUser.name}` : "Patient / Customer Login"}
                >
                  <User className="w-3.5 h-3.5 text-teal-300" />
                  <span className="max-w-[100px] truncate">
                    {currentUser ? currentUser.name.split(' ')[0] : 'Patient Login'}
                  </span>
                  {currentUser && (
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                  )}
                </button>
              )}

              {/* Clinic & Doctor Admin Login Button */}
              {onOpenClinicLogin && (
                <button
                  type="button"
                  onClick={onOpenClinicLogin}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                    isClinicAdminAuthenticated
                      ? 'bg-amber-950/80 text-amber-200 border-amber-500/40 hover:bg-amber-900/90 shadow-xs'
                      : 'bg-[#00685F] text-white border-teal-400/30 hover:bg-[#00554e] shadow-xs'
                  }`}
                  title={isClinicAdminAuthenticated ? "Open Clinic Command Center" : "Doctor & Clinic Staff Access"}
                >
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">
                    {isClinicAdminAuthenticated ? 'Clinic Dashboard' : 'Clinic Login'}
                  </span>
                  <span className="sm:hidden">
                    {isClinicAdminAuthenticated ? 'Dashboard' : 'Clinic'}
                  </span>
                </button>
              )}

              {/* Mobile Menu Button */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="lg:hidden p-2 rounded-xl text-slate-300 hover:bg-white/10 border border-white/10"
                aria-label="Toggle navigation"
              >
                {mobileMenuOpen ? (
                  <X style={{ color: '#e2e8f1' }} className="w-5 h-5" />
                ) : (
                  <Menu style={{ color: '#e2e8f1' }} className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Dropdown Menu (Top) */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#080808] border-b border-white/10 p-4 space-y-2 shadow-lg">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = currentTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    onSelectTab(tab.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-bold transition ${
                    isActive
                      ? 'bg-[#00685F] text-white shadow-2xs'
                      : 'text-slate-200 hover:bg-white/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{tab.label}</span>
                </button>
              );
            })}

            {/* Mobile AI Assistant Button */}
            {onOpenChatbot && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenChatbot();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-gradient-to-r from-teal-950/80 to-teal-900/50 border border-teal-500/40 text-teal-200 text-xs font-bold"
              >
                <div className="flex items-center gap-2">
                  <Bot className="w-4 h-4 text-teal-400" />
                  <span>Ask Dr. Swati's Dental AI</span>
                </div>
                <span className="text-[10px] bg-teal-700 text-white px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-amber-300" /> AI Online
                </span>
              </button>
            )}

            {/* Mobile Patient Portal Button */}
            {onOpenLogin && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-teal-950/60 border border-teal-500/30 text-teal-200 text-xs font-bold"
              >
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-teal-400" />
                  <span>{currentUser ? `Patient Account (${currentUser.name})` : 'Customer / Patient Login'}</span>
                </div>
                <span className="text-[10px] bg-teal-800 text-white px-2 py-0.5 rounded-full">
                  {currentUser ? 'Profile' : 'Sign In'}
                </span>
              </button>
            )}

            {/* Mobile Clinic & Doctor Portal Button */}
            {onOpenClinicLogin && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenClinicLogin();
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-amber-950/60 border border-amber-500/30 text-amber-200 text-xs font-bold"
              >
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  <span>Clinic & Admin Portal (Dr. Swati)</span>
                </div>
                <span className="text-[10px] bg-amber-800 text-white px-2 py-0.5 rounded-full font-bold">
                  {isClinicAdminAuthenticated ? 'Active' : 'Doctor Login'}
                </span>
              </button>
            )}

            <div className="pt-3 border-t border-white/10 flex items-center justify-between gap-2">
              <a
                href={`tel:${DOCTOR_INFO.phone}`}
                style={{ backgroundColor: '#090909' }}
                className="flex-1 py-2 text-center rounded-xl text-xs font-semibold border border-white/10"
              >
                <span style={{ color: '#e9edf3' }}>Call Clinic</span>
              </a>
              <a
                href={`https://wa.me/${DOCTOR_INFO.whatsapp.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                style={{ backgroundColor: '#20e688' }}
                className="flex-1 py-2 text-center rounded-xl text-xs font-semibold text-[#070808] border border-[#20e688]"
              >
                WhatsApp
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Ergonomic Mobile Bottom Nav Bar (Thumb reach zone) */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-[#0c0d10]/95 backdrop-blur-md border-t border-white/10 px-1 py-1.5 shadow-[0_-4px_16px_rgba(0,0,0,0.4)] pb-safe">
        <div className={`grid ${tabs.length === 5 ? 'grid-cols-5' : 'grid-cols-4'} gap-1 text-center`}>
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onSelectTab(tab.id)}
                className={`flex flex-col items-center justify-center py-1 rounded-xl transition ${
                  isActive
                    ? 'text-teal-300 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className={`p-1 rounded-lg ${isActive ? 'bg-teal-900/60 border border-teal-500/30' : 'bg-transparent'}`}>
                  <Icon className="w-4 h-4" />
                </div>
                <span className="text-[9px] tracking-tight mt-0.5 leading-none">
                  {tab.shortLabel}
                </span>
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
};
