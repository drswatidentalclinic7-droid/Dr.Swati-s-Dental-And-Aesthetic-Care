import React, { useState } from 'react';
import { ToothData, ToothCondition, ToothSurface } from '../types/dental';
import { 
  Check, 
  AlertCircle, 
  HelpCircle, 
  Plus, 
  RotateCcw, 
  Info,
  DollarSign,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';

interface OdontogramProps {
  teeth: ToothData[];
  onUpdateTooth: (tooth: ToothData) => void;
  onResetChart: () => void;
}

export const Odontogram: React.FC<OdontogramProps> = ({
  teeth,
  onUpdateTooth,
  onResetChart
}) => {
  const [notationSystem, setNotationSystem] = useState<'universal' | 'fdi'>('universal');
  const [selectedToothNum, setSelectedToothNum] = useState<number>(3); // Default inspect tooth #3 (Upper right 1st molar)
  const [filterCondition, setFilterCondition] = useState<string>('all');
  const [planExported, setPlanExported] = useState<boolean>(false);

  const selectedTooth = teeth.find(t => t.universalNumber === selectedToothNum) || teeth[0];

  // Upper Arch (Maxillary): teeth 1 to 16
  const upperTeeth = teeth.filter(t => t.arch === 'maxillary').sort((a, b) => a.universalNumber - b.universalNumber);
  
  // Lower Arch (Mandibular): arranged naturally from 32 down to 17 or 17 to 32
  // Anatomically left-to-right matching patient's mouth:
  // Patient's Right (Viewer's Left): 32 to 25. Patient's Left (Viewer's Right): 24 to 17.
  const lowerRightTeeth = teeth.filter(t => t.quadrant === 'LR').sort((a, b) => b.universalNumber - a.universalNumber); // 32 down to 25
  const lowerLeftTeeth = teeth.filter(t => t.quadrant === 'LL').sort((a, b) => a.universalNumber - b.universalNumber); // 17 to 24 (or 24 to 17)
  const lowerTeethOrdered = [...lowerRightTeeth, ...teeth.filter(t => t.quadrant === 'LL').sort((a, b) => b.universalNumber - a.universalNumber).reverse()];

  // Condition styling dictionary
  const conditionConfig: Record<ToothCondition, { label: string; bg: string; text: string; border: string; indicator: string }> = {
    healthy: { label: 'Healthy & Sound', bg: 'bg-emerald-50', text: 'text-emerald-800', border: 'border-emerald-200', indicator: 'bg-emerald-500' },
    caries: { label: 'Active Caries / Decay', bg: 'bg-rose-50', text: 'text-rose-800', border: 'border-rose-300', indicator: 'bg-rose-500' },
    filled: { label: 'Composite Restored', bg: 'bg-cyan-50', text: 'text-cyan-800', border: 'border-cyan-300', indicator: 'bg-cyan-500' },
    crown: { label: 'Prosthetic Crown', bg: 'bg-amber-50', text: 'text-amber-800', border: 'border-amber-300', indicator: 'bg-amber-500' },
    'root-canal': { label: 'Root Canal Treated', bg: 'bg-purple-50', text: 'text-purple-800', border: 'border-purple-300', indicator: 'bg-purple-500' },
    implant: { label: 'Osseointegrated Implant', bg: 'bg-indigo-50', text: 'text-indigo-800', border: 'border-indigo-300', indicator: 'bg-indigo-500' },
    missing: { label: 'Missing / Extracted', bg: 'bg-slate-100', text: 'text-slate-600', border: 'border-slate-300 border-dashed', indicator: 'bg-slate-400' },
    veneer: { label: 'Ceramic Veneer', bg: 'bg-teal-50', text: 'text-teal-800', border: 'border-teal-300', indicator: 'bg-teal-500' },
    fracture: { label: 'Enamel Fracture', bg: 'bg-orange-50', text: 'text-orange-800', border: 'border-orange-300', indicator: 'bg-orange-500' }
  };

  // Surface toggler
  const toggleSurface = (surface: ToothSurface) => {
    if (!selectedTooth) return;
    const exists = selectedTooth.affectedSurfaces.includes(surface);
    const newSurfaces = exists
      ? selectedTooth.affectedSurfaces.filter(s => s !== surface)
      : [...selectedTooth.affectedSurfaces, surface];

    onUpdateTooth({
      ...selectedTooth,
      affectedSurfaces: newSurfaces
    });
  };

  // Update tooth condition
  const handleSetCondition = (cond: ToothCondition) => {
    if (!selectedTooth) return;
    let recTreatment = selectedTooth.recommendedTreatment;
    let estCost = selectedTooth.estimatedCost;

    if (cond === 'caries') {
      recTreatment = 'Tooth-Colored Composite Restoration';
      estCost = 65;
    } else if (cond === 'root-canal') {
      recTreatment = 'Rotary Endodontic Therapy + Crown';
      estCost = 210;
    } else if (cond === 'crown') {
      recTreatment = 'Zirconia Crown Placement';
      estCost = 180;
    } else if (cond === 'implant') {
      recTreatment = 'Titanium Implant + Abutment';
      estCost = 450;
    } else if (cond === 'healthy') {
      recTreatment = 'Preventive Cleaning & Fluoride';
      estCost = 0;
    }

    onUpdateTooth({
      ...selectedTooth,
      condition: cond,
      recommendedTreatment: recTreatment,
      estimatedCost: estCost
    });
  };

  // Treatment statistics
  const flaggedCount = teeth.filter(t => t.condition !== 'healthy' && t.condition !== 'missing').length;
  const totalEstimatedCost = teeth.reduce((sum, t) => sum + (t.estimatedCost || 0), 0);

  // SVG representation for tooth icon
  const renderToothVisual = (t: ToothData, isSelected: boolean) => {
    const isMolar = t.name.toLowerCase().includes('molar');
    const isPremolar = t.name.toLowerCase().includes('premolar');
    const isCanine = t.name.toLowerCase().includes('canine');
    const isMissing = t.condition === 'missing';
    const isDecay = t.condition === 'caries';
    const isFilled = t.condition === 'filled';
    const isCrown = t.condition === 'crown';
    const isRct = t.condition === 'root-canal';

    return (
      <div
        onClick={() => setSelectedToothNum(t.universalNumber)}
        className={`relative flex flex-col items-center justify-between p-1.5 rounded-xl cursor-pointer transition-all duration-200 select-none ${
          isSelected
            ? 'bg-[#00685F] text-white ring-3 ring-[#06B6D4]/40 shadow-md scale-105 z-10'
            : isMissing
            ? 'bg-slate-100/80 text-slate-400 border border-dashed border-slate-300 opacity-60'
            : isDecay
            ? 'bg-rose-50 text-rose-900 border-2 border-rose-400 hover:border-rose-500'
            : isRct
            ? 'bg-purple-50 text-purple-900 border-2 border-purple-400'
            : isCrown
            ? 'bg-amber-50 text-amber-900 border-2 border-amber-400'
            : isFilled
            ? 'bg-cyan-50 text-cyan-900 border-2 border-cyan-400'
            : 'bg-white text-slate-800 border border-slate-200 hover:border-[#0D9488] hover:shadow-xs'
        }`}
        style={{ minWidth: isMolar ? '38px' : isPremolar ? '34px' : '30px', height: '68px' }}
      >
        {/* Tooth Number */}
        <span className={`text-[11px] font-bold ${isSelected ? 'text-white' : 'text-slate-700'}`}>
          {notationSystem === 'universal' ? t.universalNumber : t.fdiNumber}
        </span>

        {/* Anatomical Tooth SVG Outline */}
        <svg
          viewBox="0 0 28 32"
          className="w-5 h-6 shrink-0 my-0.5"
          fill="none"
          xmlns="http://www.w3.org/2000/svg"
        >
          {isMissing ? (
            <path d="M6 6L22 26M22 6L6 26" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" />
          ) : isMolar ? (
            /* Molar shape with 2 roots */
            <g>
              <path
                d="M4 10 C4 6, 8 4, 14 4 C20 4, 24 6, 24 10 C24 16, 22 20, 20 28 C18 29, 16 25, 14 20 C12 25, 10 29, 8 28 C6 20, 4 16, 4 10 Z"
                fill={isSelected ? '#004e47' : isCrown ? '#fef3c7' : isFilled ? '#cffafe' : isDecay ? '#ffe4e6' : '#ffffff'}
                stroke={isSelected ? '#ffffff' : 'currentColor'}
                strokeWidth="1.8"
              />
              {/* Occlusal fissure cross */}
              <circle cx="14" cy="9" r="2.5" fill={isDecay ? '#e11d48' : isFilled ? '#0284c7' : isRct ? '#9333ea' : 'currentColor'} opacity={isSelected ? 0.9 : 0.4} />
            </g>
          ) : isPremolar ? (
            /* Premolar shape */
            <g>
              <path
                d="M6 10 C6 6, 9 5, 14 5 C19 5, 22 6, 22 10 C22 16, 19 23, 16 28 C14 29, 12 28, 12 24 C10 26, 9 27, 8 24 C7 18, 6 15, 6 10 Z"
                fill={isSelected ? '#004e47' : isCrown ? '#fef3c7' : isFilled ? '#cffafe' : isDecay ? '#ffe4e6' : '#ffffff'}
                stroke={isSelected ? '#ffffff' : 'currentColor'}
                strokeWidth="1.8"
              />
              <circle cx="14" cy="9" r="2" fill={isDecay ? '#e11d48' : isFilled ? '#0284c7' : 'currentColor'} opacity={isSelected ? 0.9 : 0.4} />
            </g>
          ) : isCanine ? (
            /* Pointed Canine cusp */
            <g>
              <path
                d="M7 12 C7 7, 10 4, 14 3 C18 4, 21 7, 21 12 C21 18, 18 24, 15 29 C14 30, 13 30, 12 27 C10 21, 7 18, 7 12 Z"
                fill={isSelected ? '#004e47' : isCrown ? '#fef3c7' : isFilled ? '#cffafe' : isDecay ? '#ffe4e6' : '#ffffff'}
                stroke={isSelected ? '#ffffff' : 'currentColor'}
                strokeWidth="1.8"
              />
            </g>
          ) : (
            /* Incisor chisel blade */
            <g>
              <path
                d="M7 8 C7 5, 11 4, 14 4 C17 4, 21 5, 21 8 C21 14, 18 22, 15 28 C14 29, 13 29, 12 25 C9 20, 7 15, 7 8 Z"
                fill={isSelected ? '#004e47' : isCrown ? '#fef3c7' : isFilled ? '#cffafe' : isDecay ? '#ffe4e6' : '#ffffff'}
                stroke={isSelected ? '#ffffff' : 'currentColor'}
                strokeWidth="1.8"
              />
            </g>
          )}
        </svg>

        {/* Condition Indicator Pill */}
        <div className="flex items-center gap-0.5">
          <span className={`w-1.5 h-1.5 rounded-full ${isSelected ? 'bg-white' : conditionConfig[t.condition].indicator}`} />
          {t.affectedSurfaces.length > 0 && !isSelected && (
            <span className="text-[8px] font-mono uppercase font-bold text-slate-500">
              {t.affectedSurfaces.map(s => s[0]).join('')}
            </span>
          )}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Notation Controls */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h3 className="text-lg font-bold text-slate-900 tracking-tight flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-teal-600" />
              Interactive Odontogram & Dental Arch
            </h3>
            <span className="text-xs bg-teal-50 text-teal-800 font-semibold px-2 py-0.5 rounded-full border border-teal-200">
              Adult Dentition (32 Teeth)
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Tap any tooth to inspect surfaces (MODBL), diagnose pathology, or plan restorations with Dr. Swati R Emaliya.
          </p>
        </div>

        {/* Right Action Controls */}
        <div className="flex items-center flex-wrap gap-2 w-full md:w-auto">
          {/* Notation toggle */}
          <div className="inline-flex p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-semibold">
            <button
              onClick={() => setNotationSystem('universal')}
              className={`px-2.5 py-1 rounded-lg transition ${
                notationSystem === 'universal'
                  ? 'bg-white text-teal-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Universal (#1-32)
            </button>
            <button
              onClick={() => setNotationSystem('fdi')}
              className={`px-2.5 py-1 rounded-lg transition ${
                notationSystem === 'fdi'
                  ? 'bg-white text-teal-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              FDI / ISO (#11-48)
            </button>
          </div>

          <button
            onClick={onResetChart}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 text-xs font-medium hover:bg-slate-50 transition"
            title="Reset to default healthy chart"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset
          </button>
        </div>
      </div>

      {/* Main Arch Viewport Container */}
      <div className="bg-white rounded-2xl border border-slate-200 p-4 sm:p-6 shadow-sm overflow-hidden">
        {/* Quadrant orientation guide */}
        <div className="flex justify-between items-center text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-2 border-b border-slate-100 pb-2">
          <span>Patient Right (Viewer Left)</span>
          <span className="text-teal-700 font-semibold lowercase bg-teal-50 px-2 py-0.5 rounded">
            click tooth to inspect
          </span>
          <span>Patient Left (Viewer Right)</span>
        </div>

        {/* Upper Arch (Maxillary) */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2 px-1">
            <span className="inline-flex items-center gap-1 text-teal-800">
              <span className="w-2 h-2 rounded-full bg-teal-600" /> Maxillary Arch (Upper Jaw)
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Teeth #1 – #16</span>
          </div>

          {/* Horizontal scroll container on mobile with smooth touch */}
          <div className="overflow-x-auto pb-2 scrollbar-thin">
            <div className="flex items-center justify-center gap-1.5 min-w-[620px] p-2 bg-slate-50/70 rounded-2xl border border-slate-100">
              {upperTeeth.map((tooth) => (
                <React.Fragment key={tooth.universalNumber}>
                  {/* Subtle midline separator between Tooth 8 and 9 */}
                  {tooth.universalNumber === 9 && (
                    <div className="h-12 w-[2px] bg-teal-300 mx-1 rounded-full relative group">
                      <span className="absolute -top-4 left-1/2 -translate-x-1/2 text-[9px] font-bold text-teal-600 uppercase">Midline</span>
                    </div>
                  )}
                  {renderToothVisual(tooth, tooth.universalNumber === selectedToothNum)}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Lower Arch (Mandibular) */}
        <div>
          <div className="flex items-center justify-between text-xs font-semibold text-slate-700 mb-2 px-1">
            <span className="inline-flex items-center gap-1 text-teal-800">
              <span className="w-2 h-2 rounded-full bg-teal-600" /> Mandibular Arch (Lower Jaw)
            </span>
            <span className="text-[11px] text-slate-400 font-mono">Teeth #32 – #17</span>
          </div>

          <div className="overflow-x-auto pb-2 scrollbar-thin">
            <div className="flex items-center justify-center gap-1.5 min-w-[620px] p-2 bg-slate-50/70 rounded-2xl border border-slate-100">
              {lowerTeethOrdered.map((tooth) => (
                <React.Fragment key={tooth.universalNumber}>
                  {/* Midline between Tooth 25 and 24 */}
                  {tooth.universalNumber === 24 && (
                    <div className="h-12 w-[2px] bg-teal-300 mx-1 rounded-full relative">
                      <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[9px] font-bold text-teal-600 uppercase">Midline</span>
                    </div>
                  )}
                  {renderToothVisual(tooth, tooth.universalNumber === selectedToothNum)}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>

        {/* Chart Color Legend */}
        <div className="mt-6 pt-4 border-t border-slate-100 flex flex-wrap items-center justify-center gap-3 text-xs">
          <span className="text-slate-400 text-[11px] font-medium mr-1">Status Legend:</span>
          {Object.entries(conditionConfig).slice(0, 7).map(([key, cfg]) => (
            <div key={key} className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${cfg.indicator}`} />
              <span className="text-slate-600 text-[11px]">{cfg.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Selected Tooth Detail Inspector Card */}
      {selectedTooth && (
        <div className="bg-white rounded-2xl border border-teal-500/30 shadow-md p-5 sm:p-6 transition-all">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#00685F] text-white flex flex-col items-center justify-center font-bold shadow-xs">
                <span className="text-[10px] uppercase tracking-wider text-teal-200">
                  {notationSystem === 'universal' ? 'Tooth' : 'FDI'}
                </span>
                <span className="text-lg leading-none">
                  {notationSystem === 'universal' ? `#${selectedTooth.universalNumber}` : `#${selectedTooth.fdiNumber}`}
                </span>
              </div>
              <div>
                <h4 className="text-base font-bold text-slate-900">
                  {selectedTooth.name}
                </h4>
                <p className="text-xs text-slate-500">
                  Quadrant: <strong className="text-slate-700">{selectedTooth.quadrant}</strong> ({selectedTooth.arch === 'maxillary' ? 'Maxilla / Upper Jaw' : 'Mandible / Lower Jaw'})
                </p>
              </div>
            </div>

            {/* Current Condition Badge */}
            <div className="flex items-center gap-2">
              <span className={`px-3 py-1 rounded-full text-xs font-bold border ${conditionConfig[selectedTooth.condition].bg} ${conditionConfig[selectedTooth.condition].text} ${conditionConfig[selectedTooth.condition].border}`}>
                {conditionConfig[selectedTooth.condition].label}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mt-5">
            {/* Column 1: Quick Condition Actions */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Update Clinical Condition
              </label>
              <div className="grid grid-cols-2 gap-1.5">
                {(['healthy', 'caries', 'filled', 'crown', 'root-canal', 'implant', 'missing'] as ToothCondition[]).map((cond) => {
                  const active = selectedTooth.condition === cond;
                  return (
                    <button
                      key={cond}
                      onClick={() => handleSetCondition(cond)}
                      className={`px-2.5 py-2 rounded-xl text-xs font-semibold text-left transition flex items-center justify-between border ${
                        active
                          ? 'bg-[#00685F] text-white border-[#00685F] shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      <span className="truncate">{conditionConfig[cond].label.split('/')[0]}</span>
                      {active && <Check className="w-3.5 h-3.5 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Column 2: Affected Anatomical Surfaces (MODBL) */}
            <div>
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-2">
                Involved Surfaces (M-O-D-B-L)
              </label>
              <p className="text-[11px] text-slate-500 mb-2.5">
                Select tooth surfaces requiring cavity restoration or margin evaluation.
              </p>

              <div className="flex flex-wrap gap-2">
                {(['mesial', 'occlusal', 'distal', 'buccal', 'lingual'] as ToothSurface[]).map((surf) => {
                  const isChecked = selectedTooth.affectedSurfaces.includes(surf);
                  return (
                    <button
                      key={surf}
                      onClick={() => toggleSurface(surf)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-semibold uppercase tracking-wider transition flex items-center gap-1.5 border ${
                        isChecked
                          ? 'bg-[#0D9488] text-white border-[#0D9488] shadow-xs'
                          : 'bg-white hover:bg-slate-50 text-slate-600 border-slate-200'
                      }`}
                    >
                      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-60" />
                      {surf}
                      {isChecked && <Check className="w-3 h-3" />}
                    </button>
                  );
                })}
              </div>

              {/* Surface diagram helper */}
              <div className="mt-3 p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-[11px] text-slate-600 flex items-center gap-2">
                <Info className="w-4 h-4 text-teal-600 shrink-0" />
                <span>M = Mesial, O = Occlusal, D = Distal, B = Buccal, L = Lingual</span>
              </div>
            </div>

            {/* Column 3: Clinical Findings & Cost Estimate */}
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 flex flex-col justify-between">
              <div>
                <label className="text-xs font-bold text-slate-700 uppercase tracking-wider block mb-1">
                  Dr. Swati's Clinical Plan
                </label>
                <p className="text-xs font-semibold text-teal-900 mt-1">
                  {selectedTooth.recommendedTreatment || 'Routine hygiene & preventive check'}
                </p>
                {selectedTooth.notes && (
                  <p className="text-xs text-slate-600 mt-1 italic">
                    "{selectedTooth.notes}"
                  </p>
                )}
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-400 block">Est. Cost</span>
                  <span className="text-lg font-bold text-slate-900">
                    ${selectedTooth.estimatedCost || 0}
                  </span>
                </div>

                <div className="text-right">
                  <span className="text-[10px] text-emerald-700 font-medium bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Covered 80% with PPO
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Treatment Summary Drawer Banner */}
      <div className="bg-gradient-to-r from-[#00685F] to-[#008378] text-white rounded-2xl p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-center sm:text-left">
          <div className="w-12 h-12 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center shrink-0">
            <ShieldCheck className="w-6 h-6 text-teal-200" />
          </div>
          <div>
            <h4 className="font-bold text-white text-base">
              Comprehensive Treatment Plan Summary
            </h4>
            <p className="text-xs text-teal-100">
              {flaggedCount === 0
                ? "All 32 teeth charted healthy! No active interventions required."
                : `${flaggedCount} teeth flagged for restorative / aesthetic treatment.`}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-right">
            <span className="text-[10px] uppercase tracking-wider text-teal-200 font-semibold block">Total Estimated Care</span>
            <span className="text-2xl font-bold text-white">${totalEstimatedCost}</span>
          </div>
          <button
            onClick={() => {
              setPlanExported(true);
              setTimeout(() => setPlanExported(false), 3500);
            }}
            className="px-4 py-2.5 rounded-xl bg-white text-[#00685F] text-xs font-bold hover:bg-teal-50 active:scale-95 transition shadow-sm"
          >
            {planExported ? '✓ Plan Exported' : 'Export Plan'}
          </button>
        </div>
      </div>
    </div>
  );
};
