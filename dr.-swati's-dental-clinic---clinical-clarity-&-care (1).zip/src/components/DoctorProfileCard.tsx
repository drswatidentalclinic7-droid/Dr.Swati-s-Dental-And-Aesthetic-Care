import React, { useState } from 'react';
import { DOCTOR_INFO } from '../data/dentalData';
import doctorPortraitImg from '../assets/images/dr_swati_emaliya_portrait_1790706192276.jpg';
import { 
  Award, 
  Clock, 
  MapPin, 
  Phone, 
  Mail, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles,
  Calendar,
  MessageCircle,
  X,
  Maximize2
} from 'lucide-react';

interface DoctorProfileCardProps {
  onBookClick?: () => void;
  variant?: 'banner' | 'compact' | 'full';
}

export const DoctorProfileCard: React.FC<DoctorProfileCardProps> = ({
  onBookClick,
  variant = 'full'
}) => {
  const [showFullPhoto, setShowFullPhoto] = useState(false);

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
      {/* Top Banner Accent */}
      <div 
        style={{
          background: 'linear-gradient(90deg, #99762e 0%, #d1c458 35%, #fef08a 50%, #d1c458 65%, #b48b35 100%)'
        }}
        className="h-2.5 w-full shadow-xs" 
      />

      <div style={{ backgroundColor: '#e9f1ef' }} className="p-5 sm:p-6">
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-5">
          {/* Dr. Swati R Emaliya Original Profile Photo */}
          <div className="relative shrink-0 flex flex-col items-center group">
            <button
              type="button"
              onClick={() => setShowFullPhoto(true)}
              className="w-28 h-28 sm:w-32 sm:h-32 rounded-2xl overflow-hidden ring-4 ring-[#d1c458]/40 border border-[#d1c458]/50 bg-slate-100 shadow-md relative select-none cursor-pointer focus:outline-none"
              title="Click to view full photo"
            >
              <img
                src={doctorPortraitImg}
                alt="Dr. Swati R Emaliya - Profile Photo"
                className="w-full h-full object-cover object-[center_50%]"
                loading="eager"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/WhatsApp Image 2026-09-29 at 9.53.32 PM (1).jpeg';
                }}
              />
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Maximize2 className="w-5 h-5 text-white drop-shadow" />
              </div>
            </button>
          </div>

          {/* Doctor Information */}
          <div className="flex-1 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 tracking-tight">
                {DOCTOR_INFO.name}
              </h2>
              <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-50 text-teal-800 border border-teal-200/80">
                {DOCTOR_INFO.degrees}
              </span>
            </div>

            <p className="text-sm font-medium text-teal-800 mt-0.5">
              {DOCTOR_INFO.role}
            </p>
            <p className="text-xs text-slate-500 mt-1 flex items-center justify-center sm:justify-start gap-1">
              <Award className="w-3.5 h-3.5 text-amber-500" />
              <span>{DOCTOR_INFO.experienceYears}+ Years Clinical Mastery</span>
            </p>

            <p className="text-xs sm:text-sm text-slate-600 mt-2.5 leading-relaxed line-clamp-2 sm:line-clamp-none">
              {DOCTOR_INFO.bio}
            </p>

            {/* Quick Badges */}
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-1.5 mt-3">
              <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-slate-50 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200">
                <Sparkles className="w-3 h-3 text-cyan-500" /> Pain-Free Dentistry
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-slate-50 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200">
                <CheckCircle2 className="w-3 h-3 text-emerald-500" /> Digital Smile Makeover
              </span>
              <span className="inline-flex items-center gap-1 text-[11px] font-medium bg-slate-50 text-slate-700 px-2.5 py-1 rounded-lg border border-slate-200">
                <ShieldCheck className="w-3 h-3 text-teal-500" /> Autoclave Class-B Sterile
              </span>
            </div>
          </div>
        </div>

        {/* Divider */}
        {variant === 'full' && (
          <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-xs text-slate-500 flex flex-col gap-1 w-full sm:w-auto">
              <div className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span className="truncate">{DOCTOR_INFO.address}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>{DOCTOR_INFO.hours}</span>
              </div>
            </div>

            <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
              <a
                href={`https://wa.me/${DOCTOR_INFO.whatsapp.replace(/\D/g, '')}?text=Hello%20Dr.%20Swati%2C%20I%20would%20like%20to%20consult%20for%20dental%20care.`}
                target="_blank"
                rel="noreferrer"
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-emerald-300 text-emerald-800 text-xs font-semibold hover:bg-emerald-50 active:scale-95 transition"
              >
                <MessageCircle className="w-4 h-4 text-emerald-600" />
                WhatsApp Clinic
              </a>
              <button
                onClick={onBookClick}
                className="flex-1 sm:flex-initial inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#00685F] hover:bg-[#005049] text-white text-xs font-semibold shadow-xs active:scale-95 transition"
              >
                <Calendar className="w-4 h-4" />
                Book Consultation
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Full Authentic Original Photo Modal */}
      {showFullPhoto && (
        <div 
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setShowFullPhoto(false)}
        >
          <div 
            className="relative max-w-lg w-full bg-slate-900 rounded-2xl overflow-hidden shadow-2xl border border-white/10"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="p-3 bg-slate-950 flex items-center justify-between text-white border-b border-white/10">
              <span className="text-xs font-semibold tracking-wide text-amber-300">
                Dr. Swati R Emaliya - Clinical Consultation Office
              </span>
              <button
                type="button"
                onClick={() => setShowFullPhoto(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-2 flex items-center justify-center bg-black max-h-[80vh] overflow-auto">
              <img
                src={doctorPortraitImg}
                alt="Dr. Swati R Emaliya, BDS Dental Surgeon"
                className="max-h-[75vh] w-auto object-contain rounded-lg shadow-lg select-none"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src = '/WhatsApp Image 2026-09-29 at 9.53.32 PM (1).jpeg';
                }}
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
