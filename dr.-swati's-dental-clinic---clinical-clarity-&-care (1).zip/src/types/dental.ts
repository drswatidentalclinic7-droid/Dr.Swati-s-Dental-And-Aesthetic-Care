export type ToothCondition = 
  | 'healthy'
  | 'caries'
  | 'filled'
  | 'crown'
  | 'root-canal'
  | 'implant'
  | 'missing'
  | 'veneer'
  | 'fracture';

export type ToothSurface = 'mesial' | 'distal' | 'occlusal' | 'buccal' | 'lingual';

export type ArchType = 'maxillary' | 'mandibular'; // Upper | Lower
export type QuadrantType = 'UR' | 'UL' | 'LL' | 'LR'; // Upper Right, Upper Left, Lower Left, Lower Right

export interface ToothData {
  universalNumber: number; // 1 - 32
  fdiNumber: number; // 11-18, 21-28, 31-38, 41-48
  name: string;
  quadrant: QuadrantType;
  arch: ArchType;
  condition: ToothCondition;
  affectedSurfaces: ToothSurface[];
  notes?: string;
  recommendedTreatment?: string;
  estimatedCost?: number;
}

export interface PatientIntakeData {
  fullName: string;
  dateOfBirth: string;
  gender: string;
  phone: string;
  email: string;
  address: string;
  emergencyContactName?: string;
  emergencyContactPhone?: string;
  emergencyContactRelation?: string;
  
  // Dental Insurance
  hasInsurance: boolean;
  insuranceProvider: string;
  policyNumber: string;
  groupNumber: string;

  // Medical History & Anxiety
  dentalAnxietyScore: number; // 1 (Relaxed) to 5 (Severe Fear)
  allergies: string[];
  medicalConditions: string[];
  medications: string;
  isPregnant: boolean;
  hasPreviousComplications: boolean;
  complicationsDetails: string;

  // Chief Complaint
  primaryConcern: string;
  painLevel: number; // 0 to 10
  symptoms: string[];
  symptomDuration: string;

  // Consent
  consentSigned: boolean;
  signatureDataUrl: string;
  consentDate: string;
  privacyNoticeAcknowledged: boolean;
}

export interface AppointmentSlot {
  id: string;
  serviceId: string;
  serviceName: string;
  doctorName: string;
  date: string;
  time: string;
  durationMinutes: number;
  status: 'confirmed' | 'pending' | 'completed';
  patientName: string;
  phone: string;
  email: string;
  notes?: string;
}

export interface DentalService {
  id: string;
  name: string;
  category: 'Preventive' | 'Restorative' | 'Cosmetic' | 'Surgical' | 'Endodontics';
  price: number;
  duration: string;
  description: string;
  popular?: boolean;
}
