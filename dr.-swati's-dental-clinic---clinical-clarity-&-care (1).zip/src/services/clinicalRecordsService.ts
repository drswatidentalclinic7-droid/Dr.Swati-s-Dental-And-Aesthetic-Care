/**
 * Clinical Records Service
 * Manages doctor remarks, uploaded digital radiographs (X-rays), and clinical dental prescriptions
 * keyed by registered patient mobile number.
 */

export interface PatientRemark {
  id: string;
  date: string;
  category: 'Examination' | 'Treatment Plan' | 'Post-Op Observation' | 'Hygiene Advice' | 'General';
  content: string;
  doctor: string;
}

export interface PatientXray {
  id: string;
  date: string;
  title: string;
  type: string;
  anatomicalArea: string;
  imageDataUrl?: string; // base64 or photo URL
  dosageMsv?: string;
  findings: string;
  doctor: string;
}

export interface PatientPrescription {
  id: string;
  date: string;
  drug: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
  status: 'Active' | 'Completed';
  doctor: string;
}

export interface PatientClinicalVault {
  phone: string;
  remarks: PatientRemark[];
  xrays: PatientXray[];
  prescriptions: PatientPrescription[];
}

export const normalizePhone = (phone?: string): string => {
  if (!phone) return '';
  const digits = phone.replace(/\D/g, '');
  return digits.length > 10 ? digits.slice(-10) : digits;
};

// Initial default records for Sarah Jenkins (phone: 9876543210 or 5553928841)
const DEFAULT_SARAH_VAULT: PatientClinicalVault = {
  phone: '9876543210',
  remarks: [
    {
      id: 'rem-1',
      date: 'Sept 30, 2026',
      category: 'Treatment Plan',
      content: 'Single-visit rotary root canal completed on tooth #30 with bioceramic sealer. Recommended CAD/CAM monolithic zirconia crown within 2-3 weeks to avoid coronal cusp fracture.',
      doctor: 'Dr. Swati R Emaliya, BDS'
    },
    {
      id: 'rem-2',
      date: 'Sept 15, 2026',
      category: 'Hygiene Advice',
      content: 'Excellent oral hygiene maintenance. Continue using interdental floss picks twice daily. Avoid biting hard foods or ice on the right mandibular quadrant until permanent crown placement.',
      doctor: 'Dr. Swati R Emaliya, BDS'
    }
  ],
  xrays: [
    {
      id: 'xray-1',
      date: 'Sept 30, 2026',
      title: 'Post-Endodontic Periapical Radiograph',
      type: 'Direct Digital Intraoral Sensor (RVG)',
      anatomicalArea: 'Tooth #30 (Mandibular 1st Molar)',
      dosageMsv: '0.003 mSv',
      findings: 'Complete root canal obturation to true anatomical apex (0.5mm working length). Bone density around periapical lamina dura is sound with zero apical periodontitis radiolucency.',
      doctor: 'Dr. Swati R Emaliya, BDS'
    },
    {
      id: 'xray-2',
      date: 'Jan 22, 2026',
      title: 'Full Orthopantomogram (OPG)',
      type: 'Digital Panoramic Scan',
      anatomicalArea: 'Full Dentition Arch & TMJ Condyles',
      dosageMsv: '0.015 mSv',
      findings: 'Alveolar crest height normal (>90%). Symmetrical bilateral condyles. No impacted third molars or periapical cysts detected.',
      doctor: 'Dr. Swati R Emaliya, BDS'
    }
  ],
  prescriptions: [
    {
      id: 'rx-1',
      date: 'Sept 30, 2026',
      drug: 'Amoxicillin + Potassium Clavulanate 625mg',
      dosage: '1 Tablet',
      frequency: 'Twice Daily (BID) - After Meals',
      duration: '5 Days (Post-Endodontic Protocol)',
      instructions: 'Take strictly after food with a full glass of water. Complete the entire antimicrobial course.',
      status: 'Active',
      doctor: 'Dr. Swati R Emaliya, BDS'
    },
    {
      id: 'rx-2',
      date: 'Sept 30, 2026',
      drug: 'Ketorolac Tromethamine 10mg DT',
      dosage: '1 Dispersible Tablet',
      frequency: 'SOS / As needed for acute discomfort (Max BID)',
      duration: '3 Days',
      instructions: 'Dissolve in 1 tablespoon of lukewarm water. Take only if mild post-obturation ache occurs.',
      status: 'Active',
      doctor: 'Dr. Swati R Emaliya, BDS'
    },
    {
      id: 'rx-3',
      date: 'Sept 15, 2026',
      drug: 'Chlorhexidine Gluconate 0.2% w/v Oral Rinse',
      dosage: '10 ml rinse',
      frequency: 'Twice Daily (Morning & Night)',
      duration: '14 Days',
      instructions: 'Rinse vigorously for 60 seconds after brushing. Do not eat or drink for 30 minutes following rinse.',
      status: 'Completed',
      doctor: 'Dr. Swati R Emaliya, BDS'
    }
  ]
};

/**
 * Retrieve clinical vault for a patient by phone number
 */
export const getPatientClinicalVault = (phone?: string): PatientClinicalVault => {
  const norm = normalizePhone(phone);
  if (!norm) {
    return {
      phone: '',
      remarks: [],
      xrays: [],
      prescriptions: []
    };
  }

  try {
    const key = `sda_patient_vault_${norm}`;
    const saved = localStorage.getItem(key);
    if (saved) {
      return JSON.parse(saved);
    }
  } catch (err) {
    console.error('Failed to read patient clinical vault', err);
  }

  // If Sarah Jenkins demo phone, initialize with rich clinical data
  if (norm.includes('9876543210') || norm.includes('3928841')) {
    savePatientClinicalVault(norm, DEFAULT_SARAH_VAULT);
    return DEFAULT_SARAH_VAULT;
  }

  // Default empty vault for new patient
  return {
    phone: norm,
    remarks: [],
    xrays: [],
    prescriptions: []
  };
};

/**
 * Save clinical vault for a patient by phone number and broadcast update
 */
export const savePatientClinicalVault = (phone: string, vault: PatientClinicalVault): void => {
  const norm = normalizePhone(phone);
  if (!norm) return;

  try {
    const key = `sda_patient_vault_${norm}`;
    localStorage.setItem(key, JSON.stringify({ ...vault, phone: norm }));
    // Broadcast event for live UI reactivity across components
    window.dispatchEvent(new CustomEvent('sda_patient_clinical_updated', { detail: { phone: norm } }));
  } catch (err) {
    console.error('Failed to save patient clinical vault', err);
  }
};
