import { DentalService, ToothData } from '../types/dental';

export const DOCTOR_INFO = {
  name: "Dr. Swati R Emaliya",
  degrees: "B.D.S.",
  role: "Dental Surgeon & Aesthetic Specialist",
  regNo: "DCI-84920/DL",
  experienceYears: 9,
  clinicName: "Dr. Swati's Dental And Aesthetic Care",
  tagline: "Painless Modern Dentistry & Advanced Aesthetic Smile Studio",
  email: "support@drswatisdentalansaestheticcare.org",
  phone: "+91 85275 83991",
  whatsapp: "+91 85275 83991",
  address: "5/904, GDA Market, Sector 5, Vaishali, Ghaziabad, UTTAR PRADESH, 201019",
  hours: "Mon - Sat: 5:00 PM – 8:30 PM | Sun: On Call",
  bio: "Dr. Swati R Emaliya is a senior dental surgeon with 9+ years of clinical excellence in minimally invasive restorative dentistry, digital smile design, and pain-free endodontics. Committed to empathetic, anxiety-free patient care in a pristine sterile environment.",
  specialties: [
    "Painless Single-Sitting Root Canals",
    "Digital Smile Design & Ceramic Veneers",
    "Invisible Aligners & Orthodontics",
    "Laser Gum Depigmentation & Contouring",
    "Crown & Bridge Prosthetics",
    "Bio-compatible Tooth Fillings"
  ]
};

// 32 Adult Permanent Teeth
export const INITIAL_TEETH_DATA: ToothData[] = [
  // Upper Right Quadrant (UR) - Universal 1 to 8 (FDI 18 to 11)
  { universalNumber: 1, fdiNumber: 18, name: "Upper Right 3rd Molar (Wisdom)", quadrant: "UR", arch: "maxillary", condition: "missing", affectedSurfaces: [], notes: "Surgically extracted 2024" },
  { universalNumber: 2, fdiNumber: 17, name: "Upper Right 2nd Molar", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 3, fdiNumber: 16, name: "Upper Right 1st Molar", quadrant: "UR", arch: "maxillary", condition: "caries", affectedSurfaces: ["occlusal"], notes: "Mild occlusal pit caries detected, recommended composite filling", recommendedTreatment: "Composite Resin Restoration", estimatedCost: 65 },
  { universalNumber: 4, fdiNumber: 15, name: "Upper Right 2nd Premolar", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 5, fdiNumber: 14, name: "Upper Right 1st Premolar", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 6, fdiNumber: 13, name: "Upper Right Canine", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 7, fdiNumber: 12, name: "Upper Right Lateral Incisor", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 8, fdiNumber: 11, name: "Upper Right Central Incisor", quadrant: "UR", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },

  // Upper Left Quadrant (UL) - Universal 9 to 16 (FDI 21 to 28)
  { universalNumber: 9, fdiNumber: 21, name: "Upper Left Central Incisor", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 10, fdiNumber: 22, name: "Upper Left Lateral Incisor", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 11, fdiNumber: 23, name: "Upper Left Canine", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 12, fdiNumber: 24, name: "Upper Left 1st Premolar", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 13, fdiNumber: 25, name: "Upper Left 2nd Premolar", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 14, fdiNumber: 26, name: "Upper Left 1st Molar", quadrant: "UL", arch: "maxillary", condition: "filled", affectedSurfaces: ["occlusal", "mesial"], notes: "Existing sound composite restoration done 2023" },
  { universalNumber: 15, fdiNumber: 27, name: "Upper Left 2nd Molar", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 16, fdiNumber: 28, name: "Upper Left 3rd Molar (Wisdom)", quadrant: "UL", arch: "maxillary", condition: "healthy", affectedSurfaces: [], notes: "Erupted normal alignment" },

  // Lower Left Quadrant (LL) - Universal 17 to 24 (FDI 38 to 31)
  { universalNumber: 17, fdiNumber: 38, name: "Lower Left 3rd Molar (Wisdom)", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 18, fdiNumber: 37, name: "Lower Left 2nd Molar", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 19, fdiNumber: 36, name: "Lower Left 1st Molar", quadrant: "LL", arch: "mandibular", condition: "crown", affectedSurfaces: ["occlusal", "buccal", "lingual", "mesial", "distal"], notes: "Zirconia ceramic crown placed post-RCT, margins clean", recommendedTreatment: "Routine monitoring", estimatedCost: 0 },
  { universalNumber: 20, fdiNumber: 35, name: "Lower Left 2nd Premolar", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 21, fdiNumber: 34, name: "Lower Left 1st Premolar", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 22, fdiNumber: 33, name: "Lower Left Canine", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 23, fdiNumber: 32, name: "Lower Left Lateral Incisor", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 24, fdiNumber: 31, name: "Lower Left Central Incisor", quadrant: "LL", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },

  // Lower Right Quadrant (LR) - Universal 25 to 32 (FDI 41 to 48)
  { universalNumber: 25, fdiNumber: 41, name: "Lower Right Central Incisor", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 26, fdiNumber: 42, name: "Lower Right Lateral Incisor", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 27, fdiNumber: 43, name: "Lower Right Canine", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 28, fdiNumber: 44, name: "Lower Right 1st Premolar", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 29, fdiNumber: 45, name: "Lower Right 2nd Premolar", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 30, fdiNumber: 46, name: "Lower Right 1st Molar", quadrant: "LR", arch: "mandibular", condition: "root-canal", affectedSurfaces: ["occlusal"], notes: "Completed root canal therapy; scheduled for final crown placement", recommendedTreatment: "Zirconia Crown Placement", estimatedCost: 180 },
  { universalNumber: 31, fdiNumber: 47, name: "Lower Right 2nd Molar", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
  { universalNumber: 32, fdiNumber: 48, name: "Lower Right 3rd Molar (Wisdom)", quadrant: "LR", arch: "mandibular", condition: "healthy", affectedSurfaces: [] },
];

export const CLINICAL_SERVICES: DentalService[] = [
  {
    id: "consultation-checkup",
    name: "Comprehensive Oral Examination & Digital X-Rays",
    category: "Preventive",
    price: 35,
    duration: "30 mins",
    description: "Detailed dental inspection, intraoral camera scan, low-radiation digital radiography, and personalized oral health report.",
    popular: true
  },
  {
    id: "ultrasonic-cleaning",
    name: "Ultrasonic Scaling & Deep Stain Polishing",
    category: "Preventive",
    price: 55,
    duration: "45 mins",
    description: "Painless calculus plaque removal, airflow polishing, and protective remineralizing fluoride varnish application.",
    popular: true
  },
  {
    id: "composite-filling",
    name: "Bio-Aesthetic Composite Resin Filling",
    category: "Restorative",
    price: 65,
    duration: "40 mins",
    description: "Tooth-colored, nano-hybrid composite filling matching natural enamel shade with seamless margin seal.",
    popular: true
  },
  {
    id: "painless-rct",
    name: "Single-Sitting Rotary Root Canal Therapy",
    category: "Endodontics",
    price: 145,
    duration: "60 mins",
    description: "State-of-the-art apex locator and rotary file disinfection for fast, pain-free tooth preservation.",
    popular: true
  },
  {
    id: "zirconia-crown",
    name: "Custom CAD/CAM Ceramic Zirconia Crown",
    category: "Restorative",
    price: 180,
    duration: "45 mins (2 visits)",
    description: "High-strength, lifelike biocompatible monolithic zirconia crown with 10-year warranty."
  },
  {
    id: "laser-whitening",
    name: "In-Office Laser Teeth Whitening",
    category: "Cosmetic",
    price: 120,
    duration: "60 mins",
    description: "Immediate 4 to 8 shades whiter smile using cold-light blue laser technology with anti-sensitivity gel.",
    popular: true
  },
  {
    id: "clear-aligners",
    name: "Invisible Aligners Consultation & 3D Scan",
    category: "Cosmetic",
    price: 40,
    duration: "45 mins",
    description: "3D digital simulation of teeth movement, personalized alignment trajectory, and orthodontic treatment blueprint."
  },
  {
    id: "emergency-relief",
    name: "Urgent Pain Relief & Emergency Triage",
    category: "Surgical",
    price: 45,
    duration: "30 mins",
    description: "Same-day priority evaluation for severe toothache, dental trauma, swelling, or fractured restoration."
  }
];

export const ALLERGY_OPTIONS = [
  "Penicillin / Amoxicillin",
  "Latex",
  "Local Anesthetics (Lidocaine/Articaine)",
  "Aspirin / NSAIDs",
  "Codeine / Opioids",
  "Sulfa Drugs",
  "Metals / Nickel",
  "No Known Drug Allergies (NKDA)"
];

export const MEDICAL_CONDITION_OPTIONS = [
  "High Blood Pressure (Hypertension)",
  "Diabetes (Type 1 / Type 2)",
  "Heart Murmur / Cardiac Condition",
  "Bleeding Disorder / On Blood Thinners",
  "Asthma / Respiratory Condition",
  "Artificial Joints / Implants",
  "Osteoporosis / Bisphosphonates",
  "Currently Pregnant (1st/2nd/3rd Trimester)",
  "Hepatitis / Liver Disease",
  "None of the above"
];

export const DENTAL_SYMPTOM_OPTIONS = [
  "Sharp toothache with cold/hot liquids",
  "Spontaneous throbbing pain at night",
  "Bleeding gums while brushing or flossing",
  "Visible cavity or dark spot on tooth",
  "Chipped, cracked, or broken tooth",
  "Loose tooth or crown",
  "Jaw stiffness, clicking, or clenching (TMJ)",
  "Bad breath or unpleasant taste",
  "Cosmetic discoloration / desire whiter smile",
  "Routine checkup & hygiene only"
];

export const VITA_SHADES = [
  { code: "B1", title: "Ultra Bright", hex: "#FFFDF0", lightness: 96, undertone: "Reddish-Yellow (Very Light)" },
  { code: "A1", title: "Bright Natural", hex: "#FCF8E3", lightness: 92, undertone: "Reddish-Brownish (Natural Light)" },
  { code: "B2", title: "Natural Light", hex: "#F7F1D5", lightness: 88, undertone: "Yellowish" },
  { code: "A2", title: "Standard Natural", hex: "#F3ECC6", lightness: 84, undertone: "Warm Enamel (Most Common)" },
  { code: "D2", title: "Soft Neutral", hex: "#EBE3C1", lightness: 80, undertone: "Reddish-Grey" },
  { code: "A3", title: "Warm Classic", hex: "#E7DCB5", lightness: 76, undertone: "Reddish-Brown" },
  { code: "C1", title: "Cool Neutral", hex: "#E2D9BC", lightness: 74, undertone: "Greyish" },
  { code: "A3.5", title: "Deep Warm", hex: "#DFD2A3", lightness: 70, undertone: "Deeper Amber" },
  { code: "A4", title: "Warm Brown", hex: "#D6C492", lightness: 64, undertone: "Dark Amber" }
];
