import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini Client
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

const CLINIC_SYSTEM_INSTRUCTION = `You are "SDA Dental AI", the friendly, knowledgeable, and empathetic AI clinical assistant for Dr. Swati's Dental And Aesthetic Care (SDA).

Clinic Details:
- Lead Dental Surgeon: Dr. Swati R Emaliya, B.D.S. (Dental Surgeon & Aesthetic Specialist, DCI Reg. No: DCI-84920/DL, 9+ years clinical experience).
- Clinic Name: Dr. Swati's Dental And Aesthetic Care
- Location: 5/904, GDA Market, Sector 5, Vaishali, Ghaziabad, Uttar Pradesh 201019.
- Helpline / WhatsApp: +91 85275 83991
- Timings: Monday – Saturday: 5:00 PM – 8:30 PM | Sunday: On Prior Appointment.
- Clinical Philosophy: Painless minimally invasive dentistry, anxiety-free treatments, digital diagnostics, high sterility.

Core Clinical Services:
1. Painless Rotary Root Canal Treatment (Single-sitting RCT, apex locator guided, bioceramic obturation).
2. Advanced Aesthetic Smile Studio (Porcelain veneers, cosmetic digital smile design, teeth whitening/bleaching).
3. Tooth-Colored Restorations (Nano-hybrid bio-compatible composite fillings).
4. Preventive Periodontal Prophylaxis (Ultrasonic scaling, airflow polishing, topical fluoride).
5. Prosthetics (Zirconia & ceramic crowns, fixed dental bridges).
6. Orthodontics & Invisible Aligners.
7. Wisdom Tooth Extractions (Atraumatic surgical removal).
8. Digital Radiography (Ultra-low dose digital sensors & panoramic OPGs).

Portal Capabilities to Guide Patients On:
- "Patient Intake Form": Digital medical history & consent before visiting.
- "Book Visit": Schedule real-time appointments with instant confirmation.
- "Reports & Digital X-Rays": Patients can log in using their registered mobile number to see their doctor remarks, high-resolution radiographs (with contrast invert & zoom), and digital prescriptions (Rx) once verified by clinic administration.
- "Smile Studio": Interactive tooth shade evaluation simulator.
- "Recovery & Post-Op": Interactive guidelines for root canal, extraction, and crown aftercare.

Guidelines for Your Answers:
- Tone: Warm, professional, reassuring, and compassionate. Relieve dental fear and anxiety.
- Format: Use concise bullet points, bold key points, and clear language.
- Emergency / Acute Pain: If the user describes swelling, trauma, or severe throbbing toothache, provide safe immediate home comfort advice (e.g. warm saltwater rinse, cold compress on cheek, avoid chewing on that side, keep head elevated) and strongly recommend booking an immediate clinical consultation with Dr. Swati or calling +91 85275 83991.
- Disclaimer: Always maintain medical responsibility. You provide clinical dental guidance and education on behalf of Dr. Swati's clinic, but an in-person clinical exam and radiograph are necessary for definitive diagnosis.`;

// Endpoint: AI Dental Chat
app.post('/api/chat', async (req: Request, res: Response) => {
  try {
    const { message, history } = req.body;

    if (!message || typeof message !== 'string') {
      res.status(400).json({ error: 'Message text is required' });
      return;
    }

    // Check if Gemini API Key is available
    if (!process.env.GEMINI_API_KEY) {
      console.warn('GEMINI_API_KEY not found in environment, falling back to local clinical knowledge responder.');
      const fallbackReply = generateFallbackDentalReply(message);
      res.json({ reply: fallbackReply });
      return;
    }

    // Prepare contents payload from conversation history + user prompt
    const contents: Array<{ role: string; parts: Array<{ text: string }> }> = [];

    if (Array.isArray(history)) {
      for (const msg of history.slice(-8)) {
        if (msg.role === 'user' || msg.role === 'model') {
          contents.push({
            role: msg.role,
            parts: [{ text: String(msg.text || (msg.parts && msg.parts[0]?.text) || '') }]
          });
        }
      }
    }

    // Add current user message
    contents.push({
      role: 'user',
      parts: [{ text: message }]
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: contents,
      config: {
        systemInstruction: CLINIC_SYSTEM_INSTRUCTION,
        temperature: 0.7,
      }
    });

    const reply = response.text || "I'm here to help with your dental health questions. Please feel free to ask about any procedure, tooth symptom, or appointment details.";
    res.json({ reply });
  } catch (error: any) {
    console.error('Error generating AI response with Gemini:', error);
    // Graceful fallback to avoid leaving user hanging
    const fallback = generateFallbackDentalReply(req.body?.message || '');
    res.json({ reply: fallback });
  }
});

// Helper for local dental responses when API key is unavailable or during rate limits
function generateFallbackDentalReply(query: string): string {
  const q = query.toLowerCase();

  if (q.includes('root canal') || q.includes('rct') || q.includes('pulpitis') || q.includes('nerve')) {
    return `### **Root Canal Treatment (RCT) at Dr. Swati's Clinic**
- **Is it painful?** Not at all! Dr. Swati uses advanced local anesthesia and precision rotary instruments, making modern root canals virtually pain-free.
- **Single-Sitting Available:** Most uncomplicated cases are completed in a comfortable 45–60 minute session.
- **Post-RCT Protection:** A biocompatible ceramic or zirconia crown is recommended within 2–3 weeks to prevent coronal fracture and restore 100% biting function.
- **Next Step:** You can easily book an endodontic consultation with Dr. Swati under the **Book Visit** tab!`;
  }

  if (q.includes('whiten') || q.includes('yellow') || q.includes('stain') || q.includes('cosmetic') || q.includes('veneer')) {
    return `### **Cosmetic Smile Enhancement Options**
Dr. Swati offers several tailored aesthetic solutions:
1. **Ultrasonic Scaling & Airflow Polishing:** Clears stubborn coffee/tea stains and tartar buildup safely.
2. **Professional In-Office Teeth Whitening:** Brightens enamel up to 6–8 shades in a single comfortable visit.
3. **Porcelain Veneers & Ceramic Laminates:** Flawlessly corrects minor gaps, chipped edges, or uneven contours.
- **Tip:** Check out our interactive **Smile Studio** tab right here in the portal to explore shade grades from A1 to D4!`;
  }

  if (q.includes('book') || q.includes('appointment') || q.includes('timing') || q.includes('contact') || q.includes('fee') || q.includes('cost')) {
    return `### **Clinic Timings & Appointment Booking**
- **Clinic:** Dr. Swati's Dental And Aesthetic Care
- **Address:** 5/904, GDA Market, Sector 5, Vaishali, Ghaziabad, UP 201019
- **Consultation Hours:** Mon – Sat: 5:00 PM – 8:30 PM (Sunday by appointment)
- **Direct Phone / WhatsApp:** +91 85275 83991
- **Online Booking:** Click the **Book Visit** tab in the top navigation to reserve your preferred date and time slot instantly!`;
  }

  if (q.includes('pain') || q.includes('ache') || q.includes('swelling') || q.includes('emergency')) {
    return `### **Immediate Comfort Advice for Toothache**
1. **Warm Saltwater Rinse:** Dissolve 1/2 teaspoon of salt in warm water and gently rinse to reduce oral bacterial load.
2. **Cold Compress:** Apply an ice pack wrapped in a cloth to your outer cheek for 10-minute intervals if swelling or tenderness is present.
3. **Avoid Trigger Foods:** Stay away from very hot, icy, or hard foods.
4. **Do Not Place Aspirin on Gums:** Never place pain pills directly against the tooth as this causes chemical tissue burns.
- **Urgent Care:** Severe tooth pain indicates pulp inflammation. Please call Dr. Swati at **+91 85275 83991** or book an urgent examination under **Book Visit**.`;
  }

  if (q.includes('xray') || q.includes('x-ray') || q.includes('report') || q.includes('prescription')) {
    return `### **Accessing Your Digital X-Rays & Prescriptions**
- **Registered Patient Vault:** Log into your patient account using your **registered mobile number** (via the Patient Login button in the header).
- **Admin Verification:** Once Dr. Swati's clinic desk verifies your patient file, the **Reports & Digital X-rays** tab unlocks automatically.
- **Features:** You can view high-resolution radiographs with contrast inversion and zoom, read Dr. Swati's clinical findings, and print official digital prescriptions (Rx)!`;
  }

  return `Hello! I'm **SDA Dental AI**, your clinical assistant for Dr. Swati's Dental And Aesthetic Care.

I can assist you with:
- 🦷 **Painless Root Canals & Fillings:** Procedure details, what to expect, and post-care.
- ✨ **Smile Studio & Whitening:** Porcelain veneers, aligners, and aesthetic shade matching.
- 🩻 **Digital X-Rays & Reports:** How to view your radiographs and prescriptions online.
- 📅 **Appointments & Clinic Timings:** Located at Sector 5, Vaishali, Ghaziabad (Helpline: +91 85275 83991).

How can I help you with your dental health today?`;
}

// Vite middleware in dev; static dist serving in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Dr. Swati Dental Clinic server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
